// Quadros especiais do sprite (depois dos 9 de caminhada).
export const POSE = { cheer: 9, protest: 10, kick: 11, signal: 12 };
