import Phaser from 'phaser';
import { createAllPersonTextures, createBallTextures, createShadowTexture } from '../utils/pixelTextures.js';

export default class BootScene extends Phaser.Scene {
  constructor() {
    super('BootScene');
  }

  create() {
    createAllPersonTextures(this);
    createBallTextures(this);
    createShadowTexture(this);
    this.scene.start('MenuScene');
  }
}
