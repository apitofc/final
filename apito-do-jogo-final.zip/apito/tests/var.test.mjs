import test from 'node:test';
import assert from 'node:assert/strict';
import { createMatch } from './helpers/harness.mjs';

const FOULS = ['light_foul', 'serious_foul', 'penalty'];

function runUntil(m, pred, mode = 'ignore', max = 60 * 60 * 20) {
  let n = 0;
  while (!pred() && n < max && !m.sim.finished) {
    m.advance(mode);
    n++;
  }
  assert.ok(pred(), 'condição não atingida');
}
function runFrames(m, frames, mode = 'ignore') {
  for (let i = 0; i < frames && !m.sim.finished; i++) m.advance(mode);
}
// Procura, na gravação, o primeiro lance de falta já decidido (resolvido) no tempo atual.
const resolvedFoul = (m) => [...m.varSys.infos.values()].find((i) => FOULS.includes(i.incident.type) && i.incident.status === 'resolved' && i.status === 'live' && i.incident.period === m.sim.period);
const keyState = (m) => ({
  time: m.sim.time,
  matchMs: m.sim.matchMs,
  state: m.sim.state,
  score: { ...m.sim.score },
  period: m.sim.period,
  ball: [m.ball.x, m.ball.y],
  players: m.sim.allPlayers.map((p) => [p.x, p.y, p.yellowCards, p.sentOff]),
  cards: JSON.stringify(m.dec.cards),
  log: m.dec.log.length,
  pending: m.dec.pending.length,
});
const redCount = (m) => m.dec.cards.home.red + m.dec.cards.away.red;
function checkInvariants(m, label = '') {
  const goalsHome = m.varSys.rec.events.filter((e) => e.type === 'goal' && !e.annulled && e.team === 'home').length;
  const goalsAway = m.varSys.rec.events.filter((e) => e.type === 'goal' && !e.annulled && e.team === 'away').length;
  assert.equal(m.sim.score.home, goalsHome, `${label} placar casa x gols válidos`);
  assert.equal(m.sim.score.away, goalsAway, `${label} placar fora x gols válidos`);
  assert.equal(m.sim.players.length, 22 - redCount(m), `${label} jogadores em campo x vermelhos`);
  assert.equal(m.sim.allPlayers.filter((p) => p.sentOff).length, redCount(m), `${label} expulsos x vermelhos`);
  assert.equal(m.nan, false, `${label} valores inválidos`);
}

test('o gravador registra a partida inteira com quadros crescentes e lances na linha do tempo', () => {
  const m = createMatch({ seed: 2, durationMs: 245000 });
  runUntil(m, () => m.sim.finished, 'perfect');
  const rec = m.varSys.rec;
  assert.ok(rec.length > 4000, `poucos quadros: ${rec.length}`);
  for (let i = 1; i < rec.frames.length; i++) assert.ok(rec.frames[i][0] > rec.frames[i - 1][0], 'rt deve só crescer');
  const types = new Set(rec.events.map((e) => e.type));
  for (const t of ['incident', 'restart', 'whistle']) assert.ok(types.has(t), `faltou ${t}`);
  const v = rec.sample(rec.end / 2);
  assert.ok(v.actors.every((a) => Number.isFinite(a.x) && Number.isFinite(a.y)));
  assert.equal(v.actors.length, 24);
});

test('a amostragem interpola entre quadros reais e não inventa movimento', () => {
  const m = createMatch({ seed: 3, durationMs: 245000 });
  runFrames(m, 600, 'perfect');
  const rec = m.varSys.rec;
  const i = 100;
  const a = rec.frames[i];
  const b = rec.frames[i + 1];
  const mid = (a[0] + b[0]) / 2;
  const v = rec.sample(mid);
  const ballX = v.actors[0].x;
  const lo = Math.min(a[7], b[7]);
  const hi = Math.max(a[7], b[7]);
  assert.ok(ballX >= lo - 1e-3 && ballX <= hi + 1e-3, 'bola fora do intervalo entre quadros');
  assert.equal(rec.sample(a[0]).actors[0].x, a[7]);
});

test('a revisão pausa a partida: relógio, placar e posições ficam congelados e voltam exatamente de onde pararam', () => {
  const m = createMatch({ seed: 1, durationMs: 245000 });
  runFrames(m, 60 * 40, 'perfect');
  const before = keyState(m);
  assert.ok(m.varSys.open().ok);
  assert.ok(m.varSys.active);
  // Dentro da revisão a cena não avança a simulação; aqui simulamos o uso dos controles por bastante tempo.
  const v = m.varSys;
  for (let i = 0; i < 600; i++) {
    v.update(16.67);
    if (i === 100) v.togglePlay();
    if (i === 200) v.setSpeed(0.25);
    if (i === 300) v.seek(1000);
    if (i === 400) v.step(-2000);
    if (i === 500) v.replay();
  }
  assert.deepEqual(keyState(m), before, 'a revisão não pode alterar o estado da partida');
  v.close();
  assert.equal(v.active, false);
  runFrames(m, 120, 'perfect');
  assert.ok(m.sim.matchMs > before.matchMs, 'o relógio volta a andar depois da revisão');
});

test('o VAR abre durante uma decisão (só para assistir) e não abre depois do fim da partida', () => {
  const m = createMatch({ seed: 1, durationMs: 245000 });
  runFrames(m, 30, 'perfect');
  assert.equal(m.varSys.canOpen().ok, true);
  // Com a janela de decisão aberta (painel de cartões), o VAR espera.
  m.referee.x = m.ball.x;
  m.referee.y = m.ball.y;
  runUntil(m, () => m.dec.pending.length > 0, 'manual');
  m.referee.x = m.dec.pending[0].x + 10;
  m.referee.y = m.dec.pending[0].y + 6;
  m.dec.whistle();
  assert.equal(m.dec.isDeciding(), true);
  // Durante a decisão o VAR abre (para rever o lance), mas só para assistir.
  const deciding = m.dec.stoppage.incident;
  const before = keyState(m);
  assert.ok(m.varSys.open({ incident: deciding }).ok);
  assert.equal(m.varSys.selectedEvent().incidentId, deciding.id, 'abre já no lance em decisão');
  assert.equal(m.varSys.canAlter(deciding.id).ok, false);
  assert.match(m.varSys.canAlter(deciding.id).reason, /aguarda a sua decisão/);
  assert.equal(m.varSys.alterDecision(deciding.id, { foul: true, cards: {} }).ok, false);
  for (let i = 0; i < 200; i++) m.varSys.update(16.67);
  m.varSys.close();
  assert.deepEqual(keyState(m), before, 'rever o lance não muda nada');
  assert.equal(m.dec.isDeciding(), true, 'a decisão continua em aberto');
  m.dec.resolveDecision({ foul: false, cards: {} });
  runUntil(m, () => m.sim.finished, 'perfect');
  assert.equal(m.varSys.canOpen().ok, false);
  assert.equal(m.varSys.open().ok, false);
});

test('controles de reprodução: velocidades, passos, avanço, retorno e início da jogada', () => {
  const m = createMatch({ seed: 4, durationMs: 245000 });
  runFrames(m, 60 * 50, 'perfect');
  const v = m.varSys;
  v.open();
  v.seek(20000);
  v.playing = true;
  v.setSpeed(0.25);
  for (let i = 0; i < 10; i++) v.update(100); // 1 s de tempo real
  assert.ok(Math.abs(v.cursor - 20250) < 1, `câmera lenta 0,25x deve avançar 250ms em 1s, avançou ${v.cursor - 20000}`);
  v.setSpeed(2);
  for (let i = 0; i < 5; i++) v.update(100); // 0,5 s de tempo real
  assert.ok(Math.abs(v.cursor - 21250) < 1);
  const jump = v.cursor;
  v.update(5000); // um quadro muito longo (aba em segundo plano) não pode fazer a reprodução pular
  assert.ok(v.cursor - jump <= 200 + 1e-6);
  v.cursor = jump;
  v.step(-2000);
  assert.equal(v.playing, false);
  assert.ok(Math.abs(v.cursor - 19250) < 1);
  v.step(2000);
  assert.ok(Math.abs(v.cursor - 21250) < 1);
  v.seek(-5);
  assert.equal(v.cursor, 0);
  v.seek(1e9);
  assert.equal(v.cursor, v.rec.end);

  const ev = v.eventList('lances')[0];
  v.selectEvent(ev.id);
  assert.ok(v.cursor < ev.rt, 'começa antes do lance');
  assert.ok(v.cursor >= ev.rt - 5001, 'não começa mais de 5 s antes');
  assert.ok(v.playing && v.stopAt > ev.rt, 'reproduz e para logo depois do lance');
  v.setSpeed(1);
  for (let i = 0; i < 1000 && v.playing; i++) v.update(16.67);
  assert.equal(v.playing, false);
  assert.ok(v.cursor >= ev.rt && v.cursor <= ev.rt + 2600);
  v.seek(ev.rt + 1000);
  v.jumpToPlayStart();
  assert.ok(v.cursor <= ev.rt - 1999, 'início da jogada fica antes do lance');
  v.close();
});

test('manter a decisão não altera nada na partida', () => {
  const m = createMatch({ seed: 3, durationMs: 245000 });
  runUntil(m, () => resolvedFoul(m), 'ignore');
  runFrames(m, 120);
  const info = resolvedFoul(m);
  m.varSys.open();
  const before = keyState(m);
  const r = m.varSys.keepDecision(info.incident.id);
  assert.ok(r.ok && !r.changed);
  assert.deepEqual(keyState(m), before);
  assert.equal(m.varSys.stats.kept, 1);
  // Alterar para exatamente a mesma decisão também equivale a manter.
  const same = m.varSys.alterDecision(info.incident.id, info.original);
  assert.ok(same.ok && !same.changed);
  assert.deepEqual(keyState(m), before);
});

test('alterar uma falta ignorada: o jogo volta ao lance, marca a falta e a partida segue consistente até o fim', () => {
  const m = createMatch({ seed: 3, durationMs: 245000 });
  runUntil(m, () => resolvedFoul(m), 'ignore');
  runFrames(m, 600); // o jogo já seguiu por alguns segundos depois do lance
  const info = resolvedFoul(m);
  const inc = info.incident;
  assert.equal(info.original.foul, false);
  const snapScore = { ...info.snapshot.sim.score };
  const matchMsBefore = m.sim.matchMs;

  assert.ok(m.varSys.open().ok);
  const res = m.varSys.alterDecision(inc.id, { foul: true, cards: { offender: null, victim: null } });
  assert.ok(res.ok && res.changed, res.reason);
  assert.deepEqual(m.sim.score, snapScore, 'placar volta ao do instante do lance');
  assert.equal(m.sim.matchMs, matchMsBefore, 'o relógio da partida não volta nem anda na correção');
  assert.equal(m.sim.state, 'stopped');
  assert.equal(m.dec.stoppage.reason, 'resolved');
  m.varSys.close();

  runUntil(m, () => m.sim.state === 'setpiece', 'ignore', 300);
  assert.equal(m.sim.state, 'setpiece', 'depois da parada, a cobrança é preparada');
  assert.equal(m.sim.setpiece.team, inc.victim.team);
  assert.ok(['free_kick', 'penalty'].includes(m.sim.setpiece.type));
  const entries = m.dec.log.filter((e) => e.incidentId === inc.id);
  assert.equal(entries.length, 1, 'uma única entrada na súmula para o lance');
  assert.equal(entries[0].actual.foulCalled, true);
  assert.equal(entries[0].varChanged, true);
  assert.equal(m.varSys.stats.changed, 1);

  runUntil(m, () => m.sim.finished, 'ignore');
  m.dec.closeAll();
  checkInvariants(m, 'após falta corrigida');
  assert.equal(m.sim.getClock().text, '90:00');
});

test('anular gol: corrigir o lance que o antecedeu desfaz o gol e devolve o placar', () => {
  let found = null;
  for (let seed = 1; seed <= 40 && !found; seed++) {
    const m = createMatch({ seed, durationMs: 245000 });
    let goalEv = null;
    for (let i = 0; i < 60 * 300 && !m.sim.finished && !goalEv; i++) {
      m.advance('ignore');
      const g = m.varSys.rec.events.filter((e) => e.type === 'goal').pop();
      if (g && g.period === m.sim.period) {
        const rel = m.varSys.relatedTo(g).filter((e) => FOULS.includes(m.varSys.infoOf(e.incidentId).incident.type) && m.varSys.canAlter(e.incidentId).ok);
        if (rel.length) goalEv = { g, rel: rel[0] };
        else if (m.sim.score.home + m.sim.score.away > 0) break;
      }
    }
    if (goalEv) found = { m, ...goalEv };
  }
  assert.ok(found, 'nenhuma partida de teste teve gol depois de uma falta no mesmo lance');
  const { m, g, rel } = found;
  const scoreWithGoal = { ...m.sim.score };
  const info = m.varSys.infoOf(rel.incidentId);
  const snapScore = { ...info.snapshot.sim.score };
  assert.ok(scoreWithGoal[g.team] > snapScore[g.team]);
  assert.ok(m.varSys.consequences(rel.incidentId).some((c) => c.startsWith('Gol')), 'o aviso deve listar o gol que será desfeito');

  m.varSys.open();
  const res = m.varSys.alterDecision(rel.incidentId, { foul: true, cards: { offender: null, victim: null } });
  assert.ok(res.ok && res.changed, res.reason);
  assert.deepEqual(m.sim.score, snapScore);
  assert.equal(m.varSys.eventById(g.id).annulled, true, 'o gol fica marcado como anulado na linha do tempo');
  m.varSys.close();
  runUntil(m, () => m.sim.finished, 'ignore');
  m.dec.closeAll();
  checkInvariants(m, 'após gol anulado');
});

test('cartão vermelho desfeito traz o jogador de volta; cartão vermelho aplicado pelo VAR o expulsa', () => {
  const m = createMatch({ seed: 5, durationMs: 245000 });
  runUntil(m, () => resolvedFoul(m), 'ignore');
  runFrames(m, 300);
  const info = resolvedFoul(m);
  const inc = info.incident;
  m.varSys.open();
  let res = m.varSys.alterDecision(inc.id, { foul: true, cards: { offender: 'red', victim: null } });
  assert.ok(res.ok && res.changed, res.reason);
  assert.equal(inc.offender.sentOff, true);
  assert.equal(m.dec.cards[inc.offender.team].red, 1);
  assert.equal(m.sim.players.includes(inc.offender), false);
  m.varSys.close();
  runFrames(m, 300);
  checkInvariants(m, 'com vermelho do VAR');

  // Agora o VAR volta atrás: sem cartão.
  m.varSys.open();
  res = m.varSys.alterDecision(inc.id, { foul: true, cards: { offender: null, victim: null } });
  assert.ok(res.ok && res.changed, res.reason);
  assert.equal(inc.offender.sentOff, false, 'o jogador expulso volta');
  assert.equal(m.sim.players.includes(inc.offender), true);
  assert.equal(m.dec.cards[inc.offender.team].red, 0);
  m.varSys.close();
  runFrames(m, 300);
  checkInvariants(m, 'vermelho desfeito');
});

test('se a correção falhar no meio, o estado anterior é restaurado por inteiro', () => {
  const m = createMatch({ seed: 3, durationMs: 245000 });
  runUntil(m, () => resolvedFoul(m), 'ignore');
  runFrames(m, 600);
  const info = resolvedFoul(m);
  m.varSys.open();
  const before = keyState(m);
  m.dec.applyReviewDecision = () => {
    throw new Error('falha simulada');
  };
  const res = m.varSys.alterDecision(info.incident.id, { foul: true, cards: { offender: 'red', victim: null } });
  assert.equal(res.ok, false);
  assert.match(res.reason, /mantido como estava/);
  assert.deepEqual(keyState(m), before, 'nada pode ter mudado');
  assert.equal(m.varSys.stats.changed, 0);
});

test('lances de outro tempo de jogo só podem ser assistidos, não alterados', () => {
  const m = createMatch({ seed: 3, durationMs: 245000 });
  runUntil(m, () => resolvedFoul(m), 'ignore');
  const id = resolvedFoul(m).incident.id;
  runUntil(m, () => m.sim.period === 2, 'ignore');
  const can = m.varSys.canAlter(id);
  assert.equal(can.ok, false);
  assert.match(can.reason, /tempo de jogo atual/);
  assert.equal(m.varSys.alterDecision(id, { foul: true, cards: {} }).ok, false);
  assert.ok(m.varSys.open().ok, 'mas a revisão abre e permite assistir');
  const ev = m.varSys.eventById(m.varSys.infoOf(id).eventId);
  m.varSys.selectEvent(ev.id);
  assert.ok(m.varSys.current().actors.length === 24);
});

test('VAR no intervalo: a correção concede tempo para a cobrança e o jogo não trava', () => {
  const m = createMatch({ seed: 3, durationMs: 245000 });
  m.autoSecondHalf = false;
  runUntil(m, () => resolvedFoul(m), 'ignore');
  runUntil(m, () => m.sim.state === 'stopped' && m.sim.stopReason === 'halftime', 'ignore');
  const info = resolvedFoul(m);
  assert.ok(m.varSys.open().ok, 'o VAR abre no intervalo');
  const res = m.varSys.alterDecision(info.incident.id, { foul: true, cards: { offender: null, victim: null } });
  assert.ok(res.ok, res.reason);
  assert.ok(m.sim.extraMs > 0, 'há acréscimo para a cobrança');
  m.varSys.close();
  runUntil(m, () => m.sim.state === 'stopped' && m.sim.stopReason === 'halftime' && m.sim.matchMs >= m.sim.periodEnd(), 'ignore');
  assert.equal(m.sim.period, 1);
  m.sim.startSecondHalf();
  assert.equal(m.sim.period, 2);
  assert.equal(m.sim.extraMs, 0, 'acréscimo do 1º tempo não vaza para o 2º');
  m.autoSecondHalf = true;
  runUntil(m, () => m.sim.finished, 'ignore');
  m.dec.closeAll();
  checkInvariants(m, 'VAR no intervalo');
});

test('estresse: dezenas de revisões e correções aleatórias mantêm placar, cartões e jogadores consistentes', () => {
  let altered = 0;
  for (const seed of [11, 12, 13, 14, 15, 16]) {
    const m = createMatch({ seed, durationMs: 245000 });
    const pick = () => [null, null, 'warning', 'yellow', 'red'][Math.floor(m.rng.frac() * 5)];
    let next = 60 * 15;
    let n = 0;
    while (!m.sim.finished && n < 60 * 60 * 20) {
      m.advance('random');
      n++;
      if (n >= next) {
        next = n + 60 * (8 + Math.floor(m.rng.frac() * 20));
        if (m.varSys.open().ok) {
          const cands = [...m.varSys.infos.values()].filter((i) => m.varSys.canAlter(i.incident.id).ok);
          if (cands.length && m.rng.frac() < 0.8) {
            const c = cands[Math.floor(m.rng.frac() * cands.length)];
            const res = m.varSys.alterDecision(c.incident.id, { foul: m.rng.frac() < 0.6, cards: { offender: pick(), victim: m.rng.frac() < 0.2 ? pick() : null } });
            assert.ok(res.ok, res.reason);
            if (res.changed) altered++;
          }
          m.varSys.close();
        }
      }
    }
    assert.ok(m.sim.finished, `seed ${seed} não terminou`);
    m.dec.closeAll();
    checkInvariants(m, `seed ${seed}`);
    assert.equal(m.dec.pending.length, 0);
    assert.equal(m.sim.getClock().text, '90:00');
  }
  assert.ok(altered >= 10, `poucas correções exercitadas: ${altered}`);
});
