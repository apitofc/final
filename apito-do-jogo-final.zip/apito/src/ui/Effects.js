import { playWhistle, playKick, playGoal, playCard, crowdSwell } from '../utils/audio.js';
import { POSE } from '../data/poses.js';
import { playerFull } from '../utils/labels.js';

const TEXT = { fontFamily: 'monospace', fontSize: '8px', color: '#ffffff', stroke: '#000000', strokeThickness: 2 };

export default class Effects {
  constructor(scene, referee) {
    this.scene = scene;
    this.referee = referee;
    this.markers = new Map();
    this.cards = [];

    scene.events.on('whistle', () => this.whistle());
    scene.events.on('incident-registered', (inc) => this.addMarker(inc));
    scene.events.on('decision-result', (entry) => this.removeMarker(entry.incidentId));
    scene.events.on('card', (e) => this.showCard(e));
    scene.events.on('player-sent-off', ({ player }) => this.sendOff(player));
    scene.events.on('var-rollback', (d) => this.onVarRollback(d));

    // Sons e torcida acompanham os acontecimentos da partida.
    scene.events.on('player-touch', ({ action, speed }) => {
      if (['shoot', 'pass', 'clear', 'cross'].includes(action)) playKick(Math.min(1, (speed || 150) / 240));
      if (action === 'shoot') crowdSwell(0.07, 700);
    });
    scene.events.on('goal', () => {
      playGoal();
      crowdSwell(0.18, 2600);
    });
    scene.events.on('halftime', () => playWhistle('final'));
    scene.events.on('fulltime', () => playWhistle('final'));
    scene.events.on('setpiece-start', ({ type }) => {
      if (type === 'penalty') crowdSwell(0.08, 1500);
    });
    scene.events.on('incident-registered', (inc) => {
      if (['light_foul', 'serious_foul', 'penalty'].includes(inc.type)) crowdSwell(0.06, 700);
    });
  }

  whistle() {
    const scene = this.scene;
    const ref = this.referee;
    playWhistle();
    ref.setPose(POSE.signal, 700);

    const g = scene.add.graphics().setDepth(9000);
    const o = { r: 4, a: 1 };
    scene.tweens.add({
      targets: o,
      r: 34,
      a: 0,
      duration: 600,
      onUpdate: () => {
        g.clear();
        g.lineStyle(2, 0xffffff, o.a);
        g.strokeCircle(ref.x, ref.y - 8, o.r);
      },
      onComplete: () => g.destroy(),
    });

    const t = scene.add.text(ref.x, ref.y - 26, 'PIIII!', TEXT).setOrigin(0.5).setDepth(9500);
    scene.tweens.add({ targets: t, y: t.y - 10, alpha: 0, duration: 900, onComplete: () => t.destroy() });
  }

  addMarker(inc) {
    const t = this.scene.add
      .text(inc.x, inc.y - 24, '!', { ...TEXT, fontSize: '10px', color: '#ffe066' })
      .setOrigin(0.5)
      .setDepth(9000);
    this.scene.tweens.add({ targets: t, y: t.y - 3, yoyo: true, repeat: -1, duration: 350 });
    this.markers.set(inc.id, t);
  }

  removeMarker(id) {
    const t = this.markers.get(id);
    if (!t) return;
    this.scene.tweens.killTweensOf(t);
    t.destroy();
    this.markers.delete(id);
  }

  showCard({ color, effective, player, secondYellow }) {
    const scene = this.scene;
    playCard();
    this.referee.setPose(POSE.signal, 1800);
    const hex = { yellow: 0xf5d90a, red: 0xe02020 };
    const colors = secondYellow ? ['yellow', 'red'] : [effective];
    const rects = [];

    colors.forEach((c, i) => {
      const dx = 6 + i * 8;
      const refRect = scene.add.rectangle(0, 0, 6, 9, hex[c]).setStrokeStyle(1, 0x000000).setDepth(9500);
      const playerRect = scene.add.rectangle(0, 0, 6, 9, hex[c]).setStrokeStyle(1, 0x000000).setDepth(9500);
      rects.push({ rect: refRect, owner: this.referee, dx, dy: -22 });
      rects.push({ rect: playerRect, owner: player, dx: dx - 6, dy: -22 });
    });
    this.cards.push({ rects, until: scene.time.now + 1800 });

    const name = color === 'yellow' && !secondYellow ? 'AMARELO' : secondYellow ? '2º AMARELO = VERMELHO' : 'VERMELHO';
    scene.events.emit('feedback', {
      kind: 'info',
      text: `CARTÃO ${name}\n${playerFull(player)}`,
    });
  }

  sendOff(player) {
    player.fadeOutSentOff();
  }

  // O VAR desfez lances: tira as marcas dos lances anulados e recoloca as dos lances que voltaram a ficar pendentes.
  onVarRollback({ annulledIds, restored }) {
    for (const id of annulledIds) this.removeMarker(id);
    for (const inc of restored) if (!this.markers.has(inc.id)) this.addMarker(inc);
    for (const c of this.cards) for (const r of c.rects) r.rect.destroy();
    this.cards = [];
  }

  update() {
    const now = this.scene.time.now;
    this.cards = this.cards.filter((c) => {
      const alive = now < c.until;
      for (const r of c.rects) {
        if (!alive) {
          r.rect.destroy();
        } else {
          r.rect.setPosition(Math.round(r.owner.x + r.dx), Math.round(r.owner.y + r.dy));
        }
      }
      return alive;
    });
  }
}