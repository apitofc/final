import { INCIDENT_LABEL, ERROR_MESSAGES, errorText } from './MatchRules.js';
import { playerFull } from '../utils/labels.js';

export const CATEGORIES = [
  { id: 'accuracy', label: 'Decisões corretas', max: 30 },
  { id: 'missed', label: 'Infrações não marcadas', max: 15 },
  { id: 'wrong', label: 'Faltas marcadas sem infração', max: 15 },
  { id: 'cards', label: 'Aplicação dos cartões', max: 15 },
  { id: 'advantage', label: 'Uso da vantagem', max: 10 },
  { id: 'position', label: 'Posicionamento', max: 10 },
  { id: 'consistency', label: 'Consistência', max: 5 },
];

const IMPORTANCE = { goal_check: 1.5, challenge: 0.5, light_foul: 1, serious_foul: 1.5, penalty: 2, simulation: 1.5, offside: 1, legal_position: 0.5 };
const WHISTLE_WEIGHT = 0.5;

const ERROR_SEVERITY = {
  FOUL_MISSED: 2,
  FOUL_WRONG: 2,
  CARD_MISSED: 1.5,
  CARD_TOO_LIGHT: 1,
  CARD_TOO_HARSH: 1,
  CARD_UNWARRANTED: 2,
  CARD_WRONG_PLAYER: 2,
  ADVANTAGE_FAILED: 1,
  WHISTLE_UNNECESSARY: 1,
};

const POSITION_GOOD = 30;
const POSITION_BAD = 120;

const weightOf = (e) => (IMPORTANCE[e.type] ?? 1) + (e.level === 'red' ? 0.5 : 0);
const sum = (list, fn) => list.reduce((acc, x) => acc + fn(x), 0);
const clamp01 = (v) => Math.max(0, Math.min(1, v));
const round1 = (v) => Math.round(v * 10) / 10;

const typeLabel = (e) => (e.type === 'unnecessary_whistle' ? 'Apito sem lance' : INCIDENT_LABEL[e.type]);
const teamTag = playerFull;
const CARD_NAMES = { yellow: 'amarelo', red: 'vermelho', warning: 'advertência verbal' };

export function expectedText(e) {
  const x = e.expected;
  const card = x.card ? ` + cartão ${CARD_NAMES[x.card]}` : '';
  switch (e.type) {
    case 'challenge':
      return 'lance legal: seguir o jogo';
    case 'light_foul':
      return 'falta (ou vantagem)';
    case 'serious_foul':
      return `falta${card}`;
    case 'penalty':
      return `pênalti${card}`;
    case 'simulation':
      return 'cartão amarelo para quem simulou, sem marcar falta';
    case 'offside':
      return 'impedimento (tiro livre indireto para o adversário)';
    case 'legal_position':
      return 'posição legal: seguir o jogo';
    case 'goal_check':
      return x.foul ? 'anular o gol (houve falta ou impedimento da equipe que marcou)' : 'confirmar o gol (não houve infração)';
    default:
      return '';
  }
}

export function actualText(e) {
  const a = e.actual;
  const parts = [];
  if (e.type === 'goal_check') return a.foulCalled ? 'anulou o gol' : 'confirmou o gol';
  if (a.foulCalled) parts.push(e.type === 'penalty' ? 'marcou pênalti' : e.type === 'offside' || e.type === 'legal_position' ? 'marcou impedimento' : 'marcou falta');
  else if (a.decided) parts.push('não marcou falta');
  for (const c of a.cards) parts.push(`${CARD_NAMES[c.color]} para ${teamTag(c)}`);
  if (a.advantage === 'success') parts.push('vantagem bem-sucedida');
  else if (a.advantage === 'implicit') parts.push('deixou seguir (vantagem sem sinalizar)');
  else if (a.advantage === 'failed') parts.push('vantagem que não se confirmou');
  if (!parts.length) parts.push('deixou seguir');
  return parts.join(', ');
}

// Fatos da partida, contados só a partir do registro de decisões (fonte única). Alimentam as estatísticas
// da carreira e todo o conteúdo de notícias, e-mails e rede social: nada é inventado.
export function matchFacts(log) {
  const f = {
    decisions: log.length,
    correct: 0,
    yellow: 0,
    red: 0,
    redWrong: 0,
    fouls: 0,
    penalties: 0,
    penaltiesCorrect: 0,
    penaltiesMissed: 0,
    wrongCalls: 0,
    missedFouls: 0,
    simulationsPunished: 0,
    simulationsMissed: 0,
    offsides: 0,
    offsidesCorrect: 0,
    offsidesMissed: 0,
    advantageOk: 0,
    advantageFailed: 0,
    whistles: 0,
    goalsDisallowed: 0,
    goalChecksWrong: 0,
  };
  for (const e of log) {
    if (e.correct) f.correct += 1;
    if (e.type === 'unnecessary_whistle') {
      f.whistles += 1;
      continue;
    }
    const a = e.actual;
    if (e.type === 'goal_check') {
      // Conferência de gol: não conta como falta, impedimento nem cartão.
      if (a.foulCalled && e.correct) f.goalsDisallowed += 1;
      if (!e.correct) f.goalChecksWrong += 1;
      continue;
    }
    const has = (code) => e.errors.includes(code);
    for (const c of a.cards) {
      if (c.color === 'yellow') f.yellow += 1;
      if (c.color === 'red') {
        f.red += 1;
        if (e.errors.some((x) => x.startsWith('CARD_'))) f.redWrong += 1;
      }
    }
    const isOffside = e.type === 'offside' || e.type === 'legal_position';
    if (a.foulCalled) {
      if (isOffside) f.offsides += 1;
      else f.fouls += 1;
      if (e.type === 'penalty') {
        f.penalties += 1;
        if (e.correct) f.penaltiesCorrect += 1;
      }
      if (e.type === 'offside' && e.correct) f.offsidesCorrect += 1;
    }
    if (has('FOUL_MISSED')) {
      f.missedFouls += 1;
      if (e.type === 'penalty') f.penaltiesMissed += 1;
      if (e.type === 'offside') f.offsidesMissed += 1;
    }
    if (has('FOUL_WRONG')) f.wrongCalls += 1;
    if (e.type === 'simulation' && e.correct && a.cards.some((c) => c.color !== 'warning')) f.simulationsPunished += 1;
    if (e.type === 'simulation' && has('CARD_MISSED')) f.simulationsMissed += 1;
    if (a.advantage === 'success') f.advantageOk += 1;
    if (a.advantage === 'failed') f.advantageFailed += 1;
  }
  return f;
}

// Fatos do VAR de uma partida, a partir do histórico auditável (VarSystem.audit + desfecho real de cada decisão).
// fixed = decisão alterada que terminou correta; worsened = decisão alterada que terminou errada.
export function varFacts(reviews) {
  const list = Array.isArray(reviews) ? reviews : [];
  const changed = list.filter((r) => r.kind === 'change');
  return {
    varReviews: list.length,
    varKept: list.length - changed.length,
    varChanged: changed.length,
    varEligible: list.filter((r) => r.eligible).length,
    varFixed: changed.filter((r) => r.finalCorrect === true).length,
    varWorsened: changed.filter((r) => r.finalCorrect === false).length,
  };
}

export function describeEntry(e) {
  if (e.type === 'unnecessary_whistle') {
    return { clock: e.clock, label: typeLabel(e), who: '', actual: 'apitou sem lance por perto', expected: 'deixar o jogo seguir', errors: e.errors.map((c) => ERROR_MESSAGES[c]), correct: false };
  }
  return {
    clock: e.clock,
    label: typeLabel(e),
    who: e.type === 'goal_check' && !e.cause ? '' : `${teamTag(e.offender)} × ${teamTag(e.victim)}`,
    actual: actualText(e),
    expected: expectedText(e),
    errors: e.errors.map((c) => errorText(c, e.type)),
    correct: e.correct,
  };
}

function hitText(e) {
  switch (e.type) {
    case 'challenge':
      return 'Seguiu o jogo em disputa legal';
    case 'light_foul':
      if (e.actual.advantage === 'success') return 'Vantagem bem aplicada';
      if (e.actual.advantage === 'implicit') return 'Deixou seguir com a equipe prejudicada mantendo a bola';
      return 'Falta leve marcada corretamente';
    case 'serious_foul':
      return e.expected.card === 'red' ? 'Falta grave com cartão vermelho correto' : 'Falta grave com cartão amarelo correto';
    case 'penalty':
      return e.expected.card ? 'Pênalti com cartão corretos' : 'Pênalti marcado corretamente';
    case 'simulation':
      return 'Simulação punida corretamente';
    case 'offside':
      return 'Impedimento marcado corretamente';
    case 'legal_position':
      return 'Seguiu o jogo em posição legal';
    case 'goal_check':
      return 'Gol irregular anulado corretamente';
    default:
      return 'Decisão correta';
  }
}

export function positionScore(distance) {
  if (distance <= POSITION_GOOD) return 1;
  if (distance >= POSITION_BAD) return 0;
  return (POSITION_BAD - distance) / (POSITION_BAD - POSITION_GOOD);
}

const weightedAccuracy = (list) => (list.length ? sum(list, (e) => weightOf(e) * (e.correct ? 1 : 0)) / sum(list, weightOf) : null);

export function gradeMatch(log) {
  const incidents = log.filter((e) => e.type !== 'unnecessary_whistle');
  const whistles = log.filter((e) => e.type === 'unnecessary_whistle');
  const has = (e, code) => e.errors.includes(code);
  const cats = {};

  {
    const total = sum(incidents, weightOf) + whistles.length * WHISTLE_WEIGHT;
    const right = sum(incidents.filter((e) => e.correct), weightOf);
    cats.accuracy = {
      ratio: total ? right / total : 1,
      detail: `${incidents.filter((e) => e.correct).length} de ${incidents.length + whistles.length} decisões corretas`,
    };
  }

  {
    const fouls = incidents.filter((e) => e.expected.foul);
    const missed = fouls.filter((e) => has(e, 'FOUL_MISSED'));
    const total = sum(fouls, weightOf);
    cats.missed = {
      ratio: total ? 1 - sum(missed, weightOf) / total : 1,
      detail: fouls.length ? `${missed.length} de ${fouls.length} infrações ignoradas` : 'nenhuma infração no jogo',
    };
  }

  {
    const clean = incidents.filter((e) => !e.expected.foul);
    const wrong = clean.filter((e) => has(e, 'FOUL_WRONG'));
    const total = sum(clean, weightOf) + whistles.length * WHISTLE_WEIGHT;
    const wrongW = sum(wrong, weightOf) + whistles.length * WHISTLE_WEIGHT;
    cats.wrong = {
      ratio: total ? 1 - wrongW / total : 1,
      detail: `${wrong.length} marcações indevidas e ${whistles.length} apitos sem lance`,
    };
  }

  {
    const relevant = incidents.filter(
      (e) => !has(e, 'FOUL_MISSED') && (e.expected.card || e.actual.cards.some((c) => c.color !== 'warning'))
    );
    const score = (e) => {
      const codes = e.errors.filter((c) => c.startsWith('CARD_'));
      if (!codes.length) return 1;
      return codes.every((c) => c === 'CARD_TOO_LIGHT' || c === 'CARD_TOO_HARSH') ? 0.5 : 0;
    };
    const total = sum(relevant, score);
    cats.cards = {
      ratio: relevant.length ? total / relevant.length : 1,
      detail: relevant.length ? `${total % 1 ? total.toFixed(1).replace('.', ',') : total} de ${relevant.length} aplicações corretas` : 'nenhum cartão necessário',
    };
  }

  {
    const used = incidents.filter((e) => ['success', 'implicit', 'failed'].includes(e.actual.advantage));
    const value = (e) => (e.actual.advantage === 'success' ? 1 : e.actual.advantage === 'implicit' ? 0.5 : 0);
    const total = sum(used, value);
    cats.advantage = {
      ratio: used.length ? total / used.length : 1,
      detail: used.length ? `${used.filter((e) => e.actual.advantage === 'success').length} de ${used.length} vantagens bem-sucedidas` : 'vantagem não utilizada',
    };
  }

  {
    const seen = incidents.filter((e) => e.refDistance !== null && e.refDistance !== undefined);
    const total = sum(seen, weightOf);
    const avg = seen.length ? sum(seen, (e) => e.refDistance) / seen.length : 0;
    cats.position = {
      ratio: total ? sum(seen, (e) => weightOf(e) * positionScore(e.refDistance)) / total : 1,
      detail: seen.length ? `distância média de ${Math.round(avg)} px nos lances` : 'sem lances',
    };
  }

  {
    const diffs = [];
    const culprit = (e) => (e.type === 'simulation' ? e.victim.team : e.offender.team);
    const home = incidents.filter((e) => culprit(e) === 'home');
    const away = incidents.filter((e) => culprit(e) === 'away');
    if (home.length >= 2 && away.length >= 2) diffs.push(Math.abs(weightedAccuracy(home) - weightedAccuracy(away)));
    const first = incidents.filter((e) => e.period === 1);
    const second = incidents.filter((e) => e.period === 2);
    if (first.length >= 2 && second.length >= 2) diffs.push(Math.abs(weightedAccuracy(first) - weightedAccuracy(second)));
    const mean = diffs.length ? sum(diffs, (d) => d) / diffs.length : 0;
    cats.consistency = {
      ratio: 1 - mean,
      detail: diffs.length ? `diferença média de ${Math.round(mean * 100)}% entre equipes e tempos` : 'poucos lances para comparar',
    };
  }

  const categories = CATEGORIES.map((c) => {
    const r = clamp01(cats[c.id].ratio);
    return { id: c.id, label: c.label, max: c.max, points: round1(r * c.max), ratio: r, detail: cats[c.id].detail };
  });
  const total = round1(sum(categories, (c) => c.points));
  const nota = round1(total / 10);

  const mistakes = log
    .filter((e) => e.errors.length)
    .map((e) => ({ entry: e, severity: sum(e.errors, (c) => ERROR_SEVERITY[c] ?? 1) * (e.type === 'unnecessary_whistle' ? 1 : weightOf(e)) }))
    .sort((a, b) => b.severity - a.severity || a.entry.time - b.entry.time)
    .map(({ entry, severity }) => ({ ...describeEntry(entry), severity }));

  const hits = incidents
    .filter((e) => e.correct)
    .map((e) => ({ entry: e, weight: weightOf(e) }))
    .sort((a, b) => b.weight - a.weight || a.entry.time - b.entry.time)
    .map(({ entry, weight }) => ({ ...describeEntry(entry), text: hitText(entry), weight }));

  const label = nota >= 9 ? 'Excelente' : nota >= 8 ? 'Muito bom' : nota >= 7 ? 'Bom' : nota >= 5 ? 'Regular' : 'Precisa melhorar';

  return {
    total,
    nota,
    label,
    categories,
    mistakes,
    hits,
    counts: { incidents: incidents.length, correct: incidents.filter((e) => e.correct).length, unnecessaryWhistles: whistles.length },
  };
}