// Simula partidas inteiras sem navegador, com entidades de mentira no lugar dos sprites do Phaser.
import { EventEmitter } from 'events';
import { FIELD, FIELD_RECT, TEAMS } from '../../src/config.js';
import { FORMATION_442 } from '../../src/data/formations.js';
import MatchSimulation from '../../src/systems/MatchSimulation.js';
import RefereeDecisionSystem from '../../src/systems/RefereeDecisionSystem.js';
import { gradeMatch } from '../../src/systems/RefereeGrading.js';
import VarSystem from '../../src/systems/VarSystem.js';

function mulberry32(a) {
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const approach = (c, t, m) => (c < t ? Math.min(c + m, t) : Math.max(c - m, t));

class MockChar {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.vx = 0;
    this.vy = 0;
    this.moveSpeed = 70;
    this.accel = 700;
  }
  placeAt(x, y) {
    this.x = x;
    this.y = y;
    this.vx = 0;
    this.vy = 0;
  }
  update(delta, move) {
    const dt = delta / 1000;
    const len = Math.hypot(move.x, move.y);
    const sc = len > 1 ? 1 / len : 1;
    this.vx = approach(this.vx, move.x * sc * this.moveSpeed, this.accel * dt);
    this.vy = approach(this.vy, move.y * sc * this.moveSpeed, this.accel * dt);
    this.x = Math.max(0, Math.min(FIELD_RECT.right + 24, this.x + this.vx * dt));
    this.y = Math.max(0, Math.min(FIELD_RECT.bottom + 24, this.y + this.vy * dt));
  }
}
const SPEED = { GK: 62, DEF: 66, MID: 70, FWD: 72 };
class MockPlayer extends MockChar {
  constructor(x, y, c) {
    super(x, y);
    Object.assign(this, c);
    this.moveSpeed = SPEED[c.role];
    this.touchCooldown = 0;
    this.holdTimer = 0;
  }
}
class MockBall {
  constructor(x, y) {
    Object.assign(this, { x, y, vx: 0, vy: 0, lastTouchTeam: null, holder: null, lastPasser: null, lastPassTime: -Infinity, touchLock: 0, refCooldown: 0 });
  }
  kick(vx, vy) {
    this.vx = vx;
    this.vy = vy;
  }
  place(x, y) {
    Object.assign(this, { x, y, vx: 0, vy: 0, touchLock: 0, holder: null });
  }
  update(ms) {
    const dt = ms / 1000;
    const k = Math.pow(0.35, dt);
    this.vx *= k;
    this.vy *= k;
    if (Math.hypot(this.vx, this.vy) < 5) this.vx = this.vy = 0;
    this.x += this.vx * dt;
    this.y += this.vy * dt;
  }
}

// Monta uma partida completa sem navegador e devolve tudo o que os testes precisam.
// `advance(mode)` executa um quadro, na mesma ordem da MatchScene (gravação do VAR antes e depois do passo).
// mode: 'perfect' (decide como esperado), 'random', 'ignore' (nunca apita) ou 'manual' (não decide nada sozinho).
export function createMatch({ seed = 1, durationMs = 300000, difficulty = {} } = {}) {
  const rng = { frac: mulberry32(seed) };
  const players = [];
  for (const t of Object.values(TEAMS)) {
    const d = t.attackDir;
    const ownX = d > 0 ? FIELD_RECT.left : FIELD_RECT.right;
    FORMATION_442.forEach((s, i) => {
      const nx = s.role === 'GK' ? s.nx : Math.min(s.nx, 0.46);
      players.push(new MockPlayer(ownX + d * nx * FIELD.width, FIELD_RECT.top + s.ny * FIELD.height, { team: t.id, role: s.role, attackDir: d, nx: s.nx, ny: s.ny, number: i + 1 }));
    });
  }
  const ball = new MockBall(FIELD_RECT.cx, FIELD_RECT.cy);
  const referee = new MockChar(FIELD_RECT.cx + 12, FIELD_RECT.cy + 22);
  const events = new EventEmitter();
  const fouls = [];
  const goals = [];
  const incidents = [];
  const setpieces = {};
  events.on('incident', (i) => {
    if (['light_foul', 'serious_foul', 'penalty'].includes(i.type)) fouls.push({ type: i.type, level: i.level, evidence: i.evidence });
  });
  events.on('incident', (i) => incidents.push({ type: i.type, evidence: i.evidence, expected: i.expected }));
  events.on('setpiece-start', (d) => (setpieces[d.type] = (setpieces[d.type] || 0) + 1));
  events.on('goal', (g) => goals.push(g.team));

  const sim = new MatchSimulation(events, { ball, players, referee, rng, matchDurationMs: durationMs, difficulty });
  const dec = new RefereeDecisionSystem(events, sim);
  const varSys = new VarSystem(events, sim, dec);
  events.on('halftime', () => dec.closeAll());
  events.on('fulltime', () => dec.closeAll());
  sim.startSetPiece('kickoff', 'home');

  const queue = [];
  const forced = [];
  events.on('incident-registered', (inc) => queue.push(inc));
  events.on('decision-needed', (d) => {
    if (d.forceFoul) forced.push(d);
  });

  const act = (mode) => {
    while (forced.length) {
      const d = forced.shift();
      if (!dec.isDeciding()) continue;
      const e = d.incident.expected;
      dec.resolveDecision({ foul: true, cards: { offender: e.cardTarget === 'offender' ? e.card : null, victim: null } });
    }
    while (queue.length) {
      const inc = queue.shift();
      if (inc.status === 'resolved') continue;
      if (sim.state !== 'playing') {
        queue.unshift(inc);
        break;
      }
      if (inc.status !== 'pending') continue;
      if (mode === 'random') {
        if (rng.frac() < 0.4) continue;
        referee.x = inc.x + (rng.frac() < 0.5 ? 10 : 70);
        referee.y = inc.y + 6;
        dec.whistle();
        if (!dec.isDeciding()) continue;
        const pick = () => [null, null, 'warning', 'yellow', 'red'][Math.floor(rng.frac() * 5)];
        dec.resolveDecision({ foul: rng.frac() < 0.5, cards: { offender: pick(), victim: rng.frac() < 0.2 ? pick() : null } });
        continue;
      }
      referee.x = inc.x + 10;
      referee.y = inc.y + 6;
      const e = inc.expected;
      if (!e.foul && !e.card) continue;
      dec.whistle();
      if (!dec.isDeciding()) continue;
      dec.resolveDecision({ foul: e.foul, cards: { offender: e.cardTarget === 'offender' ? e.card : null, victim: e.cardTarget === 'diver' ? e.card : null } });
    }
  };

  const m = { sim, dec, varSys, events, referee, ball, players, rng, fouls, goals, incidents, setpieces, nan: false, frames: 0, autoSecondHalf: true };
  m.advance = (mode = 'perfect', ms = 16.67) => {
    m.frames++;
    varSys.beforeStep(ms);
    referee.update(ms, { x: 0, y: 0 });
    sim.update(ms);
    if (mode !== 'ignore' && mode !== 'manual') act(mode);
    dec.update(ms);
    varSys.afterStep();
    if (m.autoSecondHalf && sim.state === 'stopped' && sim.stopReason === 'halftime') sim.startSecondHalf();
    for (const p of players) if (!Number.isFinite(p.x) || !Number.isFinite(p.y)) m.nan = true;
    if (!Number.isFinite(ball.x) || !Number.isFinite(ball.y)) m.nan = true;
  };
  return m;
}

// mode: 'perfect' (decide como esperado), 'random' ou 'ignore' (nunca apita).
export function runMatch({ mode = 'perfect', seed = 1, durationMs = 300000, difficulty = {} } = {}) {
  const m = createMatch({ seed, durationMs, difficulty });
  const limit = 60 * 60 * 40;
  while (!m.sim.finished && m.frames < limit) m.advance(mode);
  m.dec.closeAll();
  return { sim: m.sim, dec: m.dec, fouls: m.fouls, goals: m.goals, incidents: m.incidents, setpieces: m.setpieces, nan: m.nan, frames: m.frames, finished: m.sim.finished, grade: gradeMatch(m.dec.log), varSys: m.varSys };
}
