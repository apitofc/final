# Apito do Jogo: entrega final (Etapas 1 a 8)

## Instalar e executar
    npm install
    npm run dev      # abre em http://localhost:5173
    npm test         # 123 testes automáticos
    npm run build    # build de produção (dist/)

## Funcionalidades implementadas
- **Gameplay original (8 fases, ver docs/ARQUITETURA.md §2):** campo, árbitro e câmera, jogadores/bola/IA, faltas/apito/cartões/painel, placar/relógio/gols/tempos, nota do árbitro, menu e carreira, impedimento/visual/áudio. Controles preservados.
- **Perfil:** nome (padrão "Novo Árbitro"), 8 aparências, 5 regiões; voltar sem perder o rascunho; salvo e restaurado.
- **Central da carreira:** visão geral, convocações, calendário, classificação, notícias, e-mails, rede social, estatísticas, objetivos, prêmios, eventos, histórico, competições, configurações, salvar/apagar, menu.
- **Calendário e competições:** jogos fictícios determinísticos, convocações aceitáveis ou recusáveis sem custo, partidas não repetíveis, tabelas e copas.
- **Durações:** 3 opções (Rápida, Padrão, Longa), preferência salva (decisão do usuário: manter só 3).
- **Progressão:** XP, reputação, divisões, promoções por critérios explícitos, 9 objetivos de carreira.
- **Comunicação:** notícias, e-mails e rede social gerados só a partir dos fatos reais da partida.
- **VAR:** gravação, replay, painel, manter ou corrigir a decisão, histórico auditável (decisão inicial, final e motivo) ligado à carreira.
- **Pressão e eventos:** clássicos, finais, última rodada etc. (não alteram nota nem recompensas); eventos de jogo de pressão, revisão técnica, reconhecimento, críticas públicas e convocação especial.
- **Prêmios de temporada:** Revelação, Avaliação Técnica, Destaque Regional, Eliminatórias e Árbitro da Temporada, por critérios verificáveis.
- **Anulação de gol:** gol vindo de falta ou impedimento da equipe que marcou pode ser anulado com Espaço, F ou G logo depois do gol (com ou sem VAR), com nota própria.
- **Salvamento:** versão 7, migração com backup a partir de versões antigas, dados inválidos nunca apagados em silêncio.

## Arquivos (em relação ao projeto recebido em apito-grande-atualizacao.zip)
Criados: `src/systems/ContextSystem.js`, `src/systems/AwardsSystem.js`, `tests/context.test.mjs`, `tests/awards.test.mjs`, `tests/goalcheck.test.mjs`, `ENTREGA.md`.
Modificados: `src/config.js` (só a lista de eventos), `src/scenes/MatchScene.js`, `MenuScene.js`, `ResultScene.js`, `src/style.css`, `src/ui/HUD.js`, `src/systems/CareerSystem.js`, `CommsSystem.js`, `Controls.js`, `MatchRules.js`, `MatchSimulation.js`, `ProgressionSystem.js`, `RefereeDecisionSystem.js`, `RefereeGrading.js`, `VarSystem.js` (Etapa 6: só acrescentou o histórico de auditoria; a anulação de gol não mexeu nele), `tests/progression.test.mjs` (9 objetivos em vez de 8), `package.json`, `package-lock.json`, `ATUALIZACAO.md`, `docs/ARQUITETURA.md` (seções 13 a 15).

## Testes executados
| Verificação | Resultado |
|---|---|
| `npm test` (node --test) | 123 aprovados, 0 reprovados |
| `vite build` | aprovado |
| Regressão no navegador (Chromium headless, 16 verificações) | 16 aprovadas |
Cobertura do navegador: ajuda (3 abas), criação do árbitro (8 aparências, 5 regiões, nome padrão, voltar sem perder o rascunho), carreira salva com perfil, abertura de todas as abas da central, partida completa da carreira até o resultado, histórico/e-mails/notícias/publicações atualizados, retorno à central, recarregar a página, 3 durações e preferência salva, migração v5 para v7 com backup, salvamento inválido preservado, tela estreita sem rolagem horizontal e nenhum erro de console.

## Não testado ou limitado
- Anulação de gol e painel do VAR no navegador com gol e revisão reais: cobertos só pelos testes automáticos (a simulação do navegador não teve gol nem revisão nessas partidas).
- Teste manual humano de jogo (sensação de ritmo, balanceamento, aparência dos 8 visuais em partida) não foi feito.
- Supercopa Nacional e Liga Continental (sugeridas no prompt) não foram criadas: existem as ligas nacionais, a Copa Nacional, as 5 copas regionais e a Copa Continental. A estrutura de dados permite acrescentá-las.
- Eventos de mudança de escala e de oportunidade de competição superior não têm evento próprio (a liberação de competição continua avisada por e-mail).
- Anulação de gol não permite dar cartão junto; o replay do VAR mostra o gol anulado pela tecla na linha do tempo.
- Notícias, e-mails e publicações usam textos modelo variados, não geração livre.

## Próximos passos sugeridos
Jogar algumas temporadas completas para balancear XP, reputação e prêmios; criar o evento de mudança de escala; permitir cartão junto da anulação de gol; testes de ponta a ponta automatizados no navegador (o roteiro usado está descrito acima).
