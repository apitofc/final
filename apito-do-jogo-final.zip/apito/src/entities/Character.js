import Phaser from 'phaser';

const STEP_CYCLE = [1, 0, 2, 0]; // sequência de quadros de caminhada
const STEP_MS = 110;

const approach = (current, target, maxDelta) =>
  current < target ? Math.min(current + maxDelta, target) : Math.max(current - maxDelta, target);

// Base comum de árbitro e jogadores: movimento com aceleração, direção e animação.
export default class Character extends Phaser.Physics.Arcade.Sprite {
  constructor(scene, x, y, texture) {
    super(scene, x, y, texture, 0);
    scene.add.existing(this);
    scene.physics.add.existing(this);

    // Origem nos pés; o corpo físico é só a área dos pés.
    this.setOrigin(0.5, 1);
    this.body.setSize(6, 3, false);
    this.body.setOffset(3, 13);
    this.setCollideWorldBounds(true);

    this.moveSpeed = 70; // px/s
    this.accel = 700; // px/s²
    this.dir = 0; // 0 frente, 1 costas, 2 lado
    this.animTimer = 0;
    this.poseTimer = 0;
    this.poseFrame = 0;

    this.shadow = scene.add.image(x, y - 1, 'shadow').setDepth(1);
    this.setDepth(y);
  }

  // Teletransporta o personagem (reinício de jogo): zera velocidade e atualiza sombra e profundidade.
  placeAt(x, y) {
    this.body.reset(x, y);
    this.setPosition(x, y);
    this.animTimer = 0;
    this.poseTimer = 0;
    this.shadow.setPosition(Math.round(x), Math.round(y) - 1);
    this.setDepth(y);
  }

  // Pose especial por alguns instantes (chute, comemoração, reclamação, sinal do árbitro).
  setPose(frame, ms) {
    this.poseFrame = frame;
    this.poseTimer = ms;
  }

  get vx() {
    return this.body.velocity.x;
  }

  get vy() {
    return this.body.velocity.y;
  }

  // move: vetor com módulo até 1 (acima de 1 é normalizado).
  update(delta, move) {
    const dt = delta / 1000;
    const len = Math.hypot(move.x, move.y);
    const scale = len > 1 ? 1 / len : 1;

    const tx = move.x * scale * this.moveSpeed;
    const ty = move.y * scale * this.moveSpeed;
    const step = this.accel * dt;
    this.body.setVelocity(
      approach(this.body.velocity.x, tx, step),
      approach(this.body.velocity.y, ty, step)
    );

    const moving = len > 0.05;
    if (moving) {
      if (Math.abs(move.x) > Math.abs(move.y)) {
        this.dir = 2;
        this.setFlipX(move.x < 0);
      } else {
        this.dir = move.y > 0 ? 0 : 1;
        this.setFlipX(false);
      }
      this.animTimer += delta;
    } else {
      this.animTimer = 0;
    }

    const stepFrame = moving ? STEP_CYCLE[Math.floor(this.animTimer / STEP_MS) % STEP_CYCLE.length] : 0;
    if (this.poseTimer > 0) {
      this.poseTimer -= delta;
      let frame = this.poseFrame;
      // Comemoração "pulando": alterna entre braços para cima e parado.
      if (frame === 9 && Math.floor(this.poseTimer / 220) % 2 === 1) frame = 0;
      this.setFrame(frame);
    } else {
      this.setFrame(this.dir * 3 + stepFrame);
    }

    // Ordenação por profundidade (quem está mais abaixo fica na frente).
    this.setDepth(this.y);
    this.shadow.setPosition(Math.round(this.x), Math.round(this.y) - 1);
  }
}
