import test from 'node:test';
import assert from 'node:assert/strict';
import { runMatch } from './helpers/harness.mjs';
import { DURATIONS, DEFAULT_DURATION, getDuration } from '../src/config.js';

test('existem exatamente as três durações pedidas, com as faixas certas', () => {
  assert.deepEqual(DURATIONS.map((d) => [d.id, d.minutes]), [['quick', '2 a 3'], ['standard', '4 a 5'], ['long', '6 a 7']]);
  assert.equal(DEFAULT_DURATION, 'standard');
  assert.equal(getDuration('short').id, 'quick', 'ids antigos continuam resolvendo');
  assert.equal(getDuration('inexistente').id, 'standard');
});

for (const d of DURATIONS) {
  test(`duração ${d.label} (${d.minutes} min): o tempo real fica na faixa, o relógio vai a 90:00 e a partida não trava`, () => {
    const [lo, hi] = d.minutes.split(' a ').map(Number);
    for (const mode of ['perfect', 'random', 'ignore']) {
      for (const seed of [1, 2, 3]) {
        const r = runMatch({ mode, seed, durationMs: d.ms });
        assert.ok(r.finished, `${mode}/${seed} não terminou`);
        const min = r.sim.time / 60000;
        assert.ok(min >= lo && min <= hi, `${mode}/${seed}: ${min.toFixed(2)} min fora de ${lo}-${hi}`);
        assert.equal(r.sim.getClock().text, '90:00');
        assert.equal(r.sim.period, 2);
        assert.equal(r.nan, false);
      }
    }
  });
}
