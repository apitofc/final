import { COMPETITIONS, LEVELS, getCompetition, getClub, unlockThreshold } from '../data/competitions.js';
import {
  WEEKS_PER_SEASON,
  createWorld,
  isValidWorld,
  findFixture,
  completeFixture,
  playWeek,
  seasonChampions,
  buildOffers,
} from './CalendarSystem.js';
import {
  LEAGUES,
  GRAVE_SEVERITY,
  repBreakdown,
  xpBreakdown,
  suspensionFor,
  seasonStats,
  decideSeason,
  initialObjectives,
  completeObjectives,
} from './ProgressionSystem.js';
import { ensureComms, publish, commsForMatch, commsForSeason, commsForObjectives, syncWeekEmail, welcomeEmail, EMPTY_FACTS } from './CommsSystem.js';
import { DEFAULT_PROFILE, REGIONS, REFEREE_LOOKS } from '../data/referees.js';
import { matchContext, contextSummary, eventsForMatch, criticismEvent, eventsForWeek } from './ContextSystem.js';
import { varFacts } from './RefereeGrading.js';
import { grantAwards } from './AwardsSystem.js';

// A temporada tem uma rodada por semana do calendário (5). Era 6 jogos antes da Etapa 3.
export const SEASON_ROUNDS = WEEKS_PER_SEASON;
const MIN_MATCHES_FOR_BONUS = 3; // para receber o bônus de fim de temporada é preciso ter apitado ao menos 3 jogos
const CHAMPIONS_LIMIT = 60;
const HISTORY_LIMIT = 40;
const START_REPUTATION = 5;
const PROCESSED_LIMIT = 30;
export const CAREER_VERSION = 7;
const SEASONS_LIMIT = 30;

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const round1 = (v) => Math.round(v * 10) / 10;
export const comma = (n) => String(round1(n)).replace('.', ',');

// profile: { name, look, region }. Também aceita só o nome (formato antigo).
export function createCareer(profile, seed = Math.floor(Math.random() * 1e6)) {
  const p = typeof profile === 'string' ? { name: profile } : profile || {};
  const clean = sanitizeProfile(p);
  const career = {
    version: CAREER_VERSION,
    name: clean.name,
    profile: clean,
    seed,
    xp: 0,
    rep: START_REPUTATION,
    totalMatches: 0,
    unlocked: ['varzea'],
    season: newSeason(1, 0),
    history: [],
    invitations: [], // legado das versões 1 e 2 (os convites agora vêm do calendário em world.offers)
    processed: [],
    skipped: 0,
    champions: [],
    division: 0, // índice da liga atual na escada de divisões (muda só por promoção ou rebaixamento)
    strikes: 0, // temporadas seguidas com média abaixo de 5,0
    restricted: null, // suspensão de oportunidades por uma rodada: { season, week, reason }
    seasons: [], // resumo de cada temporada concluída, com promoção ou rebaixamento
    objectives: initialObjectives(),
    inbox: [], // e-mails (convocações, relatórios, comunicados)
    news: [], // notícias geradas a partir das partidas
    social: [], // rede social fictícia
    comms: { seq: 0 },
    awards: [], // prêmios de temporada conquistados
    events: [], // eventos especiais da carreira (pressão, revisões, críticas, convocações especiais)
    world: createWorld(seed, 1),
  };
  publish(career, { emails: [welcomeEmail(career)] }, { season: 1, week: 1 });
  prepareWeek(career);
  return career;
}

// Garante nome, aparência e região válidos (usa os valores padrão quando faltam).
export function sanitizeProfile(p) {
  const name = String(p.name ?? '').trim().slice(0, 16) || DEFAULT_PROFILE.name;
  const look = REFEREE_LOOKS.some((l) => l.id === p.look) ? p.look : DEFAULT_PROFILE.look;
  const region = REGIONS.some((r) => r.id === p.region) ? p.region : DEFAULT_PROFILE.region;
  return { name, look, region };
}

// Valida a estrutura mínima de uma carreira salva.
export function isValidCareer(c) {
  if (!c || typeof c !== 'object') return false;
  const finite = (v) => typeof v === 'number' && Number.isFinite(v);
  return (
    typeof c.name === 'string' &&
    finite(c.xp) &&
    finite(c.rep) &&
    finite(c.totalMatches) &&
    finite(c.seed) &&
    Array.isArray(c.unlocked) &&
    c.unlocked.length > 0 &&
    Array.isArray(c.history) &&
    Array.isArray(c.invitations) &&
    c.season &&
    typeof c.season === 'object' &&
    finite(c.season.number) &&
    finite(c.season.round) &&
    Array.isArray(c.season.matches)
  );
}

// Migra uma carreira de versão anterior sem perder nenhum campo existente.
// Retorna { career, migrated } ou { error }.
export function migrateCareer(raw) {
  if (!raw || typeof raw !== 'object') return { error: 'dados vazios ou ilegíveis' };
  if (![1, 2, 3, 4, 5, 6, CAREER_VERSION].includes(raw.version)) return { error: `versão desconhecida (${raw.version})` };
  if (!isValidCareer(raw)) return { error: 'estrutura inválida' };

  let migrated = false;
  const career = { ...raw };
  if (career.version === 1) {
    career.migratedFrom = 1;
    migrated = true;
  }
  if (!career.profile) {
    career.profile = sanitizeProfile({ name: career.name });
    migrated = true;
  } else {
    career.profile = sanitizeProfile(career.profile);
  }
  if (!Array.isArray(career.processed)) {
    career.processed = [];
    migrated = true;
  }

  // v2 -> v3: calendário. A semana atual sai do progresso da temporada; as semanas anteriores são simuladas.
  if (career.version < 3 || !isValidWorld(career.world)) {
    if (career.version < 3) career.migratedFrom = career.migratedFrom ?? career.version;
    const week = clamp(career.season.round + 1, 1, WEEKS_PER_SEASON);
    career.world = createWorld(career.seed, career.season.number);
    for (let w = 1; w < week; w++) playWeek(career.world, career.seed, w);
    career.world.week = week;
    career.skipped = Number.isFinite(career.skipped) ? career.skipped : 0;
    career.champions = Array.isArray(career.champions) ? career.champions : [];
    refreshUnlocks(career);
    prepareWeek(career);
    migrated = true;
  }
  career.skipped = Number.isFinite(career.skipped) ? career.skipped : 0;
  if (!Array.isArray(career.champions)) career.champions = [];

  // v3 -> v4: divisão explícita, avisos, temporadas e objetivos de carreira.
  // A divisão vem da maior liga já liberada; objetivos já cumpridos são marcados sem dar recompensa.
  if (career.version < 4 || !Number.isInteger(career.division) || !Array.isArray(career.objectives)) {
    if (career.version < 4) career.migratedFrom = career.migratedFrom ?? career.version;
    const unlockedLeagues = LEAGUES.map((l, i) => (career.unlocked.includes(l.id) ? i : -1));
    career.division = clamp(Number.isInteger(career.division) ? career.division : Math.max(0, ...unlockedLeagues), 0, LEAGUES.length - 1);
    career.strikes = Number.isFinite(career.strikes) ? career.strikes : 0;
    career.restricted = career.restricted || null;
    career.seasons = Array.isArray(career.seasons) ? career.seasons : [];
    career.objectives = initialObjectives();
    completeObjectives(career, { retro: true });
    refreshUnlocks(career);
    prepareWeek(career);
    migrated = true;
  }

  // v4 -> v5: central de mensagens. Nada é inventado sobre partidas passadas; só a central é ativada.
  if (career.version < 5 || !Array.isArray(career.inbox) || !Array.isArray(career.news) || !Array.isArray(career.social)) {
    if (career.version < 5) career.migratedFrom = career.migratedFrom ?? career.version;
    ensureComms(career);
    publish(career, { emails: [welcomeEmail(career, true)] }, { season: career.season.number, week: career.world.week });
    syncWeekEmail(career);
    migrated = true;
  }
  // v5 -> v6: eventos da carreira. Nada é inventado sobre partidas passadas: a lista começa vazia.
  if (career.version < 6 || !Array.isArray(career.events)) {
    if (career.version < 6) career.migratedFrom = career.migratedFrom ?? career.version;
    career.events = Array.isArray(career.events) ? career.events : [];
    migrated = true;
  }
  // v6 -> v7: prêmios de temporada. Nada é concedido retroativamente: a lista começa vazia.
  if (career.version < 7 || !Array.isArray(career.awards)) {
    if (career.version < 7) career.migratedFrom = career.migratedFrom ?? career.version;
    career.awards = Array.isArray(career.awards) ? career.awards : [];
    migrated = true;
  }
  career.version = CAREER_VERSION;
  return { career, migrated };
}

function newSeason(number, tier) {
  return { number, round: 0, tierAtStart: tier, matches: [] };
}

export function levelInfo(xp) {
  let idx = 0;
  for (let i = 0; i < LEVELS.length; i++) if (xp >= LEVELS[i].xp) idx = i;
  const cur = LEVELS[idx];
  const next = LEVELS[idx + 1] || null;
  return {
    level: idx + 1,
    title: cur.title,
    floor: cur.xp,
    next: next ? next.xp : null,
    ratio: next ? (xp - cur.xp) / (next.xp - cur.xp) : 1,
  };
}

export const unlockedCompetitions = (career) =>
  COMPETITIONS.filter((c) => career.unlocked.includes(c.id)).sort((a, b) => a.tier - b.tier);

// A divisão atual é a liga em que o árbitro está (muda por promoção ou rebaixamento, nunca por reputação sozinha).
export const currentDivision = (career) => LEAGUES[career.division];
export const highestTier = (career) => currentDivision(career).tier;

// Ligas: liberadas pela divisão atual. Copas: liberadas pela reputação e mantidas depois de conquistadas.
function refreshUnlocks(career) {
  const region = career.profile ? career.profile.region : null;
  const keep = new Set(
    career.unlocked.filter((id) => {
      const c = getCompetition(id);
      return c && !c.division;
    })
  );
  for (const c of COMPETITIONS) {
    if (c.division) {
      if (c.tier <= LEAGUES[career.division].tier) keep.add(c.id);
    } else if (career.rep >= unlockThreshold(c, region)) keep.add(c.id);
  }
  const added = COMPETITIONS.filter((c) => keep.has(c.id) && !career.unlocked.includes(c.id));
  career.unlocked = COMPETITIONS.filter((c) => keep.has(c.id)).map((c) => c.id);
  return added;
}

// ------------------------------------------------------------ convocações (calendário)
function prepareWeek(career) {
  const w = career.world;
  let eligible = career.unlocked.filter((id) => COMPETITIONS.some((c) => c.id === id));
  let restriction = null;
  // Suspensão de oportunidades (uma rodada): só jogos de importância 1. O motivo é mostrado ao jogador.
  const r = career.restricted;
  if (r && r.season === w.season && r.week === w.week) {
    const limited = eligible.filter((id) => getCompetition(id).importance === 1);
    if (limited.length) {
      eligible = limited;
      restriction = r.reason;
    }
  }
  w.offers = { week: w.week, items: buildOffers(w, eligible, career.seed), restriction };
  syncWeekEmail(career);
  // Convocações especiais (final, semifinal, clássico, última rodada): registro e e-mail, uma vez por jogo.
  const special = eventsForWeek(career);
  publish(career, special.bundle, { season: w.season, week: w.week });
}

// Convocações da semana, já com jogo, competição e clubes resolvidos para a interface.
export function getOffers(career) {
  const w = career.world;
  if (!w.offers || w.offers.week !== w.week) prepareWeek(career);
  return w.offers.items
    .map((item) => {
      const fixture = findFixture(w, item.fixtureId);
      if (!fixture) return null;
      return { ...item, fixture, competition: getCompetition(fixture.competitionId), home: getClub(fixture.home), away: getClub(fixture.away) };
    })
    .filter(Boolean);
}

// Jogo que pode ser iniciado agora: precisa estar entre as convocações aceitáveis da semana e ainda agendado.
export function startableFixture(career, fixtureId) {
  const item = career.world.offers.items.find((i) => i.fixtureId === fixtureId);
  const fixture = findFixture(career.world, fixtureId);
  if (!item || item.status !== 'offered' || !fixture || fixture.status !== 'scheduled' || fixture.week !== career.world.week) return null;
  return fixture;
}

// Recusar não custa nada: não há penalidade de reputação ou experiência.
export function declineOffer(career, fixtureId) {
  const item = career.world.offers.items.find((i) => i.fixtureId === fixtureId);
  if (!item || item.status !== 'offered') return false;
  item.status = 'declined';
  return true;
}

// Passa a rodada sem apitar: o calendário avança (todos os jogos são simulados), sem custo para a carreira.
export function skipWeek(career) {
  const summary = { skipped: true, week: career.world.week, xpGain: 0, repDelta: 0, newUnlocks: [], seasonEnded: null };
  for (const item of career.world.offers.items) if (item.status === 'offered') item.status = 'declined';
  career.skipped += 1;
  advanceWeek(career, summary);
  summary.objectivesDone = completeObjectives(career);
  summary.newUnlocks.push(...refreshUnlocks(career).map((c) => c.name));
  if (summary.objectivesDone.length) publish(career, commsForObjectives(career, summary.objectivesDone, { season: career.world.season, week: career.world.week }), { season: career.world.season, week: career.world.week });
  return summary;
}

function advanceWeek(career, summary) {
  const w = career.world;
  playWeek(w, career.seed, w.week);
  w.week += 1;
  if (w.week > WEEKS_PER_SEASON) closeSeason(career, summary);
  else prepareWeek(career);
}

// Fim da temporada: objetivos, promoção ou rebaixamento (com os motivos), campeões e novo calendário.
function closeSeason(career, summary) {
  const season = career.season;
  const objectives = evaluateObjectives(season, true);
  const stats = seasonStats(season);
  const met = objectives.filter((o) => o.met).length;
  const eligible = stats.played >= MIN_MATCHES_FOR_BONUS;
  const repBonus = eligible ? met * 2 + (met >= 2 && objectives[0].met ? 3 : 0) : 0;
  career.rep = clamp(round1(career.rep + repBonus), 0, 100);

  // Promoção e rebaixamento seguem critérios explícitos (ProgressionSystem) e usam a reputação já com o bônus.
  const avgTarget = objectiveDefs(season.tierAtStart)[0].target;
  const decision = decideSeason({ division: career.division, rep: career.rep, strikes: career.strikes || 0 }, stats, met, avgTarget);
  career.division = decision.division;
  career.strikes = decision.strikes;
  if (decision.repPenalty) career.rep = clamp(round1(career.rep - decision.repPenalty), 0, 100);
  career.xp += decision.xpBonus;
  summary.newUnlocks.push(...refreshUnlocks(career).map((c) => c.name));

  const avg = stats.avg === null ? null : round1(stats.avg);
  career.seasons = [
    ...(career.seasons || []),
    { number: season.number, division: decision.from, avg, played: stats.played, graves: stats.graves, met, repBonus, action: decision.action, to: decision.to, reason: decision.reason },
  ].slice(-SEASONS_LIMIT);

  const champs = seasonChampions(career.world);
  career.champions = [...career.champions, ...champs].slice(-CHAMPIONS_LIMIT);
  // Prêmios de temporada: critérios verificáveis sobre os jogos da temporada, XP entregue uma única vez.
  const awards = grantAwards(career, season.matches, season.number, { season: season.number, week: WEEKS_PER_SEASON });
  summary.seasonEnded = { number: season.number, avg, objectives, met, repBonus, played: stats.played, graves: stats.graves, eligible, champions: champs, division: decision, awards };

  publish(career, commsForSeason(career, summary.seasonEnded), { season: season.number, week: WEEKS_PER_SEASON });

  career.season = newSeason(season.number + 1, highestTier(career));
  career.world = createWorld(career.seed, season.number + 1);
  prepareWeek(career);
}

export function objectiveDefs(tier) {
  const avgTarget = round1(6 + 0.4 * tier);
  const bestTarget = tier >= 3 ? 8.5 : 8;
  return [
    { id: 'avg', text: `Média de notas de ${comma(avgTarget)} ou mais`, target: avgTarget },
    { id: 'noLow', text: 'Nenhuma partida com nota abaixo de 5,0' },
    { id: 'best', text: `Uma partida com nota ${comma(bestTarget)} ou mais`, target: bestTarget },
    { id: 'whistles', text: 'No máximo 3 apitos sem lance na temporada' },
  ];
}

export function evaluateObjectives(season, final = false) {
  const grades = season.matches.map((m) => m.nota);
  const avg = grades.length ? grades.reduce((a, b) => a + b, 0) / grades.length : null;
  const whistles = season.matches.reduce((acc, m) => acc + (m.whistles || 0), 0);

  return objectiveDefs(season.tierAtStart).map((d) => {
    let met;
    let status;
    let progress;
    if (d.id === 'avg') {
      met = avg !== null && avg >= d.target;
      status = final ? (met ? 'ok' : 'failed') : 'pending';
      progress = avg === null ? 'sem partidas ainda' : `média atual ${comma(avg)}`;
    } else if (d.id === 'noLow') {
      const low = grades.some((g) => g < 5);
      met = !low;
      status = low ? 'failed' : final ? 'ok' : 'pending';
      progress = low ? 'houve nota abaixo de 5,0' : 'sem notas baixas';
    } else if (d.id === 'best') {
      met = grades.some((g) => g >= d.target);
      status = met ? 'ok' : final ? 'failed' : 'pending';
      progress = met ? 'meta atingida' : 'ainda não atingida';
    } else {
      met = whistles <= 3;
      status = whistles > 3 ? 'failed' : final ? 'ok' : 'pending';
      progress = `${whistles} apito(s) sem lance`;
    }
    return { id: d.id, text: d.text, met, status, progress };
  });
}

function committeeNote(nota, categories) {
  const weakest = [...categories].sort((a, b) => a.ratio - b.ratio)[0];
  if (nota >= 8) return 'O comitê aprovou sua atuação. Convites mais importantes vão aparecer.';
  if (nota >= 6.5) return 'Atuação segura. Mantenha o nível para subir de divisão.';
  if (nota >= 5) return `O comitê pede atenção a: ${weakest.label.toLowerCase()}.`;
  return `Atuação abaixo do esperado. Foco em: ${weakest.label.toLowerCase()}. Uma partida ruim não define sua carreira.`;
}

// Resumo auditável do VAR guardado no registro da partida (decisão inicial, final e motivo de cada revisão).
function varRecord(reviews) {
  const list = Array.isArray(reviews) ? reviews : [];
  if (!list.length) return null;
  const f = varFacts(list);
  return {
    reviews: f.varReviews,
    kept: f.varKept,
    changed: f.varChanged,
    eligible: f.varEligible,
    fixed: f.varFixed,
    worsened: f.varWorsened,
    audit: list.slice(0, 8).map((r) => ({ clock: r.clock, period: r.period, label: r.label, eligible: !!r.eligible, kind: r.kind, initial: r.initial, final: r.final, reason: r.reason, finalCorrect: r.finalCorrect ?? null })),
  };
}

export function applyMatch(career, fixture, result) {
  // Idempotente: o mesmo jogo nunca é contabilizado duas vezes (experiência, reputação e histórico).
  if (!Array.isArray(career.processed)) career.processed = [];
  if (fixture.matchId && career.processed.includes(fixture.matchId)) return null;
  if (fixture.matchId) career.processed = [...career.processed, fixture.matchId].slice(-PROCESSED_LIMIT);

  const comp = getCompetition(fixture.competitionId);
  const home = getClub(fixture.homeId);
  const away = getClub(fixture.awayId);
  const importance = fixture.importance;
  const nota = result.nota;

  // Pressão do jogo, calculada ANTES de a partida entrar no histórico (só narrativa: não altera nota nem recompensas).
  const fx0 = fixture.fixtureId ? findFixture(career.world, fixture.fixtureId) : null;
  const pressure = matchContext(career, { competitionId: fixture.competitionId, homeId: fixture.homeId, awayId: fixture.awayId, stage: fx0 ? fx0.stage : '', week: career.world.week });

  const before = { xp: career.xp, rep: career.rep, level: levelInfo(career.xp) };

  // A nota da partida (avaliação técnica) é a mesma da tela de resultado; aqui ela só vira experiência e reputação.
  const graves = result.mistakes.filter((m) => m.severity >= GRAVE_SEVERITY).length;
  const xpInfo = xpBreakdown(nota, importance);
  const repInfo = repBreakdown(nota, importance, graves);
  const xpGain = xpInfo.xp;
  const repDelta = repInfo.delta;

  career.xp += xpGain;
  career.rep = clamp(round1(career.rep + repDelta), 0, 100);
  career.totalMatches += 1;
  career.season.round += 1;

  const record = {
    season: career.season.number,
    round: career.season.round,
    competition: comp ? comp.name : 'Partida',
    competitionId: fixture.competitionId || null,
    home: home ? home.name : '',
    away: away ? away.name : '',
    score: `${result.score.home} x ${result.score.away}`,
    nota,
    label: result.label,
    xp: xpGain,
    rep: repDelta,
    graves,
    whistles: result.counts.unnecessaryWhistles,
    errors: result.mistakes.length,
    duration: fixture.duration || null,
    matchId: fixture.matchId || null,
    fixtureId: fixture.fixtureId || null,
    week: career.world.week,
    extras: result.extras || null,
    context: contextSummary(pressure),
    var: varRecord(result.varReviews),
  };
  career.season.matches.push(record);
  career.history.unshift(record);
  career.history = career.history.slice(0, HISTORY_LIMIT);

  const summary = {
    xpGain,
    repDelta,
    before,
    after: null,
    leveledUp: false,
    newUnlocks: refreshUnlocks(career).map((c) => c.name),
    committeeNote: committeeNote(nota, result.categories),
    reasons: { xp: xpInfo.line, rep: repInfo.lines },
    graves,
    suspension: null,
    objectivesDone: [],
    seasonRound: career.season.round,
    seasonEnded: null,
  };

  // Calendário: registra o resultado real do jogo, fecha as convocações da semana e avança a rodada.
  const fx = fixture.fixtureId ? findFixture(career.world, fixture.fixtureId) : null;
  if (fx) {
    completeFixture(career.world, fx, { home: result.score.home, away: result.score.away }, { referee: career.name, nota, duration: fixture.duration || null }, career.seed);
    for (const item of career.world.offers.items) {
      if (item.fixtureId === fx.id) item.status = 'taken';
      else if (item.status === 'offered') item.status = 'unavailable';
    }
  }
  summary.week = career.world.week;
  advanceWeek(career, summary);

  // Suspensão de oportunidades (só por uma rodada): erros muito graves ou duas notas muito baixas seguidas.
  const reason = suspensionFor({ graves, nota, previousNota: career.history[1] ? career.history[1].nota : undefined });
  if (reason) {
    career.restricted = { season: career.world.season, week: career.world.week, reason };
    prepareWeek(career);
    summary.suspension = reason;
  }

  // Objetivos de carreira concluídos (recompensa entregue uma única vez) e estado final.
  summary.objectivesDone = completeObjectives(career);
  summary.newUnlocks.push(...refreshUnlocks(career).map((c) => c.name));
  summary.after = { xp: career.xp, rep: career.rep, level: levelInfo(career.xp) };
  summary.leveledUp = summary.after.level.level > before.level.level;

  // Notícias, e-mails e publicações da partida, a partir dos fatos registrados.
  const ctx = {
    matchId: fixture.matchId || fixture.fixtureId || `m${career.totalMatches}`,
    fixtureId: fixture.fixtureId || null,
    competitionId: fixture.competitionId,
    competition: comp ? comp.name : 'Partida',
    stage: fx ? fx.stage : '',
    stadium: fx ? fx.stadium : '',
    home: { id: fixture.homeId, name: home ? home.name : '' },
    away: { id: fixture.awayId, name: away ? away.name : '' },
    score: result.score,
    nota,
    label: result.label,
    categories: result.categories || [],
    mistakes: result.mistakes || [],
    hits: result.hits || [],
    facts: { ...EMPTY_FACTS, ...(result.extras || {}) },
    graves,
    summary,
    season: record.season,
    week: record.week,
  };
  const date = { season: record.season, week: record.week };
  summary.comms = publish(career, commsForMatch(career, ctx), date);

  // Eventos especiais: pressão, revisão técnica, reconhecimento e críticas públicas (só narrativa, sem punição).
  const evm = eventsForMatch(career, ctx, pressure);
  publish(career, evm.bundle, date);
  const crit = criticismEvent(career, ctx);
  publish(career, crit.bundle, date);
  summary.events = [...evm.events, ...crit.events];
  summary.pressure = pressure;
  return summary;
}
