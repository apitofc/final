import Phaser from 'phaser';

export default class Controls {
  constructor(scene) {
    const kb = scene.input.keyboard;
    this.cursors = kb.createCursorKeys();
    this.keys = kb.addKeys('W,A,S,D');
    this.actionKeys = kb.addKeys({
      whistle: 'SPACE',
      foul: 'F',
      yellow: 'ONE',
      red: 'TWO',
      advantage: 'V',
      annulGoal: 'G',
      var: 'R',
      pause: 'ESC',
      menu: 'M',
      mute: 'N',
    });
  }

  getMove() {
    let x = 0;
    let y = 0;
    if (this.cursors.left.isDown || this.keys.A.isDown) x -= 1;
    if (this.cursors.right.isDown || this.keys.D.isDown) x += 1;
    if (this.cursors.up.isDown || this.keys.W.isDown) y -= 1;
    if (this.cursors.down.isDown || this.keys.S.isDown) y += 1;
    return { x, y };
  }

  getActions() {
    const out = {};
    for (const name of Object.keys(this.actionKeys)) {
      out[name] = Phaser.Input.Keyboard.JustDown(this.actionKeys[name]);
    }
    return out;
  }
}
