// Calendário, resultados e classificação das competições. Funções puras e determinísticas:
// a mesma semente gera sempre o mesmo calendário e os mesmos placares dos jogos que o jogador não apita.
import { COMPETITIONS, getCompetition, getClub, stadiumOf } from '../data/competitions.js';
import { makeRng, hashString } from '../utils/rng.js';

// Cada temporada tem 5 rodadas: as ligas (6 clubes, turno único) jogam uma rodada por semana.
export const WEEKS_PER_SEASON = 5;

export const FIXTURE_STATUS = {
  scheduled: 'Agendada',
  assigned: 'Convocação recebida',
  completed: 'Concluída',
  cancelled: 'Cancelada',
  unavailable: 'Indisponível',
};

const rngFor = (...parts) => makeRng(hashString(parts.join(':')));
export const clubStrength = (clubId) => 40 + (hashString(`strength:${clubId}`) % 41); // 40 a 80

function shuffle(list, rng) {
  const a = [...list];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng.frac() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// Método do círculo: cada clube enfrenta todos os outros uma vez; cada rodada tem metade dos clubes em campo.
export function roundRobin(ids) {
  const list = [...ids];
  if (list.length % 2) list.push(null);
  const m = list.length;
  const rounds = [];
  for (let r = 0; r < m - 1; r++) {
    const pairs = [];
    for (let i = 0; i < m / 2; i++) {
      const a = list[i];
      const b = list[m - 1 - i];
      if (a !== null && b !== null) pairs.push(r % 2 === 0 ? [a, b] : [b, a]);
    }
    rounds.push(pairs);
    list.splice(1, 0, list.pop());
  }
  return rounds;
}

function makeFixture(comp, season, key, week, home, away, importance, stage) {
  return {
    id: `${comp.id}:s${season}:${key}`,
    competitionId: comp.id,
    week,
    stage,
    home,
    away,
    stadium: stadiumOf(getClub(home)),
    importance,
    status: 'scheduled',
    result: null,
    referee: null,
  };
}

function buildLeague(comp, season, seed) {
  const rng = rngFor(seed, 'league', comp.id, season);
  const clubs = shuffle(comp.clubs.map((c) => c.id), rng);
  const fixtures = [];
  roundRobin(clubs).forEach((pairs, ri) =>
    pairs.forEach(([h, a], i) => fixtures.push(makeFixture(comp, season, `r${ri + 1}-${i + 1}`, ri + 1, h, a, comp.importance, `Rodada ${ri + 1}`)))
  );
  return { id: comp.id, format: 'league', clubs, fixtures, champion: null };
}

function addCupRound(state, comp, season, stageIndex, participants) {
  const stage = comp.stages[stageIndex];
  for (let i = 0; i < participants.length; i += 2) {
    state.fixtures.push(makeFixture(comp, season, `f${stageIndex + 1}-${i / 2 + 1}`, stage.week, participants[i], participants[i + 1], stage.importance, stage.name));
  }
  state.stageIndex = stageIndex;
}

function buildCup(comp, season, seed) {
  const rng = rngFor(seed, 'cup', comp.id, season);
  const size = 2 ** comp.stages.length;
  const pool = comp.pool === 'leagues' ? COMPETITIONS.filter((c) => c.format === 'league').flatMap((c) => c.clubs.map((k) => k.id)) : comp.clubs.map((c) => c.id);
  const clubs = shuffle(pool, rng).slice(0, size);
  const state = { id: comp.id, format: 'cup', clubs, fixtures: [], stageIndex: 0, champion: null };
  addCupRound(state, comp, season, 0, clubs);
  return state;
}

export function createWorld(seed, season) {
  const competitions = {};
  for (const comp of COMPETITIONS) competitions[comp.id] = comp.format === 'cup' ? buildCup(comp, season, seed) : buildLeague(comp, season, seed);
  return { season, week: 1, competitions, offers: { week: 0, items: [] } };
}

export function isValidWorld(w) {
  return !!(w && typeof w === 'object' && Number.isFinite(w.week) && Number.isFinite(w.season) && w.competitions && typeof w.competitions === 'object' && COMPETITIONS.every((c) => w.competitions[c.id] && Array.isArray(w.competitions[c.id].fixtures)));
}

export function findFixture(world, id) {
  for (const state of Object.values(world.competitions)) {
    const f = state.fixtures.find((x) => x.id === id);
    if (f) return f;
  }
  return null;
}

export const weekFixtures = (world, week) =>
  Object.values(world.competitions).flatMap((s) => s.fixtures.filter((f) => f.week === week));

// ------------------------------------------------------------ resultados
function poisson(lambda, rng) {
  const limit = Math.exp(-lambda);
  let k = 0;
  let p = 1;
  do {
    k += 1;
    p *= rng.frac();
  } while (p > limit && k < 9);
  return k - 1;
}

export function simulateScore(seed, fixture) {
  const rng = rngFor(seed, 'score', fixture.id);
  const h = clubStrength(fixture.home) + 4; // vantagem de jogar em casa
  const a = clubStrength(fixture.away);
  const lamH = Math.min(3.2, Math.max(0.35, 1.3 * Math.exp((h - a) / 60)));
  const lamA = Math.min(3.2, Math.max(0.35, 1.1 * Math.exp((a - h) / 60)));
  return { home: poisson(lamH, rng), away: poisson(lamA, rng) };
}

// Pênaltis decididos com a semente; favorece (pouco) o clube mais forte.
function penaltyShootout(seed, fixture) {
  const rng = rngFor(seed, 'pens', fixture.id);
  const pHome = 0.5 + (clubStrength(fixture.home) - clubStrength(fixture.away)) / 400;
  const homeWins = rng.frac() < pHome;
  const loser = 2 + Math.floor(rng.frac() * 3);
  return homeWins ? [loser + 1, loser] : [loser, loser + 1];
}

export function winnerOf(fixture) {
  const r = fixture.result;
  if (!r) return null;
  if (r.home !== r.away) return r.home > r.away ? fixture.home : fixture.away;
  if (r.pens) return r.pens[0] > r.pens[1] ? fixture.home : fixture.away;
  return null;
}

// Registra o resultado de um jogo. Em copas, empate vai para os pênaltis.
export function completeFixture(world, fixture, score, extra, seed) {
  if (fixture.status === 'completed') return false;
  const comp = getCompetition(fixture.competitionId);
  fixture.status = 'completed';
  fixture.result = { home: score.home, away: score.away };
  if (comp.format === 'cup' && score.home === score.away) fixture.result.pens = penaltyShootout(seed, fixture);
  if (extra && extra.referee) fixture.referee = { name: extra.referee, nota: extra.nota ?? null, duration: extra.duration ?? null };
  return true;
}

// Quando todos os jogos da fase terminam, sorteia a próxima fase ou define o campeão.
function advanceCups(world) {
  for (const comp of COMPETITIONS) {
    if (comp.format !== 'cup') continue;
    const state = world.competitions[comp.id];
    if (state.champion) continue;
    const stageFixtures = state.fixtures.filter((f) => f.stage === comp.stages[state.stageIndex].name);
    if (!stageFixtures.length || !stageFixtures.every((f) => f.status === 'completed')) continue;
    const winners = stageFixtures.map(winnerOf);
    if (state.stageIndex === comp.stages.length - 1) state.champion = winners[0];
    else addCupRound(state, comp, world.season, state.stageIndex + 1, winners);
  }
}

// Simula todos os jogos da semana que ainda não foram decididos (os que o jogador não apitou).
export function playWeek(world, seed, week) {
  const simulated = [];
  for (const state of Object.values(world.competitions)) {
    for (const f of state.fixtures) {
      if (f.week === week && f.status !== 'completed') {
        completeFixture(world, f, simulateScore(seed, f), null, seed);
        simulated.push(f);
      }
    }
  }
  advanceCups(world);
  return simulated;
}

// ------------------------------------------------------------ classificação
export function leagueStandings(state) {
  const rows = new Map(state.clubs.map((id) => [id, { id, name: getClub(id).name, played: 0, wins: 0, draws: 0, losses: 0, gf: 0, ga: 0, gd: 0, pts: 0 }]));
  for (const f of state.fixtures) {
    if (f.status !== 'completed') continue;
    const h = rows.get(f.home);
    const a = rows.get(f.away);
    h.played++;
    a.played++;
    h.gf += f.result.home;
    h.ga += f.result.away;
    a.gf += f.result.away;
    a.ga += f.result.home;
    if (f.result.home > f.result.away) {
      h.wins++;
      a.losses++;
      h.pts += 3;
    } else if (f.result.home < f.result.away) {
      a.wins++;
      h.losses++;
      a.pts += 3;
    } else {
      h.draws++;
      a.draws++;
      h.pts++;
      a.pts++;
    }
  }
  const list = [...rows.values()];
  for (const r of list) r.gd = r.gf - r.ga;
  // Critérios: pontos, saldo de gols, gols marcados e, por fim, ordem alfabética (estável e reproduzível).
  return list.sort((x, y) => y.pts - x.pts || y.gd - x.gd || y.gf - x.gf || x.name.localeCompare(y.name, 'pt-BR'));
}

// Campeões da temporada: liga só quando todos os jogos terminaram; copa quando a final foi decidida.
export function seasonChampions(world) {
  const out = [];
  for (const comp of COMPETITIONS) {
    const state = world.competitions[comp.id];
    if (comp.format === 'league') {
      if (state.fixtures.length && state.fixtures.every((f) => f.status === 'completed')) out.push({ season: world.season, competitionId: comp.id, clubId: leagueStandings(state)[0].id });
    } else if (state.champion) {
      out.push({ season: world.season, competitionId: comp.id, clubId: state.champion });
    }
  }
  return out;
}

// ------------------------------------------------------------ convocações da semana
// Até 3 jogos de competições liberadas: um seguro (divisão menor), um importante e um intermediário.
export function buildOffers(world, eligibleIds, seed) {
  const cands = [];
  for (const id of eligibleIds) {
    const state = world.competitions[id];
    if (!state) continue;
    for (const f of state.fixtures) if (f.week === world.week && f.status === 'scheduled') cands.push(f);
  }
  if (!cands.length) return [];

  const tierOf = (f) => getCompetition(f.competitionId).tier;
  const safe = [...cands].sort((a, b) => tierOf(a) - tierOf(b) || a.importance - b.importance || a.id.localeCompare(b.id));
  const big = [...cands].sort((a, b) => b.importance - a.importance || tierOf(b) - tierOf(a) || a.id.localeCompare(b.id));

  const picks = [];
  const take = (list, tag) => {
    const f = list.find((x) => !picks.some((p) => p.fixtureId === x.id));
    if (f) picks.push({ fixtureId: f.id, tag, status: 'offered' });
  };
  take(safe, 'Segura');
  take(big, 'Importante');
  const rng = rngFor(seed, 'offers', world.season, world.week);
  const rest = cands.filter((f) => !picks.some((p) => p.fixtureId === f.id));
  if (rest.length) take([rest[Math.floor(rng.frac() * rest.length)]], 'Equilibrada');

  const order = { Segura: 0, Equilibrada: 1, Importante: 2 };
  return picks.sort((a, b) => order[a.tag] - order[b.tag]);
}
