import test from 'node:test';
import assert from 'node:assert/strict';
import { createWorld, playWeek, leagueStandings, seasonChampions, buildOffers, roundRobin, findFixture, winnerOf, WEEKS_PER_SEASON } from '../src/systems/CalendarSystem.js';
import { COMPETITIONS, unlockThreshold, getCompetition } from '../src/data/competitions.js';
import {
  createCareer, migrateCareer, applyMatch, getOffers, startableFixture, declineOffer, skipWeek, currentDivision, SEASON_ROUNDS, CAREER_VERSION,
} from '../src/systems/CareerSystem.js';

const report = (nota) => ({ nota, label: 'x', categories: [{ label: 'Cartões', ratio: 0.5 }], mistakes: [], counts: { unnecessaryWhistles: 0 }, score: { home: 2, away: 1 } });
const play = (career, offerIndex, nota = 7, id = `m${career.totalMatches}`) => {
  const o = getOffers(career)[offerIndex];
  const f = o.fixture;
  return applyMatch(career, { competitionId: f.competitionId, homeId: f.home, awayId: f.away, importance: f.importance, fixtureId: f.id, matchId: id, duration: 'quick' }, report(nota));
};

test('turno único: todos os clubes se enfrentam uma vez e jogam toda rodada', () => {
  const ids = ['a', 'b', 'c', 'd', 'e', 'f'];
  const rounds = roundRobin(ids);
  assert.equal(rounds.length, 5);
  const seen = new Set();
  for (const pairs of rounds) {
    assert.equal(pairs.length, 3);
    assert.equal(new Set(pairs.flat()).size, 6, 'cada clube joga uma vez por rodada');
    for (const [h, a] of pairs) seen.add([h, a].sort().join('|'));
  }
  assert.equal(seen.size, 15);
});

test('calendário é determinístico e cobre todas as competições', () => {
  const a = createWorld(99, 1);
  const b = createWorld(99, 1);
  assert.deepEqual(a, b);
  assert.notDeepEqual(createWorld(100, 1).competitions.varzea.fixtures.map((f) => f.home), a.competitions.varzea.fixtures.map((f) => f.home));
  assert.equal(Object.keys(a.competitions).length, COMPETITIONS.length);
  for (const f of a.competitions.varzea.fixtures) {
    assert.ok(f.id && f.stadium && f.importance >= 1 && f.week >= 1 && f.week <= WEEKS_PER_SEASON);
    assert.equal(f.status, 'scheduled');
  }
});

test('simular a rodada é idempotente e a tabela fecha (jogos, gols e pontos)', () => {
  const w = createWorld(5, 1);
  for (let wk = 1; wk <= WEEKS_PER_SEASON; wk++) playWeek(w, 5, wk);
  const snapshot = JSON.stringify(w);
  for (let wk = 1; wk <= WEEKS_PER_SEASON; wk++) playWeek(w, 5, wk);
  assert.equal(JSON.stringify(w), snapshot);

  const table = leagueStandings(w.competitions.varzea);
  assert.equal(table.reduce((n, r) => n + r.played, 0), 30);
  assert.equal(table.reduce((n, r) => n + r.gf, 0), table.reduce((n, r) => n + r.ga, 0));
  for (const r of table) {
    assert.equal(r.pts, r.wins * 3 + r.draws);
    assert.equal(r.played, 5);
  }
  for (let i = 1; i < table.length; i++) assert.ok(table[i - 1].pts >= table[i].pts, 'ordenada por pontos');
});

test('copas: fases só aparecem após a anterior, empate vai aos pênaltis e há campeão', () => {
  const w = createWorld(21, 1);
  const cup = w.competitions.copanacional;
  assert.equal(cup.fixtures.length, 4, 'só as quartas existem no início');
  playWeek(w, 21, 1);
  playWeek(w, 21, 2);
  assert.equal(cup.fixtures.length, 6, 'semifinais criadas depois das quartas');
  for (const f of cup.fixtures.filter((x) => x.status === 'completed')) {
    if (f.result.home === f.result.away) assert.ok(f.result.pens && f.result.pens[0] !== f.result.pens[1]);
    assert.ok(winnerOf(f));
  }
  assert.equal(cup.champion, null);
  playWeek(w, 21, 3);
  playWeek(w, 21, 4);
  assert.equal(cup.fixtures.length, 7);
  playWeek(w, 21, 5);
  assert.ok(cup.champion, 'campeão definido só depois da final');
  assert.equal(seasonChampions(w).length, COMPETITIONS.length);
});

test('convocações: até 3, distintas, da semana atual e só de competições liberadas', () => {
  const c = createCareer('T', 8);
  const offers = getOffers(c);
  assert.ok(offers.length >= 2 && offers.length <= 3);
  assert.equal(new Set(offers.map((o) => o.fixture.id)).size, offers.length);
  for (const o of offers) {
    assert.equal(o.fixture.week, c.world.week);
    assert.ok(c.unlocked.includes(o.competition.id));
    assert.equal(o.status, 'offered');
  }
  const all = Object.values(c.world.competitions).flatMap((s) => s.fixtures).filter((f) => f.week === 1);
  assert.ok(buildOffers(c.world, ['copanacional'], 8).length === 0, 'copa nacional não tem jogo na rodada 1');
  assert.ok(all.length > offers.length);
});

test('jogo apitado: calendário recebe o resultado real e a rodada avança', () => {
  const c = createCareer('T', 8);
  const o = getOffers(c)[0];
  const id = o.fixture.id;
  const s = play(c, 0, 8);
  assert.ok(s);
  assert.equal(c.world.week, 2);
  const fx = findFixture(c.world, id);
  assert.equal(fx.status, 'completed');
  assert.deepEqual(fx.result, { home: 2, away: 1 });
  assert.equal(fx.referee.name, 'T');
  assert.equal(startableFixture(c, id), null, 'não pode iniciar de novo');
  assert.equal(c.history[0].fixtureId, id);
  const week2 = getOffers(c);
  assert.ok(week2.every((x) => x.fixture.week === 2));
});

test('recusar e pular a rodada não custam experiência nem reputação', () => {
  const c = createCareer('T', 8);
  const [a] = getOffers(c);
  assert.ok(declineOffer(c, a.fixture.id));
  assert.equal(declineOffer(c, a.fixture.id), false);
  assert.equal(startableFixture(c, a.fixture.id), null, 'recusada não inicia');
  const before = { xp: c.xp, rep: c.rep, played: c.totalMatches };
  const s = skipWeek(c);
  assert.ok(s.skipped);
  assert.equal(c.world.week, 2);
  assert.equal(c.skipped, 1);
  assert.deepEqual({ xp: c.xp, rep: c.rep, played: c.totalMatches }, before);
});

test('fim de temporada: campeões, nova temporada e bônus só com 3 jogos ou mais', () => {
  const idle = createCareer('Parado', 3);
  let end = null;
  for (let i = 0; i < SEASON_ROUNDS; i++) end = skipWeek(idle).seasonEnded || end;
  assert.ok(end && end.eligible === false && end.repBonus === 0);
  assert.equal(idle.season.number, 2);
  assert.equal(idle.world.week, 1);
  assert.equal(idle.champions.length, COMPETITIONS.length);

  const busy = createCareer('Ativo', 3);
  let busyEnd = null;
  for (let i = 0; i < SEASON_ROUNDS; i++) busyEnd = play(busy, 0, 7.5).seasonEnded || busyEnd;
  assert.ok(busyEnd.eligible && busyEnd.played === SEASON_ROUNDS && busyEnd.repBonus > 0);
  assert.equal(busy.season.number, 2);
});

test('região: competição regional exige 15 de reputação a mais de quem é de outra região', () => {
  const cup = getCompetition('copanorte');
  assert.equal(unlockThreshold(cup, 'norte'), cup.unlockRep);
  assert.equal(unlockThreshold(cup, 'sul'), cup.unlockRep + 15);
  assert.equal(unlockThreshold(getCompetition('varzea'), 'sul'), 0);
});

test('a divisão atual considera só as ligas (copas não contam)', () => {
  const c = createCareer({ name: 'x', region: 'norte' }, 1);
  c.rep = 22; // libera a Copa Norte e a Liga Regional
  for (let i = 0; i < 1; i++) play(c, 0, 6);
  assert.ok(c.unlocked.includes('copanorte'));
  assert.equal(currentDivision(c).format, 'league');
});

test('migração v2 -> v3 monta o calendário a partir do progresso da temporada', () => {
  const v3 = createCareer('Antigo', 12);
  const v2 = JSON.parse(JSON.stringify(v3));
  delete v2.world;
  delete v2.skipped;
  delete v2.champions;
  v2.version = 2;
  v2.season.round = 2;
  v2.invitations = [{ id: 'x' }];
  const r = migrateCareer(v2);
  assert.ok(r.migrated);
  assert.equal(r.career.version, CAREER_VERSION);
  assert.equal(r.career.world.week, 3);
  assert.equal(r.career.world.season, v2.season.number);
  const done = r.career.world.competitions.varzea.fixtures.filter((f) => f.week < 3);
  assert.ok(done.length === 6 && done.every((f) => f.status === 'completed'));
  assert.deepEqual(r.career.invitations, [{ id: 'x' }], 'campo antigo preservado');
  assert.ok(getOffers(r.career).length >= 1);
  // migrar de novo não muda nada
  assert.deepEqual(migrateCareer(JSON.parse(JSON.stringify(r.career))).career.world, r.career.world);
});
