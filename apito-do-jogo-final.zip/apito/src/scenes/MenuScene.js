import Phaser from 'phaser';
import { COMPETITIONS, getClub, getCompetition, clubCount, unlockThreshold } from '../data/competitions.js';
import { leagueStandings, findFixture, WEEKS_PER_SEASON } from '../systems/CalendarSystem.js';
import {
  LEAGUES,
  PROMOTION,
  DEMOTION,
  seasonStats,
  promotionCriteria,
  careerObjectives,
  unseenObjectives,
  markObjectivesSeen,
} from '../systems/ProgressionSystem.js';
import { DURATIONS, getDuration } from '../config.js';
import { REFEREE_LOOKS, REGIONS, DEFAULT_PROFILE, getLook, getRegion } from '../data/referees.js';
import { lookPreviewUrl } from '../utils/pixelTextures.js';
import { isMuted, toggleMuted, playBlip } from '../utils/audio.js';
import { unreadCount, setRead, markAllRead, publicImage } from '../systems/CommsSystem.js';
import { matchContext } from '../systems/ContextSystem.js';
import { awardStatus, unseenAwards, markAwardsSeen, AWARD_XP } from '../systems/AwardsSystem.js';
import {
  createCareer,
  sanitizeProfile,
  getOffers,
  startableFixture,
  declineOffer,
  skipWeek,
  currentDivision,
  levelInfo,
  unlockedCompetitions,
  evaluateObjectives,
  objectiveDefs,
  SEASON_ROUNDS,
  comma,
} from '../systems/CareerSystem.js';
import { loadCareerResult, saveCareer, clearCareer, backupCurrentCareer, loadSettings, saveSettings } from '../utils/storage.js';

const TABS = [
  { id: 'overview', label: 'Visão geral' },
  { id: 'offers', label: 'Convocações' },
  { id: 'calendar', label: 'Calendário' },
  { id: 'standings', label: 'Classificação' },
  { id: 'news', label: 'Notícias' },
  { id: 'inbox', label: 'E-mails' },
  { id: 'social', label: 'Rede social' },
  { id: 'stats', label: 'Estatísticas' },
  { id: 'objectives', label: 'Objetivos' },
  { id: 'awards', label: 'Prêmios' },
  { id: 'events', label: 'Eventos' },
  { id: 'history', label: 'Histórico' },
  { id: 'comps', label: 'Competições' },
];
const HELP_TABS = [
  { id: 'controls', label: 'Controles' },
  { id: 'fouls', label: 'Faltas e cartões' },
  { id: 'grade', label: 'Nota e carreira' },
  { id: 'progress', label: 'Promoção e reputação' },
];
const stars = (n) => '★'.repeat(n) + '☆'.repeat(3 - n);
const statusIcon = { ok: '✓', failed: '✗', pending: '…' };

export default class MenuScene extends Phaser.Scene {
  constructor() {
    super('MenuScene');
  }

  init(data) {
    this.startScreen = data && data.screen ? data.screen : 'main';
  }

  create() {
    this.cameras.main.setBackgroundColor('#0e1a2b');
    const loaded = loadCareerResult();
    this.career = loaded.career;
    this.loadStatus = loaded;
    this.settings = loadSettings();
    this.draft = { ...DEFAULT_PROFILE };
    this.previews = {};
    this.backTo = 'main';
    this.mailId = null;
    this.newsTone = 'all';
    this.socialTag = 'all';
    this.detail = null;
    this.calComp = null;
    this.stComp = null;
    this.notice =
      loaded.status === 'migrated'
        ? { kind: 'ok', text: 'Sua carreira foi atualizada para a nova versão. Uma cópia de segurança ficou guardada no navegador.' }
        : null;
    this.tab = 'overview';
    this.helpTab = 'controls';

    this.root = document.createElement('div');
    this.root.id = 'menu-panel';
    document.body.appendChild(this.root);

    this.root.addEventListener('mousedown', (e) => {
      if (e.target.tagName !== 'INPUT') e.preventDefault();
    });
    this.root.addEventListener('click', (e) => this.onClick(e));
    this.root.addEventListener('input', (e) => {
      if (e.target.dataset && e.target.dataset.field === 'name') this.draft.name = e.target.value;
    });
    this.root.addEventListener('keydown', (e) => {

      e.stopPropagation();
      if (e.key === 'Enter' && e.target.tagName === 'INPUT') this.createNewCareer();
    });

    const kb = this.input.keyboard;
    kb.on('keydown-ONE', () => this.shortcut(0));
    kb.on('keydown-TWO', () => this.shortcut(1));
    kb.on('keydown-THREE', () => this.shortcut(2));
    kb.on('keydown-ESC', () => this.show('main'));

    this.events.once('shutdown', () => this.root.remove());
    this.show(this.startScreen === 'career' && this.career ? 'career' : 'main');
  }

  shortcut(index) {
    if (this.screen === 'career' && this.tab === 'offers') {
      const offer = getOffers(this.career)[index];
      if (offer) this.accept(offer.fixture.id);
    }
  }

  show(screen) {
    this.screen = screen;
    let html;
    if (screen === 'main') html = this.renderMain();
    else if (screen === 'new') html = this.renderNew();
    else if (screen === 'help') html = this.renderHelp();
    else if (screen === 'settings') html = this.renderSettings();
    else if (screen === 'prep') html = this.renderPrep();
    else html = this.renderCareer();
    this.root.innerHTML = html;

    if (this.notice) {
      const box = this.root.querySelector('.mn-box');
      if (box) {
        const note = document.createElement('div');
        note.className = `mn-notice ${this.notice.kind}`;
        note.textContent = this.notice.text;
        box.prepend(note);
      }
      this.notice = null;
    }
    const input = this.root.querySelector('input');
    if (input) input.focus();
  }

  onClick(e) {
    const btn = e.target.closest('button');
    if (!btn) return;
    const { action, tab, help, id, view, from } = btn.dataset;

    if (help) {
      this.helpTab = help;
      this.show('help');
    } else if (tab) {
      this.tab = tab;
      if (tab === 'objectives') {
        this.fresh = new Set(this.career.objectives.filter((o) => o.status === 'done' && !o.seen).map((o) => o.id));
        if (markObjectivesSeen(this.career)) saveCareer(this.career);
      }
      if (tab === 'awards' && markAwardsSeen(this.career)) saveCareer(this.career);
      this.show('career');
    } else if (action === 'continue') this.show('career');
    else if (action === 'new') this.show('new');
    else if (action === 'create') this.createNewCareer();
    else if (action === 'quick') this.show('prep');
    else if (action === 'startquick') this.scene.start('MatchScene', { mode: 'quick', duration: this.settings.duration });
    else if (action === 'settings') {
      this.backTo = from === 'career' ? 'career' : 'main';
      this.show('settings');
    } else if (action === 'back') this.show(this.backTo === 'career' && this.career ? 'career' : 'main');
    else if (action === 'duration') this.setDuration(id);
    else if (action === 'sound') {
      toggleMuted();
      playBlip();
      this.show('settings');
    } else if (action === 'look') this.pickDraft('look', Number(id));
    else if (action === 'region') this.pickDraft('region', id);
    else if (action === 'save') this.saveNow();
    else if (action === 'help') {
      this.helpTab = 'controls';
      this.show('help');
    } else if (action === 'main') this.show('main');
    else if (action === 'accept') this.accept(id);
    else if (action === 'decline') this.decline(id);
    else if (action === 'skip') this.skip();
    else if (action === 'fixture') {
      this.detail = this.detail === id ? null : id;
      this.show('career');
    } else if (action === 'mail') {
      this.mailId = id;
      if (setRead(this.career, id, true)) saveCareer(this.career);
      this.show('career');
    } else if (action === 'mailback') {
      this.mailId = null;
      this.show('career');
    } else if (action === 'mailtoggle') {
      const m = this.career.inbox.find((x) => x.id === id);
      if (m) setRead(this.career, id, !m.read);
      saveCareer(this.career);
      this.show('career');
    } else if (action === 'readall') {
      markAllRead(this.career);
      this.persist('Todas as mensagens foram marcadas como lidas.');
      this.show('career');
    } else if (action === 'filter') {
      if (view === 'news') this.newsTone = id;
      else this.socialTag = id;
      this.show('career');
    } else if (action === 'pickcomp') {
      if (view === 'calendar') this.calComp = id;
      else this.stComp = id;
      this.detail = null;
      this.show('career');
    } else if (action === 'erase') {
      if (window.confirm('Apagar a carreira atual? Uma cópia de segurança fica guardada no navegador, mas a carreira some do menu.')) {
        clearCareer();
        this.career = null;
        this.show('main');
      }
    }
  }

  // Escolha de aparência ou região na criação: só troca o destaque, sem refazer a tela (o nome digitado é mantido).
  pickDraft(field, value) {
    this.draft[field] = value;
    const action = field === 'look' ? 'look' : 'region';
    for (const b of this.root.querySelectorAll(`[data-action="${action}"]`)) {
      const selected = field === 'look' ? Number(b.dataset.id) === value : b.dataset.id === value;
      b.classList.toggle('sel', selected);
    }
    const info = this.root.querySelector('[data-role="draft-summary"]');
    if (info) info.textContent = this.draftSummary();
  }

  draftSummary() {
    return `${getLook(this.draft.look).name} · ${getRegion(this.draft.region).name}`;
  }

  setDuration(id) {
    this.settings = { ...this.settings, duration: getDuration(id).id };
    const ok = saveSettings(this.settings);
    this.notice = ok
      ? { kind: 'ok', text: `Duração das próximas partidas: ${getDuration(id).label}.` }
      : { kind: 'bad', text: 'Não foi possível salvar a preferência neste navegador.' };
    this.show(this.screen);
  }

  saveNow() {
    if (!this.career) return;
    const ok = saveCareer(this.career);
    const time = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    this.notice = ok
      ? { kind: 'ok', text: `Carreira salva às ${time}.` }
      : { kind: 'bad', text: 'Não foi possível salvar a carreira neste navegador. Ela continua em memória até você sair.' };
    this.show('career');
  }

  createNewCareer() {
    const input = this.root.querySelector('[data-field="name"]');
    if (input) this.draft.name = input.value;
    const profile = sanitizeProfile(this.draft);

    backupCurrentCareer();
    this.career = createCareer(profile);
    const ok = saveCareer(this.career);

    this.draft = { ...DEFAULT_PROFILE };
    this.tab = 'overview';
    this.notice = ok
      ? { kind: 'ok', text: 'Carreira criada e salva.' }
      : { kind: 'bad', text: 'Carreira criada, mas não foi possível salvar neste navegador.' };
    this.show('career');
  }

  accept(fixtureId) {
    const c = this.career;
    const fx = c && startableFixture(c, fixtureId);
    if (!fx) {
      this.notice = { kind: 'bad', text: 'Esse jogo não pode mais ser iniciado (já foi concluído, recusado ou a rodada mudou).' };
      this.show('career');
      return;
    }
    this.scene.start('MatchScene', {
      mode: 'career',
      duration: this.settings.duration,
      fixture: {
        competitionId: fx.competitionId,
        home: getClub(fx.home),
        away: getClub(fx.away),
        importance: fx.importance,
        seed: `${c.seed}:${fx.id}`,
        fixtureId: fx.id,
        stadium: fx.stadium,
      },
    });
  }

  persist(okText) {
    const ok = saveCareer(this.career);
    this.notice = ok ? { kind: 'ok', text: okText } : { kind: 'bad', text: 'Não foi possível salvar neste navegador. A mudança vale só até você sair.' };
  }

  decline(fixtureId) {
    if (declineOffer(this.career, fixtureId)) this.persist('Convocação recusada. Sem custo para a sua carreira.');
    this.show('career');
  }

  skip() {
    const s = skipWeek(this.career);
    let text = 'Rodada passada sem apitar: todos os jogos foram simulados. Sem custo para a carreira.';
    if (s.seasonEnded) text = `Temporada ${s.seasonEnded.number} encerrada. ${s.seasonEnded.eligible ? '' : 'Poucos jogos apitados: sem bônus de reputação. '}Nova temporada começando.`;
    this.persist(text);
    this.detail = null;
    this.show('career');
  }

  renderMain() {
    const c = this.career;
    const cont = c
      ? `<button class="mn-btn primary" data-action="continue">Continuar carreira<small>${c.name} · ${levelInfo(c.xp).title}</small></button>`
      : '';
    const st = this.loadStatus;
    const warn =
      st && (st.status === 'invalid' || st.status === 'unavailable')
        ? `<p class="mn-warn">Há uma carreira salva que não pôde ser lida (${st.error}). Ela foi mantida no navegador, sem alterações. Criar uma nova carreira guarda uma cópia dela antes.</p>`
        : '';
    return `
      <div class="mn-box mn-center">
        <h1 class="mn-title">APITO DO JOGO</h1>
        <p class="mn-sub">Simulador de árbitro de futebol</p>
        ${warn}
        ${cont}
        <button class="mn-btn ${c ? '' : 'primary'}" data-action="new">Nova carreira</button>
        <button class="mn-btn" data-action="quick">Partida rápida</button>
        <button class="mn-btn" data-action="settings">Configurações<small>Duração das partidas: ${getDuration(this.settings.duration).label}</small></button>
        <button class="mn-btn" data-action="help">Como jogar</button>
      </div>`;
  }

  lookPreview(look) {
    if (!(look.id in this.previews)) this.previews[look.id] = lookPreviewUrl(look);
    const url = this.previews[look.id];
    return url ? `<img class="mn-avatar" src="${url}" alt="" />` : '<div class="mn-avatar"></div>';
  }

  renderNew() {
    const d = this.draft;
    const warn = this.career ? '<p class="mn-warn">Atenção: já existe uma carreira salva. Criar outra substitui a atual (uma cópia de segurança fica guardada).</p>' : '';
    const looks = REFEREE_LOOKS.map(
      (l) => `<button class="mn-look ${l.id === d.look ? 'sel' : ''}" data-action="look" data-id="${l.id}">${this.lookPreview(l)}<span>${l.name}</span></button>`
    ).join('');
    const regions = REGIONS.map(
      (r) => `<button class="mn-region ${r.id === d.region ? 'sel' : ''}" data-action="region" data-id="${r.id}">${r.name}</button>`
    ).join('');
    return `
      <div class="mn-box">
        <h2>Criar árbitro</h2>
        <p class="mn-sub">Nome do árbitro</p>
        <input class="mn-input" data-field="name" type="text" maxlength="16" placeholder="Novo Árbitro" value="${d.name.replace(/"/g, '&quot;')}" />
        <p class="mn-sub">Aparência</p>
        <div class="mn-looks">${looks}</div>
        <p class="mn-sub">Região de origem <small>(influencia as oportunidades regionais, sem bloquear a progressão)</small></p>
        <div class="mn-regions">${regions}</div>
        <p class="mn-hint" data-role="draft-summary">${this.draftSummary()}</p>
        ${warn}
        <div class="mn-footer">
          <button class="mn-btn small" data-action="main">Voltar</button>
          <button class="mn-btn primary small" data-action="create">Confirmar e começar</button>
        </div>
      </div>`;
  }

  durationChips() {
    return `<div class="mn-durations">${DURATIONS.map(
      (d) =>
        `<button class="mn-chip ${d.id === this.settings.duration ? 'sel' : ''}" data-action="duration" data-id="${d.id}">${d.label}<small>${d.minutes} min${d.id === 'quick' ? ' · atual' : ''}</small></button>`
    ).join('')}</div>`;
  }

  renderSettings() {
    const d = getDuration(this.settings.duration);
    return `
      <div class="mn-box">
        <h2>Configurações</h2>
        <p class="mn-sub">Duração das partidas</p>
        ${this.durationChips()}
        <p class="mn-sub">Som</p>
        <button class="mn-btn small" data-action="sound">Som: ${isMuted() ? 'desligado' : 'ligado'}</button>
        <p class="mn-hint">Durante a partida, a tecla <b>N</b> liga e desliga o som.</p>
        <p class="mn-hint">Escolha atual: <b>${d.label}</b> (${d.minutes} minutos reais). O relógio do jogo vai sempre de 00:00 a 90:00; a duração só muda a velocidade dele. A frequência de lances por minuto é a mesma, então partidas mais longas têm mais lances para decidir. A escolha vale a partir da próxima partida e fica salva.</p>
        <div class="mn-footer"><button class="mn-btn small" data-action="back">Voltar</button></div>
      </div>`;
  }

  renderPrep() {
    const d = getDuration(this.settings.duration);
    return `
      <div class="mn-box mn-center">
        <h2>Partida rápida</h2>
        <p class="mn-sub">Vermelhos x Azuis · importância ★★☆</p>
        <p class="mn-sub">Duração</p>
        ${this.durationChips()}
        <p class="mn-hint">${d.label}: cerca de ${d.minutes} minutos.</p>
        <button class="mn-btn primary" data-action="startquick">Começar partida</button>
        <button class="mn-btn" data-action="main">Voltar</button>
      </div>`;
  }

  renderHelp() {
    const tabs = HELP_TABS.map((t) => `<button class="mn-tab ${t.id === this.helpTab ? 'on' : ''}" data-help="${t.id}">${t.label}</button>`).join('');
    let body;
    if (this.helpTab === 'fouls') body = this.renderHelpFouls();
    else if (this.helpTab === 'grade') body = this.renderHelpGrade();
    else if (this.helpTab === 'progress') body = this.renderHelpProgress();
    else body = this.renderHelpControls();
    return `
      <div class="mn-box">
        <h2>Como jogar</h2>
        <div class="mn-tabs">${tabs}</div>
        <div class="mn-content mn-help">${body}</div>
        <div class="mn-footer"><button class="mn-btn small" data-action="main">Voltar</button></div>
      </div>`;
  }

  renderHelpControls() {
    return `
      <p>Você é o árbitro. Acompanhe o jogo e decida os lances. Quando acontecer algo perto de você, aparece um <b>!</b> no campo. Chegue perto (o lance precisa estar ao seu alcance) e use o apito antes que o tempo de reação acabe.</p>
      <ul class="mn-keys">
        <li><b>WASD / setas</b> mover o árbitro</li>
        <li><b>Espaço</b> apitar: o jogo para e abre o painel de decisão. Apitar sem lance por perto é erro.</li>
        <li><b>V</b> dar vantagem em falta leve (o jogo segue)</li>
        <li><b>Espaço</b> (ou <b>F</b> ou <b>G</b>) logo depois de um gol: anula o gol, como uma falta marcada</li>
        <li><b>N</b> liga e desliga o som · <b>Esc</b> pausar · <b>M</b> (na pausa) sair para o menu</li>
        <li>No painel: <b>1</b> amarelo, <b>2</b> vermelho (no autor do lance), <b>F</b> marcar falta, <b>I</b> ignorar</li>
      </ul>
      <p class="mn-hint">No painel, o botão "Informação" de cada jogador e a linha "Evidências" ajudam a decidir. Veja a aba Faltas e cartões.</p>`;
  }

  renderHelpFouls() {
    return `
      <p>Todo lance é uma disputa de bola. O que muda é <b>quem tocou primeiro</b> e <b>como foi o contato</b>. Leia a linha "Evidências" no painel de decisão: ela mostra tudo o que você precisa.</p>
      <ul class="mn-list mn-fouls">
        <li class="ok"><b>Disputa legal</b> (evidência: <i>bola jogada primeiro</i>)
          <small>Não é falta. Escolha <b>Ignorar</b> e não dê cartão. Marcar falta aqui é erro.</small></li>
        <li class="light"><b>Falta leve</b> (<i>contato antes da bola</i> com <b>0 ou 1 agravante</b>)
          <small>Marque falta. <b>Sem cartão</b> (a advertência verbal é permitida). Aqui você pode usar a <b>vantagem [V]</b>: se a equipe prejudicada mantiver a bola por uns 3 segundos, o jogo segue. Se perder a bola, a falta volta e você ainda decide os cartões.</small></li>
        <li class="heavy"><b>Falta pesada</b> (<i>contato antes da bola</i> com <b>2 agravantes</b>)
          <small>Marque falta e dê <b>cartão amarelo</b> ao <b>autor</b>. <b>Nunca</b> dê vantagem.</small></li>
        <li class="heavy"><b>Falta violenta</b> (<b>3 agravantes</b>, a evidência <i>força excessiva</i> aparece)
          <small>Marque falta e dê <b>cartão vermelho</b> ao autor. O jogador deixa o jogo.</small></li>
        <li class="pen"><b>Pênalti</b> (evidência: <i>dentro da área</i>)
          <small>Marque a falta, que vira pênalti. O cartão segue a mesma regra: nenhum com 0 ou 1 agravante, amarelo com 2, vermelho com 3.</small></li>
        <li class="sim"><b>Simulação</b> (evidências: <i>sem contato</i> e <i>queda antes do contato</i>)
          <small>Não é falta: <b>não marque</b> (use Ignorar). Dê <b>amarelo para quem caiu</b>, na coluna da direita do painel. O jogo recomeça com tiro livre indireto para o adversário.</small></li>
        <li class="light"><b>Impedimento</b> (evidência: <i>posição de impedimento no passe</i>)
          <small>No momento do passe, o atacante estava na metade adversária, à frente da bola e do penúltimo defensor (o goleiro conta como defensor), e <b>recebeu a bola</b>. Escolha <b>Marcar impedimento</b>: o jogo recomeça com tiro livre indireto para o adversário, sem cartão. Só vale em jogo corrido e tiro livre (não em lateral, escanteio, tiro de meta, pênalti ou saída de bola).</small></li>
        <li class="ok"><b>Posição legal</b> (evidência: <i>posição legal no passe</i>)
          <small>O atacante estava na linha do último defensor ou até 7 px atrás. Não é impedimento: <b>Ignorar</b>. Marcar impedimento aqui é erro.</small></li>
        <li class="pen"><b>Gol de falta ou impedimento</b> (falta ou impedimento <b>da equipe que marcou</b>, não apitado, nos últimos 8 segundos de jogo corrido)
          <small>Quando sai o gol, o jogo fica parado alguns segundos. Aperte <b>Espaço</b> (ou <b>F</b>, ou <b>G</b>) para <b>anular o gol</b>, como se marcasse a falta: o placar volta e o jogo recomeça com tiro livre (indireto se foi impedimento) para o adversário. Funciona com ou sem VAR. Se a falta ou o impedimento era real e você confirmar o gol, é erro grave. Se o gol era limpo e você anular, também é erro grave. Se não apertar nada, o gol vale.</small></li>
      </ul>

      <h3>As 3 agravantes (cada uma vale 1)</h3>
      <ul class="mn-keys">
        <li><b>entrada por trás</b>: o defensor atinge o jogador de costas.</li>
        <li><b>alta velocidade</b>: os dois se chocam em grande velocidade.</li>
        <li><b>entrada imprudente</b>: o autor é um jogador ríspido, que arrisca demais.</li>
      </ul>

      <h3>Qual cartão dar numa falta?</h3>
      <div class="mn-cardtable">
        <div><b>0 ou 1 agravante</b> falta leve: nenhum cartão.</div>
        <div class="yellow"><b>2 agravantes</b> amarelo.</div>
        <div class="red"><b>3 agravantes</b> vermelho (aparece <i>força excessiva</i>).</div>
      </div>
      <p class="mn-hint">Uma agravante sozinha, como "entrada por trás", ainda é falta leve. O cartão errado, ou para o jogador errado, conta como erro na sua nota.</p>

      <h3>Cartões e advertência</h3>
      <ul class="mn-keys">
        <li>Dois amarelos para o mesmo jogador viram vermelho automático e ele deixa o jogo.</li>
        <li><b>Advertência verbal</b> vale como "sem cartão": é aceita numa falta leve e conta como "cartão brando demais" se a falta pedia amarelo ou vermelho.</li>
        <li>No painel, a coluna da esquerda é o <b>autor do lance</b> e a da direita é o <b>adversário</b> (na simulação, quem caiu).</li>
      </ul>`;
  }

  renderHelpProgress() {
    const names = LEAGUES.map((l) => l.name).join(' → ');
    const f = (n) => n.toFixed(1).replace('.', ',');
    return `
      <p>Três números diferentes, cada um com uma função:</p>
      <ul class="mn-keys">
        <li><b>Nota</b> (0 a 10): a avaliação técnica de cada partida. É a mesma da tela de resultado e nunca é alterada pela carreira.</li>
        <li><b>Experiência (XP)</b>: prática acumulada. Define o seu nível e o título (de Aspirante a Lenda do Apito).</li>
        <li><b>Reputação</b> (0 a 100): a confiança do comitê. Libera as copas e é um dos requisitos para subir de divisão.</li>
      </ul>
      <h3>Como a reputação muda</h3>
      <ul class="mn-keys">
        <li>Nota acima de 6,0 sobe a reputação; abaixo, desce. O efeito é multiplicado pela importância do jogo.</li>
        <li>Cada <b>erro grave</b> na partida desconta 0,5 (até 3). É um erro de gravidade alta, como não marcar um pênalti ou dar cartão sem motivo.</li>
        <li>A mudança por partida tem teto: uma partida ruim isolada não apaga o que você construiu.</li>
        <li><b>Suspensão de oportunidades:</b> com 4 ou mais erros graves numa partida, ou duas notas abaixo de 4,0 seguidas, a próxima rodada oferece só jogos de importância 1. É por uma rodada e o motivo aparece na tela.</li>
      </ul>
      <h3>Divisões</h3>
      <p class="mn-hint">${names}</p>
      <p>No fim de cada temporada (5 rodadas) você sobe para a divisão seguinte se cumprir <b>todos</b> estes requisitos:</p>
      <ul class="mn-keys">
        <li>reputação mínima da divisão seguinte (15, 35, 55, 75 e 90);</li>
        <li>média da temporada acima da meta da divisão (6,0 na Várzea, +0,4 a cada divisão);</li>
        <li>pelo menos ${PROMOTION.minMatches} jogos apitados;</li>
        <li>no máximo ${PROMOTION.maxGraves} erros graves na temporada;</li>
        <li>pelo menos ${PROMOTION.minObjectives} dos 4 objetivos da temporada.</li>
      </ul>
      <p>A promoção dá ${PROMOTION.xpBonus} XP. Você acompanha cada requisito na aba <b>Objetivos</b>, e no fim da temporada vê o que faltou.</p>
      <h3>Rebaixamento</h3>
      <p>Só acontece depois de <b>${DEMOTION.strikesToDemote} temporadas seguidas</b> com média abaixo de ${f(DEMOTION.poorAvg)}. A primeira gera só um aviso, e uma temporada com média ${f(DEMOTION.goodAvg)} ou mais zera os avisos. O rebaixado perde uma divisão e ${DEMOTION.repPenalty} de reputação. Na divisão mais baixa não há rebaixamento.</p>
      <h3>Recusar e passar a rodada</h3>
      <p>Recusar uma convocação ou passar a rodada <b>não custa</b> experiência nem reputação. Só não rende nada, e o bônus de fim de temporada exige 3 jogos apitados.</p>`;
  }

  renderHelpGrade() {
    return `
      <p>No fim da partida você recebe uma nota de 0 a 10, calculada só a partir das suas decisões (sem sorteio):</p>
      <ul class="mn-keys">
        <li>decisões corretas, infrações não marcadas e faltas marcadas sem infração</li>
        <li>aplicação dos cartões e uso da vantagem</li>
        <li>posicionamento (ficar perto dos lances) e consistência</li>
      </ul>
      <p>Na <b>carreira</b>, boas notas rendem experiência e reputação, que abrem convites melhores e novas competições. Atuações ruins custam pouco e nunca travam a carreira. Cada temporada tem 5 rodadas e 4 objetivos com reputação extra.</p>
      <p class="mn-hint">Dica: é melhor se aproximar e decidir com calma do que apitar tudo. Apito sem lance também desconta nota.</p>`;
  }

  renderCareer() {
    const c = this.career;
    const lv = levelInfo(c.xp);
    const top = currentDivision(c);
    const offersOpen = getOffers(c).filter((o) => o.status === 'offered').length;
    const badges = { offers: offersOpen, objectives: unseenObjectives(c), awards: unseenAwards(c), inbox: unreadCount(c) };
    const xpText = lv.next ? `${c.xp}/${lv.next} XP` : `${c.xp} XP (nível máximo)`;
    const nav = TABS.map(
      (t) =>
        `<button class="mn-navbtn ${t.id === this.tab ? 'on' : ''}" data-tab="${t.id}">${t.label}${badges[t.id] ? `<i class="mn-badge">${badges[t.id]}</i>` : ''}</button>`
    ).join('');

    return `
      <div class="mn-box">
        <div class="mn-profile">
          <div class="mn-who">
            ${this.lookPreview(getLook(c.profile.look))}
            <div>
            <h2>${c.name}</h2>
            <p class="mn-sub">Nível ${lv.level} · ${lv.title}</p>
            <p class="mn-sub">Região: ${getRegion(c.profile.region).name}</p>
            <p class="mn-sub">Divisão atual: ${top.name}</p>
            </div>
          </div>
          <div class="mn-bars">
            <div class="mn-row"><span>Experiência</span><div class="mn-bar"><i style="width:${Math.round(lv.ratio * 100)}%"></i></div><span>${xpText}</span></div>
            <div class="mn-row"><span>Reputação</span><div class="mn-bar rep"><i style="width:${Math.round(c.rep)}%"></i></div><span>${comma(c.rep)}/100</span></div>
            <div class="mn-row"><span>Temporada ${c.season.number}</span><div class="mn-bar"><i style="width:${Math.round(((c.world.week - 1) / WEEKS_PER_SEASON) * 100)}%"></i></div><span>rodada ${c.world.week}/${WEEKS_PER_SEASON}</span></div>
          </div>
        </div>
        <div class="mn-layout">
          <nav class="mn-nav">${nav}</nav>
          <div class="mn-content">${this.renderTab()}</div>
        </div>
        <div class="mn-footer">
          <button class="mn-btn small" data-action="main">Menu</button>
          <button class="mn-btn small" data-action="settings" data-from="career">Configurações</button>
          <button class="mn-btn small primary" data-action="save">Salvar carreira</button>
          <button class="mn-btn small danger" data-action="erase">Apagar carreira</button>
        </div>
      </div>`;
  }

  renderTab() {
    switch (this.tab) {
      case 'offers':
        return this.renderOffers();
      case 'calendar':
        return this.renderCalendar();
      case 'standings':
        return this.renderStandings();
      case 'news':
        return this.renderNews();
      case 'inbox':
        return this.renderInbox();
      case 'social':
        return this.renderSocial();
      case 'stats':
        return this.renderStats();
      case 'objectives':
        return this.renderObjectives();
      case 'awards':
        return this.renderAwards();
      case 'events':
        return this.renderEvents();
      case 'history':
        return this.renderHistory();
      case 'comps':
        return this.renderComps();
      default:
        return this.renderOverview();
    }
  }

  stageLine(f) {
    return `${f.stage}${f.competitionId ? ` · ${getCompetition(f.competitionId).name}` : ''}`;
  }

  scoreText(f) {
    const r = f.result;
    return `${r.home} x ${r.away}${r.pens ? ` (pên. ${r.pens[0]} x ${r.pens[1]})` : ''}`;
  }

  // Situação de um jogo na carreira: agendada, convocação recebida, concluída ou indisponível.
  fixtureStatus(f) {
    if (f.status === 'completed') return f.referee ? `Concluída · você apitou (nota ${comma(f.referee.nota)})` : 'Concluída';
    const w = this.career.world;
    const item = w.offers.items.find((i) => i.fixtureId === f.id);
    if (item && f.week === w.week) {
      if (item.status === 'offered') return 'Convocação recebida';
      if (item.status === 'declined' || item.status === 'unavailable') return 'Indisponível';
    }
    return 'Agendada';
  }

  renderOverview() {
    const c = this.career;
    const offers = getOffers(c);
    const open = offers.filter((o) => o.status === 'offered');
    const last = c.history[0];
    const objectives = evaluateObjectives(c.season);
    const champs = [...c.champions].slice(-3).reverse();

    const next = open.length
      ? `<p><b>${open.length} convocação(ões)</b> para a rodada ${c.world.week}.</p>
         <p class="mn-hint">Destaque: ${open[open.length - 1].home.name} x ${open[open.length - 1].away.name} (${open[open.length - 1].competition.name}).</p>
         <button class="mn-btn small primary" data-tab="offers">Ver convocações</button>`
      : `<p>Nenhuma convocação pendente nesta rodada.</p><button class="mn-btn small" data-tab="offers">Ir para a rodada</button>`;
    const lastBox = last
      ? `<p><b>${last.home} ${last.score} ${last.away}</b></p><p class="mn-hint">${last.competition} · nota <b>${comma(last.nota)}</b> (${last.label})</p>`
      : '<p class="mn-hint">Você ainda não apitou nenhuma partida.</p>';
    const objs = objectives.map((o) => `<li class="${o.status}"><b>${statusIcon[o.status]}</b> ${o.text}</li>`).join('');
    const champBox = champs.length
      ? `<ul class="mn-list compact">${champs.map((ch) => `<li>T${ch.season} · ${getCompetition(ch.competitionId).name}: <b>${getClub(ch.clubId).name}</b></li>`).join('')}</ul>`
      : '<p class="mn-hint">Os campeões aparecem aqui ao fim da primeira temporada.</p>';

    return `
      <div class="mn-grid">
        <div class="mn-panel"><h3>Próxima partida</h3>${next}</div>
        <div class="mn-panel"><h3>Última avaliação</h3>${lastBox}</div>
        <div class="mn-panel"><h3>Divisão e promoção</h3>${this.promotionSummary()}</div>
        <div class="mn-panel"><h3>Objetivos ativos</h3><ul class="mn-list compact">${objs}</ul></div>
        <div class="mn-panel"><h3>Mensagens e imagem pública</h3>${this.messagesSummary()}</div>
        <div class="mn-panel"><h3>Últimos campeões</h3>${champBox}</div>
      </div>`;
  }

  messagesSummary() {
    const c = this.career;
    const unread = unreadCount(c);
    const img = publicImage(c);
    const latest = c.inbox.slice(0, 2).map((m) => `<li class="${m.read ? '' : 'unread'}">${m.subject}</li>`).join('');
    const imgText = img
      ? `<p class="mn-hint">Imagem pública: <b>${img.label}</b> (${img.positive} positiva(s), ${img.neutral} neutra(s), ${img.negative} crítica(s) nas últimas ${img.total} notícias). É só narrativa: não altera sua nota nem sua reputação.</p>`
      : '<p class="mn-hint">A imagem pública aparece depois da primeira partida.</p>';
    return `<p><b>${unread}</b> mensagem(ns) não lida(s).</p><ul class="mn-list compact">${latest}</ul>${imgText}<button class="mn-btn small" data-tab="inbox">Abrir e-mails</button>`;
  }

  // Resumo curto dos requisitos de promoção para a visão geral.
  promotionSummary() {
    const c = this.career;
    const objectives = evaluateObjectives(c.season);
    const met = objectives.filter((o) => o.met).length;
    const promo = promotionCriteria({ division: c.division, rep: c.rep }, seasonStats(c.season), met, objectiveDefs(c.season.tierAtStart)[0].target);
    const warning = c.strikes > 0 ? `<p class="mn-warn">Aviso ${c.strikes} de ${DEMOTION.strikesToDemote}: a última temporada terminou com média abaixo de ${comma(DEMOTION.poorAvg)}.</p>` : '';
    if (promo.isMax) return `<p><b>${currentDivision(c).name}</b></p><p class="mn-hint">Divisão máxima.</p>${warning}`;
    const ok = promo.criteria.filter((k) => k.ok).length;
    return `<p><b>${currentDivision(c).name}</b></p>
      <p class="mn-hint">Rumo a ${promo.next.name}: ${ok} de ${promo.criteria.length} requisitos atendidos agora.</p>
      ${warning}<button class="mn-btn small" data-tab="objectives">Ver requisitos</button>`;
  }

  renderOffers() {
    const c = this.career;
    const offers = getOffers(c);
    const dur = getDuration(this.settings.duration);
    const open = offers.filter((o) => o.status === 'offered');
    const labels = { offered: '', declined: 'Recusada', unavailable: 'Indisponível (outro árbitro escalado)', taken: 'Você apitou' };

    const cards = offers
      .map((o, i) => {
        const hint = o.fixture.importance >= 3 ? 'Muitos lances e jogadores ríspidos. Recompensa alta.' : o.fixture.importance === 2 ? 'Jogo movimentado.' : 'Jogo tranquilo.';
        const ctx = matchContext(c, { competitionId: o.fixture.competitionId, homeId: o.fixture.home, awayId: o.fixture.away, stage: o.fixture.stage, week: o.fixture.week });
        const pressure = ctx.level > 0
          ? `<p class="mn-hint pressure p${ctx.level}">Pressão: <b>${ctx.label}</b> · ${ctx.tags.map((t) => t.label).join(', ')}</p>`
          : '';
        const actions =
          o.status === 'offered'
            ? `<button class="mn-btn primary small" data-action="accept" data-id="${o.fixture.id}">Aceitar e apitar [${i + 1}]</button>
               <button class="mn-btn small" data-action="decline" data-id="${o.fixture.id}">Recusar</button>`
            : `<p class="mn-hint">${labels[o.status]}</p>`;
        return `
          <div class="mn-card ${o.status === 'offered' ? '' : 'dim'}">
            <div class="mn-tag">${o.tag}</div>
            <h3>${o.home.name} <span>x</span> ${o.away.name}</h3>
            <p>${o.competition.name} · ${o.fixture.stage}</p>
            <p class="mn-hint">${o.fixture.stadium}</p>
            <p class="mn-stars">Importância ${stars(o.fixture.importance)}</p>
            <p class="mn-hint">${hint}</p>
            ${pressure}
            ${actions}
          </div>`;
      })
      .join('');

    const empty = open.length
      ? ''
      : '<p class="mn-sub">Não há mais convocações abertas nesta rodada. Passe a rodada para ver a próxima.</p>';
    const restriction = c.world.offers.restriction
      ? `<p class="mn-notice bad">Oportunidades limitadas nesta rodada (só jogos de importância 1): ${c.world.offers.restriction}. É por uma rodada e não impede a sua progressão.</p>`
      : '';
    return `
      ${restriction}
      <p class="mn-sub">Rodada ${c.world.week} de ${WEEKS_PER_SEASON}. Escolha um jogo, recuse ou passe a rodada. Recusar não tem custo. Jogos mais importantes rendem mais experiência e reputação, mas exigem mais de você.</p>
      <p class="mn-sub">Duração da partida: <b>${dur.label}</b> (${dur.minutes} min)</p>
      ${this.durationChips()}
      <div class="mn-cards">${cards}</div>
      ${empty}
      <button class="mn-btn small" data-action="skip">Passar a rodada sem apitar</button>
      <p class="mn-hint">Os jogos da rodada são simulados. Sem apitar não há experiência nem reputação, e sem custo. Só há bônus de fim de temporada com 3 ou mais jogos apitados.</p>`;
  }

  compChips(view, selectedId) {
    const comps = unlockedCompetitions(this.career);
    return `<div class="mn-durations">${comps
      .map((comp) => `<button class="mn-chip ${comp.id === selectedId ? 'sel' : ''}" data-action="pickcomp" data-view="${view}" data-id="${comp.id}">${comp.name}</button>`)
      .join('')}</div>`;
  }

  renderCalendar() {
    const c = this.career;
    const w = c.world;
    const comps = unlockedCompetitions(c);
    const sel = comps.find((x) => x.id === this.calComp) || currentDivision(c);
    this.calComp = sel.id;
    const state = w.competitions[sel.id];

    let detail = '';
    if (this.detail) {
      const f = findFixture(w, this.detail);
      if (f) {
        const startable = startableFixture(c, f.id);
        const rows = [
          ['Competição', `${getCompetition(f.competitionId).name} · ${f.stage}`],
          ['Rodada', `${f.week} de ${WEEKS_PER_SEASON}`],
          ['Partida', `${getClub(f.home).name} x ${getClub(f.away).name}`],
          ['Estádio', f.stadium],
          ['Importância', stars(f.importance)],
          ['Situação', this.fixtureStatus(f)],
          ['Árbitro escalado', f.referee ? f.referee.name : startable ? c.name + ' (convocação aberta)' : 'a definir'],
          ['Duração', f.referee && f.referee.duration ? getDuration(f.referee.duration).label : '—'],
          ['Resultado', f.result ? this.scoreText(f) : '—'],
          ['Sua avaliação', f.referee && f.referee.nota !== null ? comma(f.referee.nota) : '—'],
        ];
        detail = `<div class="mn-detail"><h3>Detalhes do jogo</h3><table class="mn-table">${rows
          .map(([k, v]) => `<tr><td>${k}</td><td>${v}</td></tr>`)
          .join('')}</table>
          ${startable ? `<button class="mn-btn primary small" data-action="accept" data-id="${f.id}">Aceitar e apitar</button>` : ''}
          <button class="mn-btn small" data-action="fixture" data-id="${f.id}">Fechar</button></div>`;
      }
    }

    const byWeek = [];
    for (let wk = 1; wk <= WEEKS_PER_SEASON; wk++) {
      const list = state.fixtures.filter((f) => f.week === wk);
      if (!list.length) continue;
      const rows = list
        .map((f) => {
          const res = f.status === 'completed' ? `<b>${this.scoreText(f)}</b>` : '<b>x</b>';
          return `<button class="mn-fix ${f.status}" data-action="fixture" data-id="${f.id}">
            <span>${getClub(f.home).name} ${res} ${getClub(f.away).name}</span>
            <small>${f.stage} · ${this.fixtureStatus(f)}</small></button>`;
        })
        .join('');
      byWeek.push(`<div class="mn-week ${wk === w.week ? 'now' : ''}"><h3>Rodada ${wk}${wk === w.week ? ' (atual)' : ''}</h3>${rows}</div>`);
    }
    return `
      <p class="mn-sub">Calendário da temporada ${c.season.number}. Toque num jogo para ver os detalhes.</p>
      ${this.compChips('calendar', sel.id)}
      ${detail}
      ${byWeek.join('') || '<p class="mn-sub">Esta competição ainda não tem jogos marcados.</p>'}`;
  }

  renderStandings() {
    const c = this.career;
    const comps = unlockedCompetitions(c);
    const sel = comps.find((x) => x.id === this.stComp) || currentDivision(c);
    this.stComp = sel.id;
    const state = c.world.competitions[sel.id];
    const past = c.champions.filter((ch) => ch.competitionId === sel.id).slice(-4).reverse();
    const pastBox = past.length ? `<p class="mn-hint">Campeões anteriores: ${past.map((ch) => `T${ch.season} ${getClub(ch.clubId).name}`).join(' · ')}</p>` : '';

    if (state.format === 'cup') {
      const comp = getCompetition(sel.id);
      const stages = comp.stages
        .map((st) => {
          const list = state.fixtures.filter((f) => f.stage === st.name);
          if (!list.length) return `<div class="mn-week"><h3>${st.name}</h3><p class="mn-hint">Aguardando a fase anterior (rodada ${st.week}).</p></div>`;
          const rows = list
            .map((f) => `<div class="mn-fix ${f.status}"><span>${getClub(f.home).name} <b>${f.result ? this.scoreText(f) : 'x'}</b> ${getClub(f.away).name}</span><small>Rodada ${f.week}</small></div>`)
            .join('');
          return `<div class="mn-week"><h3>${st.name}</h3>${rows}</div>`;
        })
        .join('');
      const champion = state.champion ? `<p class="mn-notice ok">Campeão: <b>${getClub(state.champion).name}</b></p>` : '';
      return `<p class="mn-sub">${comp.name}: mata-mata. Empates são decididos nos pênaltis.</p>
        ${this.compChips('standings', sel.id)}${champion}${stages}${pastBox}`;
    }

    const rows = leagueStandings(state)
      .map(
        (r, i) => `<tr class="${i === 0 ? 'lead' : ''}"><td>${i + 1}</td><td class="l">${r.name}</td><td>${r.played}</td><td>${r.wins}</td><td>${r.draws}</td><td>${r.losses}</td><td>${r.gf}</td><td>${r.ga}</td><td>${r.gd}</td><td><b>${r.pts}</b></td></tr>`
      )
      .join('');
    const results = state.fixtures
      .filter((f) => f.status === 'completed')
      .map((f) => `<li>R${f.week} · ${getClub(f.home).name} <b>${this.scoreText(f)}</b> ${getClub(f.away).name}${f.referee ? ' · você apitou' : ''}</li>`)
      .join('');
    return `
      <p class="mn-sub">${getCompetition(sel.id).name}: pontos corridos, turno único. Desempate por saldo de gols, gols marcados e ordem alfabética.</p>
      ${this.compChips('standings', sel.id)}
      <table class="mn-table table-st"><thead><tr><th>#</th><th class="l">Equipe</th><th>J</th><th>V</th><th>E</th><th>D</th><th>GP</th><th>GC</th><th>SG</th><th>Pts</th></tr></thead><tbody>${rows}</tbody></table>
      ${pastBox}
      <h3>Resultados</h3>
      <ul class="mn-list compact">${results || '<li class="mn-hint">Nenhum jogo concluído ainda nesta temporada.</li>'}</ul>`;
  }

  renderSeasonsTable() {
    const list = [...this.career.seasons].reverse();
    if (!list.length) return '<p class="mn-hint">O desempenho por temporada aparece aqui depois da primeira temporada.</p>';
    const label = { promoted: 'Promovido', demoted: 'Rebaixado', warning: 'Aviso', stayed: 'Mantido', max: 'Divisão máxima' };
    const rows = list
      .map((x) => `<tr><td>T${x.number}</td><td class="l">${x.division}</td><td>${x.played}</td><td>${x.avg === null ? '—' : comma(x.avg)}</td><td>${x.graves}</td><td class="l">${label[x.action]}</td></tr>
        <tr><td></td><td class="l why" colspan="5">${x.reason}</td></tr>`)
      .join('');
    return `<h3>Desempenho por temporada</h3>
      <table class="mn-table"><thead><tr><th></th><th class="l">Divisão</th><th>Jogos</th><th>Média</th><th>Graves</th><th class="l">Resultado</th></tr></thead><tbody>${rows}</tbody></table>`;
  }

  // Estatísticas calculadas só a partir do histórico de partidas apitadas (as últimas 40).
  renderStats() {
    const c = this.career;
    const h = c.history;
    if (!h.length) return '<p class="mn-sub">Apite sua primeira partida para ver suas estatísticas.</p>';
    const avg = h.reduce((a, m) => a + m.nota, 0) / h.length;
    const best = Math.max(...h.map((m) => m.nota));
    const sum = (key) => h.reduce((a, m) => a + (m.extras ? m.extras[key] || 0 : 0), 0);
    const byComp = {};
    for (const m of h) byComp[m.competition] = (byComp[m.competition] || { n: 0, total: 0 });
    for (const m of h) {
      byComp[m.competition].n += 1;
      byComp[m.competition].total += m.nota;
    }
    const compRows = Object.entries(byComp)
      .map(([name, v]) => `<tr><td class="l">${name}</td><td>${v.n}</td><td>${comma(v.total / v.n)}</td></tr>`)
      .join('');
    const rows = [
      ['Partidas na carreira', c.totalMatches],
      ['Média das avaliações', comma(avg)],
      ['Melhor avaliação', comma(best)],
      ['Cartões amarelos', sum('yellow')],
      ['Cartões vermelhos', sum('red')],
      ['Faltas marcadas', sum('fouls')],
      ['Pênaltis marcados', sum('penalties')],
      ['Impedimentos marcados', sum('offsides')],
      ['Erros graves registrados', h.reduce((a, m) => a + (m.graves || 0), 0)],
      ['Decisões corretas', sum('decisions') ? `${sum('correct')} de ${sum('decisions')} (${Math.round((100 * sum('correct')) / sum('decisions'))}%)` : '—'],
      ['Revisões do VAR', h.reduce((a, m) => a + (m.var ? m.var.reviews : 0), 0)],
      ['Decisões alteradas após o VAR', h.reduce((a, m) => a + (m.var ? m.var.changed : 0), 0)],
      ['Revisões em lances elegíveis (pênalti, vermelho, impedimento)', h.reduce((a, m) => a + (m.var ? m.var.eligible : 0), 0)],
      ['Jogos de pressão alta ou máxima', h.filter((m) => m.context && m.context.level >= 2).length],
      ['Promoções / rebaixamentos', `${c.seasons.filter((x) => x.action === 'promoted').length} / ${c.seasons.filter((x) => x.action === 'demoted').length}`],
      ['Rodadas passadas sem apitar', c.skipped],
    ]
      .map(([k, v]) => `<tr><td class="l">${k}</td><td>${v}</td></tr>`)
      .join('');
    return `
      <p class="mn-hint">Calculado a partir do histórico das suas partidas (as últimas ${h.length}).</p>
      <table class="mn-table">${rows}</table>
      <h3>Por competição</h3>
      <table class="mn-table"><thead><tr><th class="l">Competição</th><th>Jogos</th><th>Média</th></tr></thead><tbody>${compRows}</tbody></table>
      ${this.renderSeasonsTable()}`;
  }

  renderInvites() {
    const c = this.career;
    const cards = c.invitations
      .map((inv, i) => {
        const comp = getCompetition(inv.competitionId);
        const home = getClub(inv.homeId);
        const away = getClub(inv.awayId);
        const hint = inv.importance >= 3 ? 'Muitos lances e jogadores ríspidos. Recompensa alta.' : inv.importance === 2 ? 'Jogo movimentado.' : 'Jogo tranquilo.';
        return `
          <div class="mn-card">
            <div class="mn-tag">${inv.tag}</div>
            <h3>${home.name} <span>x</span> ${away.name}</h3>
            <p>${comp.name}</p>
            <p class="mn-stars">Importância ${stars(inv.importance)}</p>
            <p class="mn-hint">${hint}</p>
            <button class="mn-btn primary small" data-action="accept" data-index="${i}">Aceitar convite [${i + 1}]</button>
          </div>`;
      })
      .join('');
    const dur = getDuration(this.settings.duration);
    return `<p class="mn-sub">Escolha sua próxima partida. Jogos mais importantes rendem mais experiência e reputação, mas exigem mais de você.</p>
      <p class="mn-sub">Duração da partida: <b>${dur.label}</b> (${dur.minutes} min)</p>
      ${this.durationChips()}
      <div class="mn-cards">${cards}</div>`;
  }

  // Data de uma mensagem: temporada e rodada (99 = fim de temporada).
  dateLabel(d) {
    if (!d) return '';
    return d.week >= 99 ? `T${d.season} · fim da temporada` : `T${d.season} · rodada ${d.week}`;
  }

  filterChips(view, current, options) {
    return `<div class="mn-durations">${options
      .map(([id, label]) => `<button class="mn-chip ${id === current ? 'sel' : ''}" data-action="filter" data-view="${view}" data-id="${id}">${label}</button>`)
      .join('')}</div>`;
  }

  renderNews() {
    const c = this.career;
    const tones = { positive: 'Positiva', neutral: 'Neutra', negative: 'Negativa' };
    const list = c.news.filter((n) => this.newsTone === 'all' || n.tone === this.newsTone);
    const img = publicImage(c);
    const cards = list
      .map(
        (n) => `<div class="mn-news ${n.tone}">
          <span class="mn-tonetag">${tones[n.tone]}</span>
          <h3>${n.headline}</h3>
          <p>${n.summary}</p>
          <small>${n.source} · ${n.category}${n.competitionId ? ` · ${getCompetition(n.competitionId).name}` : ''} · ${this.dateLabel(n.date)}</small>
        </div>`
      )
      .join('');
    return `
      <p class="mn-sub">Notícias fictícias geradas a partir do que aconteceu nas suas partidas e na sua carreira.${img ? ` Imagem pública: <b>${img.label}</b> (só narrativa).` : ''}</p>
      ${this.filterChips('news', this.newsTone, [['all', 'Todas'], ['positive', 'Positivas'], ['neutral', 'Neutras'], ['negative', 'Negativas']])}
      ${cards || '<p class="mn-sub">Nenhuma notícia ainda. Elas aparecem depois de cada partida que você apitar.</p>'}`;
  }

  renderInbox() {
    const c = this.career;
    if (this.mailId) {
      const m = c.inbox.find((x) => x.id === this.mailId);
      if (m) return this.renderMail(m);
      this.mailId = null;
    }
    const unread = unreadCount(c);
    const rows = c.inbox
      .map(
        (m) => `<button class="mn-mail ${m.read ? '' : 'unread'}" data-action="mail" data-id="${m.id}">
          <b>${m.subject}</b>
          <small>${m.from} · ${m.category} · ${this.dateLabel(m.date)}</small></button>`
      )
      .join('');
    return `
      <p class="mn-sub">${unread} mensagem(ns) não lida(s) de ${c.inbox.length}.</p>
      ${unread ? '<button class="mn-btn small" data-action="readall">Marcar todas como lidas</button>' : ''}
      <div class="mn-maillist">${rows}</div>`;
  }

  renderMail(m) {
    const c = this.career;
    const w = c.world;
    const lines = m.lines.map((l) => `<p>${l}</p>`).join('');
    const criteria = m.criteria
      ? `<ul class="mn-list compact">${m.criteria.map((k) => `<li class="${k.ok ? 'ok' : 'failed'}"><b>${k.ok ? '✓' : '✗'}</b> ${k.text}<small>${k.detail}</small></li>`).join('')}</ul>`
      : '';

    let offers = '';
    if (m.offers && m.offers.length) {
      const current = m.key === `week:${w.season}:${w.week}`;
      const statusText = { offered: '', declined: 'Recusada', unavailable: 'Indisponível (outro árbitro escalado)', taken: 'Você apitou' };
      offers = m.offers
        .map((o) => {
          const item = current ? w.offers.items.find((i) => i.fixtureId === o.fixtureId) : null;
          const status = current ? (item ? item.status : 'unavailable') : null;
          const comp = COMPETITIONS.find((x) => x.name === o.competition);
          const need = comp ? (comp.division ? `estar na ${comp.name} ou em divisão superior` : `reputação de ${unlockThreshold(comp, c.profile.region)} ou mais`) : '';
          const actions =
            status === 'offered'
              ? `<button class="mn-btn primary small" data-action="accept" data-id="${o.fixtureId}">Aceitar e apitar</button>
                 <button class="mn-btn small" data-action="decline" data-id="${o.fixtureId}">Recusar</button>`
              : `<p class="mn-hint">${status ? statusText[status] : 'Rodada encerrada'}</p>`;
          return `<div class="mn-card ${status === 'offered' ? '' : 'dim'}">
            <div class="mn-tag">${o.tag}</div>
            <h3>${o.home} <span>x</span> ${o.away}</h3>
            <p>${o.competition} · ${o.stage}</p>
            <p class="mn-hint">${o.stadium} · importância ${stars(o.importance)}</p>
            <p class="mn-hint">Requisito: ${need}. Você atende.</p>
            ${actions}</div>`;
        })
        .join('');
      offers = `<div class="mn-cards">${offers}</div>`;
    }

    return `
      <div class="mn-maildetail">
        <h3>${m.subject}</h3>
        <p class="mn-hint">${m.from} · ${m.category} · ${this.dateLabel(m.date)}</p>
        ${lines}${criteria}${offers}
        <div class="mn-footer">
          <button class="mn-btn small" data-action="mailback">Voltar à lista</button>
          <button class="mn-btn small" data-action="mailtoggle" data-id="${m.id}">Marcar como ${m.read ? 'não lida' : 'lida'}</button>
        </div>
      </div>`;
  }

  renderSocial() {
    const c = this.career;
    const tags = [['all', 'Todas'], ['dado oficial', 'Dado oficial'], ['análise', 'Análise'], ['comunicado do clube', 'Clubes'], ['opinião', 'Opinião']];
    const list = c.social.filter((p) => this.socialTag === 'all' || p.tag === this.socialTag);
    const posts = list
      .map(
        (p) => `<div class="mn-post">
          <div class="mn-ph"><b>${p.author.name}</b> <span>${p.author.handle}</span> <i class="mn-pt ${p.tag === 'opinião' ? 'op' : 'fact'}">${p.tag}</i></div>
          <p>${p.text}</p>
          <small>♥ ${p.likes} · ${p.competitionId ? `${getCompetition(p.competitionId).name} · ` : ''}${this.dateLabel(p.date)}</small>
        </div>`
      )
      .join('');
    return `
      <p class="mn-notice">Publicações fictícias. Opinião de torcedor e de comentarista não é avaliação técnica: a sua nota vem das suas decisões na partida.</p>
      ${this.filterChips('social', this.socialTag, tags)}
      ${posts || '<p class="mn-sub">Ainda não há publicações. A rede social reage depois de cada partida.</p>'}`;
  }

  renderObjectives() {
    const c = this.career;
    const objectives = evaluateObjectives(c.season);
    const stats = seasonStats(c.season);
    const met = objectives.filter((o) => o.met).length;
    const avgTarget = objectiveDefs(c.season.tierAtStart)[0].target;
    const promo = promotionCriteria({ division: c.division, rep: c.rep }, stats, met, avgTarget);

    const promoHtml = promo.isMax
      ? '<p class="mn-sub">Você está na divisão máxima. Não há promoção, mas os objetivos continuam valendo reputação.</p>'
      : `<h3>Requisitos para subir para ${promo.next.name}</h3>
         <ul class="mn-list">${promo.criteria
           .map((k) => `<li class="${k.ok ? 'ok' : k.id === 'graves' ? 'failed' : 'pending'}"><b>${k.ok ? '✓' : k.id === 'graves' ? '✗' : '…'}</b> ${k.text}<small>${k.detail}</small></li>`)
           .join('')}</ul>
         <p class="mn-hint">A decisão é tomada no fim da temporada (rodada ${WEEKS_PER_SEASON}), com todos os requisitos juntos.</p>`;

    const demotion =
      c.division === 0
        ? 'Na divisão mais baixa não há rebaixamento.'
        : `Rebaixamento: só após ${DEMOTION.strikesToDemote} temporadas seguidas com média abaixo de ${comma(DEMOTION.poorAvg)}. Avisos atuais: ${c.strikes} de ${DEMOTION.strikesToDemote}.`;

    const seasonItems = objectives
      .map((o) => `<li class="${o.status}"><b>${statusIcon[o.status]}</b> ${o.text}<small>${o.progress}</small></li>`)
      .join('');

    const career = careerObjectives(c)
      .map((o) => {
        const reward = [o.reward.xp ? `+${o.reward.xp} XP` : '', o.reward.rep ? `+${o.reward.rep} de reputação` : ''].filter(Boolean).join(' e ');
        const done = o.status === 'done';
        return `<li class="${done ? 'ok' : 'pending'}"><b>${done ? '✓' : '…'}</b> ${o.text}${done && this.fresh && this.fresh.has(o.id) ? ' <i class="mn-badge">novo</i>' : ''}
          <small>${done ? (o.retro ? 'já cumprido antes desta atualização' : `concluído na temporada ${o.doneAt.season}, rodada ${o.doneAt.week}`) : `progresso ${o.progress}`} · recompensa: ${reward}</small>
          ${done ? '' : `<div class="mn-bar"><i style="width:${Math.round(o.ratio * 100)}%"></i></div>`}</li>`;
      })
      .join('');

    return `
      <p class="mn-sub">Temporada ${c.season.number}: rodada ${c.world.week} de ${WEEKS_PER_SEASON}, ${c.season.round} jogo(s) apitado(s). Divisão atual: <b>${currentDivision(c).name}</b>.</p>
      ${promoHtml}
      <p class="mn-hint">${demotion}</p>
      <h3>Objetivos da temporada</h3>
      <ul class="mn-list">${seasonItems}</ul>
      <p class="mn-hint">Cada um rende reputação extra no fim da temporada, com pelo menos 3 jogos apitados.</p>
      <h3>Objetivos de carreira</h3>
      <ul class="mn-list">${career}</ul>`;
  }

  renderAwards() {
    const c = this.career;
    const earned = c.awards || [];
    const earnedHtml = earned.length
      ? `<ul class="mn-list">${earned.map((a) => `<li class="ok"><b>🏆 ${a.name}</b><small>Temporada ${a.season} · +${a.xp} XP · ${a.detail}</small></li>`).join('')}</ul>`
      : '<p class="mn-hint">Nenhum prêmio ainda. Eles são concedidos no fim da temporada, por critérios verificáveis.</p>';
    const status = awardStatus(c, c.season.matches, c.season.number);
    const now = status
      .map((st) => {
        const tag = st.earned ? 'já conquistado nesta temporada' : st.blockedOnce ? 'prêmio único, você já o conquistou' : st.met ? 'critérios cumpridos até agora' : 'ainda não cumprido';
        const items = st.criteria.map((k) => `<small>${k.ok ? '✓' : '…'} ${k.text} (${k.detail})</small>`).join('');
        return `<li class="${st.met || st.earned ? 'ok' : 'pending'}"><b>${st.name}</b> <small>${st.summary}</small>${items}<small>${tag}</small></li>`;
      })
      .join('');
    return `
      <p class="mn-sub">Prêmios de temporada: concedidos no fim da temporada (rodada ${WEEKS_PER_SEASON}) por critérios verificáveis, sem sorteio. Cada prêmio vale +${AWARD_XP} XP, uma única vez por temporada.</p>
      <h3>Conquistados</h3>
      ${earnedHtml}
      <h3>Temporada ${c.season.number}: critérios até agora</h3>
      <p class="mn-hint">O cálculo usa os ${c.season.matches.length} jogo(s) que você apitou nesta temporada.</p>
      <ul class="mn-list">${now}</ul>`;
  }

  renderEvents() {
    const list = this.career.events || [];
    const intro = '<p class="mn-sub">Acontecimentos especiais da carreira: jogos de pressão, revisões técnicas, críticas e convocações especiais. São registros narrativos: não alteram nota, reputação nem progressão.</p>';
    if (!list.length) return `${intro}<p class="mn-hint">Nenhum evento ainda. Eles aparecem em clássicos, finais, jogos com erros graves e convocações especiais.</p>`;
    const rows = list
      .map((e) => `<li class="${e.tone === 'negative' ? 'failed' : e.tone === 'positive' ? 'ok' : ''}"><b>${e.title}</b><small>${this.dateLabel(e.date)} · ${e.text}</small></li>`)
      .join('');
    return `${intro}<ul class="mn-list">${rows}</ul>`;
  }

  renderHistory() {
    const h = this.career.history;
    if (!h.length) return '<p class="mn-sub">Nenhuma partida apitada ainda.</p>';
    const rows = h
      .map(
        (m) => `<li>
          <b>T${m.season} · J${m.round}</b> ${m.home} ${m.score} ${m.away}
          <small>${m.competition}${m.duration ? ` · ${getDuration(m.duration).label}` : ''} · nota <b>${comma(m.nota)}</b> (${m.label}) · +${m.xp} XP · reputação ${m.rep >= 0 ? '+' : ''}${comma(m.rep)}${m.var ? ` · VAR: ${m.var.reviews} revisão(ões), ${m.var.changed} alterada(s)` : ''}${m.context && m.context.level >= 2 ? ` · pressão ${m.context.label.toLowerCase()}` : ''}</small>
        </li>`
      )
      .join('');
    return `<ul class="mn-list">${rows}</ul>`;
  }

  renderComps() {
    const c = this.career;
    const region = c.profile.region;
    const rows = COMPETITIONS.map((comp) => {
      const open = c.unlocked.includes(comp.id);
      const need = unlockThreshold(comp, region);
      const format = comp.format === 'cup' ? 'Copa (mata-mata)' : 'Liga (pontos corridos)';
      const regionText = comp.region ? ` · região ${getRegion(comp.region).name}${comp.region !== region ? ' (exige mais reputação fora da sua região)' : ''}` : '';
      return `<li class="${open ? 'ok' : 'locked'}"><b>${open ? '✓' : '🔒'}</b> ${comp.name}
        <small>${format}${regionText} · ${clubCount(comp)} clubes · importância ${stars(comp.importance)}</small>
        <small>${open ? 'Liberada' : comp.division ? `Liberada ao ser promovido a esta divisão (reputação ${need} é um dos requisitos)` : `Libera com reputação ${need} (faltam ${comma(need - c.rep)})`}</small></li>`;
    }).join('');
    return `<ul class="mn-list">${rows}</ul>`;
  }
}
