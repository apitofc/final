import { TEAMS } from '../config.js';
import { describeIncident } from '../systems/MatchRules.js';
import { playerLabel } from '../utils/labels.js';

const ROLE_NAMES = { GK: 'Goleiro', DEF: 'Defensor', MID: 'Meio-campista', FWD: 'Atacante' };

export default class DecisionPanel {
  constructor(scene, onDecide) {
    this.scene = scene;
    this.onDecide = onDecide;
    this.open_ = false;
    this.forceFoul = false;
    this.sel = { offender: null, victim: null };
    this.incident = null;
    this.suspended = false; // painel escondido enquanto o VAR está aberto
    this.ignoreUntil = 0;

    this.root = document.createElement('div');
    this.root.id = 'decision-panel';
    document.body.appendChild(this.root);

    this.root.addEventListener('mousedown', (e) => e.preventDefault());
    this.root.addEventListener('click', (e) => this.onClick(e));

    this.onKey = (e) => this.handleKey(e);
    window.addEventListener('keydown', this.onKey, true);

    scene.events.on('decision-needed', (d) => this.open(d));
    scene.events.once('shutdown', () => this.destroy());
  }

  get isOpen() {
    return this.open_;
  }

  open({ incident, forceFoul }) {
    this.incident = incident;
    this.forceFoul = !!forceFoul;
    this.sel = { offender: null, victim: null };

    const off = incident.offender;
    const vic = incident.victim;
    const col = (who, p) => `
      <div class="dp-col" data-who="${who}">
        <h3>${playerLabel(p)}</h3>
        <small>${ROLE_NAMES[p.role]} · ${TEAMS[p.team].name}</small>
        <button class="dp-btn" data-action="info" data-who="${who}">Informação</button>
        <button class="dp-btn warn" data-action="card" data-card="warning" data-who="${who}">Advertência verbal</button>
        <button class="dp-btn yellow" data-action="card" data-card="yellow" data-who="${who}">Cartão amarelo${who === 'offender' ? ' [1]' : ''}</button>
        <button class="dp-btn red" data-action="card" data-card="red" data-who="${who}">Cartão vermelho${who === 'offender' ? ' [2]' : ''}</button>
        <p class="dp-info" data-info="${who}"></p>
      </div>`;

    this.root.innerHTML = `
      <div class="dp-box">
        <p class="dp-title">${this.forceFoul ? 'VANTAGEM NÃO SE CONFIRMOU' : 'JOGO PARADO'}</p>
        <p class="dp-desc">${describeIncident(incident)}</p>
        <p class="dp-evidence">Evidências: ${incident.evidence.join(' · ')}</p>
        <div class="dp-cols">
          ${col('offender', off)}
          <div class="dp-center">
            <button class="dp-btn foul" data-action="foul">${incident.type === 'offside' || incident.type === 'legal_position' ? 'Marcar impedimento' : 'Marcar falta'} [F]</button>
            ${this.forceFoul ? '' : '<button class="dp-btn ignore" data-action="ignore">Ignorar [I]</button>'}
            <button class="dp-btn var" data-action="var">Rever no VAR [R]</button>
          </div>
          ${col('victim', vic)}
        </div>
        <p class="dp-hint">Dúvida? Reveja o lance no VAR [R]. Cartões (opcional) e depois falta ou ignorar. Agravantes: por trás, alta velocidade, imprudente. 0 a 1 = falta leve (sem cartão), 2 = amarelo, 3 = vermelho.</p>
      </div>`;
    this.root.classList.add('open');
    this.open_ = true;
    this.suspended = false;
  }

  close() {
    this.root.classList.remove('open');
    this.root.innerHTML = '';
    this.open_ = false;
    this.suspended = false;
  }

  // O VAR assume a tela: o painel some, mas guarda os cartões já escolhidos para quando voltar.
  suspend() {
    if (!this.open_) return;
    this.suspended = true;
    this.root.classList.remove('open');
  }

  resume() {
    if (!this.open_ || !this.suspended) return;
    this.suspended = false;
    this.ignoreUntil = performance.now() + 200; // a mesma tecla que fechou o VAR não pode reabri-lo
    this.root.classList.add('open');
  }

  onClick(e) {
    const btn = e.target.closest('button');
    if (!btn || !this.open_ || this.suspended) return;
    const { action, who, card } = btn.dataset;

    if (action === 'info') this.toggleInfo(who);
    else if (action === 'card') this.toggleCard(who, card);
    else if (action === 'foul') this.finish(true);
    else if (action === 'ignore') this.finish(false);
    else if (action === 'var') this.scene.requestVar();
  }

  toggleInfo(who) {
    const p = this.incident[who];
    const el = this.root.querySelector(`[data-info="${who}"]`);
    if (!el) return;
    el.textContent = el.textContent
      ? ''
      : `Posição: ${ROLE_NAMES[p.role]} · Amarelos: ${p.yellowCards}`;
  }

  toggleCard(who, card) {
    this.sel[who] = this.sel[who] === card ? null : card;
    for (const b of this.root.querySelectorAll(`button[data-action="card"][data-who="${who}"]`)) {
      b.classList.toggle('sel', b.dataset.card === this.sel[who]);
    }
  }

  finish(foul) {
    const cards = { ...this.sel };
    this.close();
    this.onDecide({ foul, cards });
  }

  handleKey(e) {
    if (!this.open_ || this.suspended) return;
    e.preventDefault();
    e.stopPropagation();
    if (e.repeat || performance.now() < this.ignoreUntil) return;

    const k = e.key.toLowerCase();
    if (k === '1') this.toggleCard('offender', 'yellow');
    else if (k === '2') this.toggleCard('offender', 'red');
    else if (k === 'f') this.finish(true);
    else if (k === 'i' && !this.forceFoul) this.finish(false);
    else if (k === 'r') this.scene.requestVar();
  }

  destroy() {
    window.removeEventListener('keydown', this.onKey, true);
    this.root.remove();
  }
}