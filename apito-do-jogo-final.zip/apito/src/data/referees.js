// Aparências e regiões do árbitro. Tudo desenhado por código no estilo do jogo (sem imagens externas).
export const REFEREE_LOOKS = [
  { id: 0, name: 'Clássico', skin: '#f0c08a', hair: '#3b2a1c', shirt: '#161616', accent: '#c8ff2e' },
  { id: 1, name: 'Veterano', skin: '#e0b088', hair: '#c4c4c4', shirt: '#1d2b4a', accent: '#ffe066' },
  { id: 2, name: 'Atleta', skin: '#8a5a3a', hair: '#141414', shirt: '#17402b', accent: '#ffffff' },
  { id: 3, name: 'Sereno', skin: '#f4d2ae', hair: '#d9b54a', shirt: '#3a3f4a', accent: '#6fe0ff' },
  { id: 4, name: 'Jovem', skin: '#c68a5a', hair: '#6a2a14', shirt: '#5a1f2e', accent: '#ffb3c8' },
  { id: 5, name: 'Elegante', skin: '#6a4028', hair: '#0e0e0e', shirt: '#14505a', accent: '#c8ff2e' },
  { id: 6, name: 'Intenso', skin: '#e8b890', hair: '#a8341c', shirt: '#3b2a63', accent: '#ffe066' },
  { id: 7, name: 'Discreto', skin: '#d29c70', hair: '#5a4a3a', shirt: '#7a3a12', accent: '#ffffff' },
];

export const REGIONS = [
  { id: 'norte', name: 'Norte' },
  { id: 'nordeste', name: 'Nordeste' },
  { id: 'centrooeste', name: 'Centro-Oeste' },
  { id: 'sudeste', name: 'Sudeste' },
  { id: 'sul', name: 'Sul' },
];

export const DEFAULT_PROFILE = { name: 'Novo Árbitro', look: 0, region: 'sudeste' };

export const getLook = (id) => REFEREE_LOOKS.find((l) => l.id === id) || REFEREE_LOOKS[0];
export const getRegion = (id) => REGIONS.find((r) => r.id === id) || REGIONS[3];
