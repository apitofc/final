import { VAR_SPEEDS, VAR_CAMERAS, VAR_FILTERS, emptyChoice, sameChoice } from '../systems/VarSystem.js';
import { INCIDENT } from '../systems/MatchRules.js';
import { TEAMS } from '../config.js';
import { playerLabel } from '../utils/labels.js';

const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
const CARD_CHOICES = [
  { id: null, label: 'Sem cartão' },
  { id: 'warning', label: 'Advertência' },
  { id: 'yellow', label: 'Amarelo' },
  { id: 'red', label: 'Vermelho' },
];
const speedLabel = (v) => `${String(v).replace('.', ',')}x`;

// Painel do VAR: fica ao lado do campo (o jogo encolhe para abrir espaço, nada é coberto).
export default class VarPanel {
  constructor(scene, varSys, onClose) {
    this.scene = scene;
    this.var = varSys;
    this.onClose = onClose;
    this.open_ = false;
    this.filter = 'all';
    this.draft = emptyChoice();
    this.draftFor = null;
    this.confirming = false;
    this.error = '';
    this.last = {};
    this.ignoreUntil = 0;

    this.root = document.createElement('div');
    this.root.id = 'var-panel';
    document.body.appendChild(this.root);
    // Os botões não roubam o foco do jogo; o controle deslizante precisa do comportamento normal.
    this.root.addEventListener('mousedown', (e) => {
      if (!e.target.closest('input')) e.preventDefault();
    });
    this.root.addEventListener('click', (e) => this.onClick(e));
    this.root.addEventListener('input', (e) => this.onInput(e));

    this.onKey = (e) => this.handleKey(e);
    window.addEventListener('keydown', this.onKey, true);
    scene.events.once('shutdown', () => this.destroy());
  }

  get isOpen() {
    return this.open_;
  }

  open() {
    this.open_ = true;
    this.ignoreUntil = performance.now() + 200; // a tecla que abriu o VAR (ex.: R no painel de decisão) não o fecha
    this.filter = 'all';
    this.draftFor = null;
    this.confirming = false;
    this.error = '';
    this.last = {};
    this.root.innerHTML = `
      <div class="vp-head">
        <b>VAR</b><span class="vp-live">JOGO PAUSADO PARA REVISÃO</span>
      </div>
      <div class="vp-moment">
        <span data-role="clock">00:00</span><small data-role="period"></small>
        <span class="vp-score" data-role="score"></span>
        <span class="vp-tag" data-role="tag"></span>
      </div>
      <div class="vp-section">
        <div class="vp-track">
          <div class="vp-ticks" data-role="ticks"></div>
          <input type="range" data-role="seek" min="0" max="${Math.round(this.var.rec.end)}" step="10" value="0" aria-label="Linha do tempo da partida" />
        </div>
        <div class="vp-row">
          <button class="vp-btn" data-act="start" title="Voltar ao início da jogada [Home]">Início da jogada</button>
          <button class="vp-btn" data-act="back" title="Voltar 2 segundos [←]">−2s</button>
          <button class="vp-btn primary" data-act="play" data-role="play">Pausar</button>
          <button class="vp-btn" data-act="fwd" title="Avançar 2 segundos [→]">+2s</button>
          <button class="vp-btn" data-act="replay" title="Repetir a jogada [Enter]">Repetir</button>
        </div>
        <div class="vp-row">
          <button class="vp-btn small" data-act="frame-" title="Um quadro para trás [,]">◀ quadro</button>
          <button class="vp-btn small" data-act="frame+" title="Um quadro para frente [.]">quadro ▶</button>
        </div>
        <div class="vp-row"><span class="vp-lbl">Velocidade</span>${VAR_SPEEDS.map((s) => `<button class="vp-chip" data-speed="${s}">${speedLabel(s)}</button>`).join('')}</div>
        <div class="vp-row"><span class="vp-lbl">Câmera</span>${VAR_CAMERAS.map((c, i) => `<button class="vp-chip" data-cam="${c.id}" title="Tecla ${i + 1}">${c.label}</button>`).join('')}</div>
      </div>
      <div class="vp-section vp-list-wrap">
        <div class="vp-row">${VAR_FILTERS.map((f) => `<button class="vp-chip" data-filter="${f.id}">${f.label}</button>`).join('')}</div>
        <div class="vp-list" data-role="list"></div>
      </div>
      <div class="vp-section vp-detail" data-role="detail"></div>
      <div class="vp-foot">
        <button class="vp-btn danger" data-act="close">${this.var.deciding ? 'Voltar ao painel de decisão [R]' : 'Encerrar revisão e voltar ao jogo [R]'}</button>
        <small>Espaço pausa/continua · ←/→ ±2s · [ ] velocidade · 1-5 câmera</small>
      </div>`;
    document.body.classList.add('var-open');
    window.dispatchEvent(new Event('resize'));
    this.renderTicks();
    this.renderList();
    this.renderDetail();
    this.update();
  }

  close() {
    if (!this.open_) return;
    this.open_ = false;
    this.root.innerHTML = '';
    document.body.classList.remove('var-open');
    window.dispatchEvent(new Event('resize'));
  }

  destroy() {
    window.removeEventListener('keydown', this.onKey, true);
    document.body.classList.remove('var-open');
    this.root.remove();
  }

  // ---- Atualização a cada quadro (só mexe no que mudou) ---------------------------------------------------------

  setText(role, text) {
    if (this.last[role] === text) return;
    this.last[role] = text;
    const el = this.root.querySelector(`[data-role="${role}"]`);
    if (el) el.textContent = text;
  }

  update() {
    if (!this.open_) return;
    const v = this.var;
    const clock = v.clockAtCursor();
    const view = v.current();
    this.setText('clock', clock.text);
    this.setText('period', `${clock.period}º TEMPO${clock.added ? ' · acréscimos' : ''}`);
    this.setText('score', `${view.score.home} - ${view.score.away}`);
    this.setText('tag', v.isCursorVoided() ? 'LANCE ANULADO PELO VAR' : v.playing ? `REPLAY ${speedLabel(v.speed)}` : 'PAUSADO');
    this.setText('play', v.playing ? 'Pausar' : 'Reproduzir');

    const seek = this.root.querySelector('[data-role="seek"]');
    if (seek && document.activeElement !== seek) seek.value = String(Math.round(v.cursor));

    const sig = `${v.speed}|${v.camera}|${this.filter}|${v.selectedId}`;
    if (this.last.sig !== sig) {
      this.last.sig = sig;
      for (const b of this.root.querySelectorAll('[data-speed]')) b.classList.toggle('sel', Number(b.dataset.speed) === v.speed);
      for (const b of this.root.querySelectorAll('[data-cam]')) b.classList.toggle('sel', b.dataset.cam === v.camera);
      for (const b of this.root.querySelectorAll('[data-filter]')) b.classList.toggle('sel', b.dataset.filter === this.filter);
      for (const b of this.root.querySelectorAll('[data-ev]')) b.classList.toggle('sel', Number(b.dataset.ev) === v.selectedId);
    }
  }

  renderTicks() {
    const el = this.root.querySelector('[data-role="ticks"]');
    const end = Math.max(1, this.var.rec.end);
    const pct = (rt) => ((rt / end) * 100).toFixed(2);
    const voids = this.var.rec.voided.map((s) => `<i class="vp-void" style="left:${pct(s.from)}%;width:${(((s.to - s.from) / end) * 100).toFixed(2)}%"></i>`);
    const ticks = this.var.rec.events
      .filter((e) => ['incident', 'goal', 'card'].includes(e.type))
      .map((e) => `<i class="vp-tick ${e.type}${e.annulled ? ' off' : ''}" style="left:${pct(e.rt)}%"></i>`);
    el.innerHTML = voids.join('') + ticks.join('');
  }

  renderList() {
    const list = this.root.querySelector('[data-role="list"]');
    const items = this.var.eventList(this.filter);
    list.innerHTML = items.length
      ? items
          .map(
            (e) => `<button class="vp-ev ${e.type}${e.annulled ? ' off' : ''}${e.id === this.var.selectedId ? ' sel' : ''}" data-ev="${e.id}">
              <b>${e.clock}</b> ${esc(e.label)}${e.annulled ? ' <em>(anulado)</em>' : ''}
              <small>${esc(e.decision || e.detail)}</small></button>`
          )
          .join('')
      : '<p class="vp-empty">Nenhum acontecimento neste filtro.</p>';
    this.last.sig = '';
  }

  // ---- Detalhe do acontecimento e edição da decisão -------------------------------------------------------------

  renderDetail() {
    const box = this.root.querySelector('[data-role="detail"]');
    const d = this.var.detail();
    if (!d) {
      box.innerHTML = `<p class="vp-hint">Escolha um acontecimento na lista para ver a jogada e, se for um lance decidido por você, revisar a decisão. Você também pode arrastar a linha do tempo para analisar qualquer momento, mesmo sem infração.</p>${this.error ? `<p class="vp-error">${esc(this.error)}</p>` : ''}`;
      return;
    }
    const { event: ev, info } = d;
    let html = `<h3>${esc(ev.label)} · ${ev.clock} · ${ev.period}º tempo${ev.annulled ? ' <em>(anulado)</em>' : ''}</h3><p>${esc(ev.detail)}</p>`;

    if (info) {
      const inc = info.incident;
      if (this.draftFor !== inc.id) {
        this.draftFor = inc.id;
        this.draft = JSON.parse(JSON.stringify(info.original));
        this.confirming = false;
        this.error = '';
      }
      html += `<p class="vp-evid">Evidências: ${esc(inc.evidence.join(' · '))}</p>`;
      html += `<p class="vp-orig">Decisão tomada: <b>${esc(info.decision)}</b></p>`;
      html += d.canAlter.ok ? this.renderEditor(info) : `<p class="vp-hint">${esc(d.canAlter.reason)}</p>`;
    } else {
      html += `<p class="vp-hint">${esc(d.canAlter.reason)}</p>`;
      if (d.related.length) {
        html += `<p class="vp-orig">Lances da construção da jogada (toque para revisar a decisão):</p>${d.related
          .map((r) => `<button class="vp-ev incident" data-ev="${r.id}"><b>${r.clock}</b> ${esc(r.label)}<small>${esc(r.decision || r.detail)}</small></button>`)
          .join('')}`;
      }
    }
    if (this.error) html += `<p class="vp-error">${esc(this.error)}</p>`;
    box.innerHTML = html;
  }

  renderEditor(info) {
    const inc = info.incident;
    const offside = inc.type === INCIDENT.OFFSIDE || inc.type === INCIDENT.LEGAL_POSITION;
    const foulLabel = offside ? 'Impedimento marcado' : inc.type === INCIDENT.PENALTY ? 'Pênalti marcado' : 'Falta marcada';
    const who = (key, p) => `
      <div class="vp-who"><span>${esc(playerLabel(p))} <small>${esc(TEAMS[p.team].name)}${key === 'offender' ? ' · autor' : ' · sofreu'}</small></span>
        <div class="vp-row">${CARD_CHOICES.map((c) => `<button class="vp-chip ${c.id || 'none'}${this.draft.cards[key] === c.id ? ' sel' : ''}" data-card="${c.id || ''}" data-who="${key}">${c.label}</button>`).join('')}</div>
      </div>`;
    const changed = !sameChoice(this.draft, info.original);
    const cons = changed ? this.var.consequences(inc.id) : [];
    return `
      <div class="vp-editor">
        <div class="vp-row">
          <button class="vp-chip big${this.draft.foul ? ' sel' : ''}" data-foul="1">${foulLabel}</button>
          <button class="vp-chip big${!this.draft.foul ? ' sel' : ''}" data-foul="0">Seguir o jogo</button>
        </div>
        ${who('offender', inc.offender)}
        ${who('victim', inc.victim)}
        ${changed ? `<p class="vp-warn">Alterar a decisão faz o jogo voltar a este lance e recomeçar dali (o relógio não volta).${cons.length ? ` Será desfeito:<br>• ${cons.map(esc).join('<br>• ')}` : ''}</p>` : ''}
        <div class="vp-row">
          <button class="vp-btn" data-act="keep">Manter decisão</button>
          <button class="vp-btn primary" data-act="alter" ${changed ? '' : 'disabled'}>${this.confirming ? 'Confirmar alteração' : 'Alterar decisão'}</button>
        </div>
      </div>`;
  }

  // ---- Interação ------------------------------------------------------------------------------------------------

  onInput(e) {
    if (e.target.matches('[data-role="seek"]')) {
      this.var.seek(Number(e.target.value));
      this.var.playing = false;
    }
  }

  onClick(e) {
    const btn = e.target.closest('button');
    if (!btn || !this.open_ || btn.disabled) return;
    const v = this.var;
    const d = btn.dataset;

    if (d.ev !== undefined) this.select(Number(d.ev));
    else if (d.speed !== undefined) v.setSpeed(Number(d.speed));
    else if (d.cam !== undefined) v.setCamera(d.cam);
    else if (d.filter !== undefined) {
      this.filter = d.filter;
      this.renderList();
    } else if (d.foul !== undefined) this.edit(() => (this.draft.foul = d.foul === '1'));
    else if (d.card !== undefined) this.edit(() => (this.draft.cards[d.who] = d.card || null));
    else if (d.act) this.action(d.act);
  }

  select(id) {
    this.var.selectEvent(id);
    this.confirming = false;
    this.error = '';
    this.renderList();
    this.renderDetail();
  }

  edit(fn) {
    fn();
    this.confirming = false;
    this.error = '';
    this.renderDetail();
  }

  action(act) {
    const v = this.var;
    if (act === 'play') v.togglePlay();
    else if (act === 'start') v.jumpToPlayStart();
    else if (act === 'back') v.step(-2000);
    else if (act === 'fwd') v.step(2000);
    else if (act === 'frame-') v.step(-50);
    else if (act === 'frame+') v.step(50);
    else if (act === 'replay') v.replay();
    else if (act === 'close') this.onClose({ changed: false });
    else if (act === 'keep') this.keep();
    else if (act === 'alter') this.alter();
  }

  keep() {
    const d = this.var.detail();
    if (!d || !d.info) return;
    this.var.keepDecision(d.info.incident.id);
    this.onClose({ changed: false, kept: true });
  }

  alter() {
    const d = this.var.detail();
    if (!d || !d.info) return;
    const id = d.info.incident.id;
    if (!this.confirming && this.var.consequences(id).length) {
      this.confirming = true;
      this.renderDetail();
      return;
    }
    const res = this.var.alterDecision(id, this.draft);
    if (!res.ok) {
      this.error = res.reason || 'Não foi possível alterar a decisão.';
      this.confirming = false;
      this.renderDetail();
      return;
    }
    this.onClose({ changed: res.changed, kept: !res.changed });
  }

  handleKey(e) {
    if (!this.open_) return;
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    e.preventDefault();
    e.stopPropagation();
    if (performance.now() < this.ignoreUntil) return;
    if (e.repeat && !['ArrowLeft', 'ArrowRight'].includes(e.key)) return;

    const v = this.var;
    const k = e.key;
    if (k === ' ') v.togglePlay();
    else if (k === 'ArrowLeft') v.step(-2000);
    else if (k === 'ArrowRight') v.step(2000);
    else if (k === ',') v.step(-50);
    else if (k === '.') v.step(50);
    else if (k === '[') v.cycleSpeed(-1);
    else if (k === ']') v.cycleSpeed(1);
    else if (k === 'Enter') v.replay();
    else if (k === 'Home') v.jumpToPlayStart();
    else if (k >= '1' && k <= String(VAR_CAMERAS.length)) v.setCamera(VAR_CAMERAS[Number(k) - 1].id);
    else if (k.toLowerCase() === 'r' || k === 'Escape') this.onClose({ changed: false });
  }
}
