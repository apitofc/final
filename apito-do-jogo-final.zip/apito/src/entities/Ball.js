import Phaser from 'phaser';
export default class Ball extends Phaser.Physics.Arcade.Sprite {
  constructor(scene, x, y) {
    super(scene, x, y, 'ball');
    scene.add.existing(this);
    scene.physics.add.existing(this);

    this.setOrigin(0.5, 0.5);
    this.body.setSize(5, 5);

    this.shadow = scene.add.image(x, y + 2, 'ball_shadow').setDepth(1);
    this.trail = [];
    this.trailG = scene.add.graphics().setDepth(2);

    this.friction = 0.35; // fração da velocidade mantida a cada segundo

    // Estado de jogo lido pela IA e, futuramente, pelo sistema de arbitragem.
    this.lastTouchTeam = null;
    this.holder = null;
    this.lastPasser = null;
    this.lastPassTime = -Infinity;
    this.touchLock = 0; // segundos sem que outro jogador possa tocar
    this.refCooldown = 0;
  }

  get vx() {
    return this.body.velocity.x;
  }

  get vy() {
    return this.body.velocity.y;
  }

  // Coloca a bola parada em (x, y), por exemplo para uma cobrança.
  place(x, y) {
    this.trail.length = 0;
    this.body.reset(x, y);
    this.setPosition(x, y);
    this.setDepth(y);
    this.shadow.setPosition(Math.round(x), Math.round(y) + 2);
    this.touchLock = 0;
    this.holder = null;
  }

  kick(vx, vy) {
    this.body.setVelocity(vx, vy);
  }

  update(delta) {
    const dt = delta / 1000;
    const k = Math.pow(this.friction, dt);
    let vx = this.body.velocity.x * k;
    let vy = this.body.velocity.y * k;
    if (Math.hypot(vx, vy) < 5) {
      vx = 0;
      vy = 0;
    }

    // Rastro curto quando a bola está rápida.
    if (Math.hypot(vx, vy) > 130) {
      this.trail.push({ x: this.x, y: this.y });
      if (this.trail.length > 6) this.trail.shift();
    } else if (this.trail.length) {
      this.trail.shift();
    }
    this.trailG.clear();
    this.trail.forEach((t, i) => {
      this.trailG.fillStyle(0xffffff, ((i + 1) / this.trail.length) * 0.35);
      this.trailG.fillRect(Math.round(t.x) - 1, Math.round(t.y) - 1, 2, 2);
    });

    this.body.setVelocity(vx, vy);
    this.setDepth(this.y);
    this.shadow.setPosition(Math.round(this.x), Math.round(this.y) + 2);
  }
}
