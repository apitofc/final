// Gravador da partida para o VAR.
//
// Grava a partida inteira em "quadros" (cerca de 20 por segundo) com a posição, o sprite e a pose de todos os
// jogadores, do árbitro e da bola, além de uma linha do tempo de acontecimentos (lances, gols, cartões, bolas fora...).
// A reprodução do VAR lê só estes dados: nada é inventado nem simulado de novo.
//
// O relógio do gravador (`rt`, em ms) só avança, nunca volta: quando o VAR corrige um lance e a simulação é
// restaurada, a linha do tempo anterior continua guardada (marcada como anulada) e a nova segue depois dela.

const STEP_MS = 50; // intervalo mínimo entre quadros gravados
const HEADER = 7; // rt, matchMs, período, gols casa, gols fora, estado, corte
const STRIDE = 6; // x, y, quadro do sprite, espelhado, ângulo, em campo
const SNAP_DIST = 40; // deslocamento maior que isso entre quadros é um teletransporte (reinício), não se interpola
const MAX_FRAMES = 60000;
const STATE_CODE = { playing: 0, setpiece: 1, stopped: 2 };

const frameOf = (e) => {
  const n = e.frame && e.frame.name !== undefined ? Number(e.frame.name) : 0;
  return Number.isFinite(n) ? n : 0;
};

export default class VarRecorder {
  // actors: bola, árbitro e todos os jogadores (inclusive os que podem ser expulsos), nesta ordem.
  constructor({ ball, referee, players }) {
    this.actors = [ball, referee, ...players];
    this.playerCount = players.length;
    this.frames = [];
    this.events = [];
    this.voided = []; // trechos [from, to] da linha do tempo desfeitos por uma correção do VAR
    this.rt = 0;
    this.lastFrameRt = -Infinity;
    this.nextEventId = 1;
    this.full = false;

    // Estrutura reaproveitada a cada amostragem (evita criar objetos por quadro).
    this.view = {
      rt: 0,
      matchMs: 0,
      period: 1,
      score: { home: 0, away: 0 },
      state: 'playing',
      actors: this.actors.map(() => ({ x: 0, y: 0, frame: 0, flipX: false, angle: 0, present: true })),
    };
  }

  get length() {
    return this.frames.length;
  }

  // Instante do último quadro gravado.
  get end() {
    return this.frames.length ? this.frames[this.frames.length - 1][0] : 0;
  }

  // Chamado antes de cada passo da simulação.
  tick(ms) {
    this.rt += ms;
  }

  // Grava um quadro se já passou tempo suficiente desde o último (ou sempre, com force).
  capture(sim, { force = false, cut = false } = {}) {
    if (this.full) return false;
    if (!force && this.rt - this.lastFrameRt < STEP_MS) return false;
    if (force && this.rt === this.lastFrameRt) return false;
    if (this.frames.length >= MAX_FRAMES) {
      this.full = true;
      return false;
    }

    const f = new Float32Array(HEADER + this.actors.length * STRIDE);
    f[0] = this.rt;
    f[1] = sim.matchMs;
    f[2] = sim.period;
    f[3] = sim.score.home;
    f[4] = sim.score.away;
    f[5] = STATE_CODE[sim.state] ?? 0;
    f[6] = cut ? 1 : 0;
    for (let i = 0; i < this.actors.length; i++) {
      const a = this.actors[i];
      const o = HEADER + i * STRIDE;
      f[o] = a.x;
      f[o + 1] = a.y;
      f[o + 2] = frameOf(a);
      f[o + 3] = a.flipX ? 1 : 0;
      f[o + 4] = a.angle || 0;
      f[o + 5] = a.sentOff ? 0 : 1;
    }
    this.frames.push(f);
    this.lastFrameRt = this.rt;
    return true;
  }

  // Marca um corte na linha do tempo (a simulação foi restaurada): o quadro seguinte não é interpolado com o anterior.
  cutBranch(sim) {
    this.rt += 1;
    return this.capture(sim, { force: true, cut: true });
  }

  mark(type, data = {}) {
    const ev = { id: this.nextEventId++, rt: this.rt, type, annulled: false, ...data };
    this.events.push(ev);
    return ev;
  }

  // Marca como anulados os acontecimentos posteriores a `fromRt` (a linha do tempo foi desfeita a partir dali).
  voidSegment(fromRt, toRt) {
    this.voided.push({ from: fromRt, to: toRt });
    for (const ev of this.events) if (ev.rt > fromRt && ev.rt <= toRt) ev.annulled = true;
  }

  isVoided(rt) {
    return this.voided.some((v) => rt > v.from && rt <= v.to);
  }

  // Último acontecimento dos tipos pedidos até `rt` (para achar o início da jogada).
  lastBoundary(rt, types) {
    let best = null;
    for (const ev of this.events) {
      if (ev.rt >= rt) break;
      if (!ev.annulled && types.includes(ev.type)) best = ev.rt;
    }
    return best;
  }

  // Índice do último quadro com rt <= t.
  indexAt(t) {
    const fr = this.frames;
    if (!fr.length) return -1;
    let lo = 0;
    let hi = fr.length - 1;
    if (t <= fr[0][0]) return 0;
    if (t >= fr[hi][0]) return hi;
    while (lo < hi) {
      const mid = (lo + hi + 1) >> 1;
      if (fr[mid][0] <= t) lo = mid;
      else hi = mid - 1;
    }
    return lo;
  }

  // Amostra a partida no instante t, interpolando entre os dois quadros vizinhos. Devolve a estrutura `view`
  // (reaproveitada: não guarde a referência entre chamadas).
  sample(t) {
    const v = this.view;
    const fr = this.frames;
    if (!fr.length) return v;
    const i = this.indexAt(t);
    const a = fr[i];
    const b = i + 1 < fr.length ? fr[i + 1] : null;
    let k = 0;
    if (b && b[6] !== 1 && t > a[0]) k = Math.min(1, (t - a[0]) / Math.max(1, b[0] - a[0]));
    const near = k < 0.5 ? a : b || a;

    v.rt = Math.max(fr[0][0], Math.min(t, fr[fr.length - 1][0]));
    v.matchMs = a[1] + (b && k > 0 ? (b[1] - a[1]) * k : 0);
    v.period = near[2];
    v.score.home = near[3];
    v.score.away = near[4];
    v.state = Object.keys(STATE_CODE).find((s) => STATE_CODE[s] === near[5]) || 'playing';

    for (let n = 0; n < this.actors.length; n++) {
      const o = HEADER + n * STRIDE;
      const out = v.actors[n];
      const ax = a[o];
      const ay = a[o + 1];
      if (b && k > 0) {
        const bx = b[o];
        const by = b[o + 1];
        const jump = Math.hypot(bx - ax, by - ay) > SNAP_DIST;
        out.x = jump ? (k < 0.5 ? ax : bx) : ax + (bx - ax) * k;
        out.y = jump ? (k < 0.5 ? ay : by) : ay + (by - ay) * k;
      } else {
        out.x = ax;
        out.y = ay;
      }
      out.frame = near[o + 2];
      out.flipX = near[o + 3] === 1;
      out.angle = near[o + 4];
      out.present = near[o + 5] === 1;
    }
    return v;
  }
}

export const ACTOR = { BALL: 0, REFEREE: 1, FIRST_PLAYER: 2 };
