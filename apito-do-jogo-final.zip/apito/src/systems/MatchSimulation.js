import { FIELD, FIELD_RECT } from '../config.js';
import { getTarget, restartAction, decideTouch, inOwnPenaltyArea, opponentGoalX, ownGoalX, offsideInfo } from './PlayerAI.js';
import { POSE } from '../data/poses.js';
import { INCIDENT, classifyFoul, buildExpected } from './MatchRules.js';

const L = FIELD_RECT;
const TOUCH_RADIUS = 9;
const GK_TOUCH_RADIUS = 12;
const TACKLE_RANGE = 11;
const CONTROL_RADIUS = 14;
const TEAM_IDS = ['home', 'away'];
const NO_CHASER = { home: null, away: null };
const RESTART_RADIUS = { free_kick: 30, indirect_free_kick: 30, corner: 30, throw_in: 15 };
const SETPIECE_WAIT = { penalty: 1.5, free_kick: 1.5, indirect_free_kick: 1.5, corner: 1.2, throw_in: 0.9, goal_kick: 1.2, kickoff: 1.6 };
const GAME_SECONDS = 5400;

const dist = (ax, ay, bx, by) => Math.hypot(ax - bx, ay - by);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

export default class MatchSimulation {
  constructor(events, { ball, players, referee, rng, matchDurationMs = 300000, difficulty = {} }) {
    this.tackleGapBase = difficulty.tackleGap ?? 7;
    this.aggressionBonus = difficulty.aggressionBonus ?? 0;
    this.diveChance = difficulty.diveChance ?? 0.3;
    this.events = events;
    this.ball = ball;
    this.players = players;
    // Cópia da escalação inicial: jogadores expulsos saem de `players`, mas o VAR precisa poder trazê-los de volta.
    this.allPlayers = [...players];
    this.referee = referee;
    this.rng = rng;

    this.time = 0;
    this.state = 'playing';
    this.stopReason = null;
    this.setpiece = null;

    this.chaser = { home: null, away: null };
    this.receiver = { home: null, away: null };
    this.chaserTimer = 0;
    this.diveTimer = 0;
    this.offside = null; // { team, passer, offside[], close[], lineDefender, time } do último passe
    this.lastLegalTime = -Infinity;
    this.tackleGap = 0;

    this.score = { home: 0, away: 0 };
    this.stats = {
      home: { shots: 0, passes: 0, fouls: 0, corners: 0, possessionMs: 0 },
      away: { shots: 0, passes: 0, fouls: 0, corners: 0, possessionMs: 0 },
    };
    this.period = 1;
    this.matchMs = 0;
    this.matchDurationMs = matchDurationMs;
    this.halfMs = matchDurationMs / 2;
    this.extraMs = 0; // acréscimos do tempo atual (hoje só o VAR os concede, para a cobrança poder ser jogada)
    this.finished = false;
    this.goalTimer = 0;
    this.restartTeam = null;
    this.attackDirs = {
      home: players.find((p) => p.team === 'home')?.attackDir ?? 1,
      away: players.find((p) => p.team === 'away')?.attackDir ?? -1,
    };

    this.ctx = { ball, players, rng, chaser: this.chaser, possessionTeam: null, now: 0 };
    this.spCtx = { ball, players, rng, chaser: NO_CHASER, possessionTeam: null, now: 0 };

    this.initPlayers();
    this.updateChasers();
  }

  initPlayers() {
    for (const p of this.players) {
      p.aggression = 0.15 + this.rng.frac() * 0.5 + this.aggressionBonus;
      p.actor = this.rng.frac() * 0.4;
      p.fallTimer = 0;
      p.freezeTimer = 0;
      p.tackleCooldown = 0;
      p.tackleImmunity = 0;
      p.diveCooldown = 0;
      p.yellowCards = 0;
      p.sentOff = false;
      // Atacantes: quanto arriscam em relação à linha de impedimento (negativo = ficam atrás, positivo = passam).
      p.lineBias = p.role === 'FWD' ? -10 + this.rng.frac() * 26 : 0;
    }
    for (const id of TEAM_IDS) {
      const team = this.players.filter((p) => p.team === id);
      const field = team.filter((p) => p.role === 'DEF' || p.role === 'MID');
      for (let i = 0; i < 2 && field.length; i++) {
        const k = Math.floor(this.rng.frac() * field.length);
        field[k].aggression = Math.min(0.85 + this.aggressionBonus, field[k].aggression + 0.2);
      }
      const attackers = team.filter((p) => p.role === 'FWD' || p.role === 'MID');
      if (attackers.length) attackers[Math.floor(this.rng.frac() * attackers.length)].actor = 0.9;
    }
  }

  update(delta) {
    const ms = Math.min(delta, 50);
    const dt = ms / 1000;
    this.time += ms;
    this.ctx.now = this.time;
    this.spCtx.now = this.time;
    this.ctx.possessionTeam = this.ball.lastTouchTeam;

    for (const p of this.players) {
      p.touchCooldown = Math.max(0, p.touchCooldown - dt);
      p.fallTimer = Math.max(0, p.fallTimer - dt);
      p.freezeTimer = Math.max(0, p.freezeTimer - dt);
      p.tackleCooldown = Math.max(0, p.tackleCooldown - dt);
      p.tackleImmunity = Math.max(0, p.tackleImmunity - dt);
      p.diveCooldown = Math.max(0, p.diveCooldown - dt);
    }
    this.ball.touchLock = Math.max(0, this.ball.touchLock - dt);
    this.ball.refCooldown = Math.max(0, this.ball.refCooldown - dt);

    if (this.state !== 'stopped') this.matchMs += ms;

    if (this.state === 'playing') this.updatePlaying(ms, dt);
    else if (this.state === 'stopped') this.updateStopped(ms, dt);
    else this.updateSetPiece(ms, dt);

    if (this.state === 'playing' && !this.finished && this.matchMs >= this.periodEnd()) this.endPeriod();
  }

  updatePlaying(ms, dt) {
    if (this.ball.holder) this.ball.holder.holdTimer += ms;
    if (this.ball.lastTouchTeam) this.stats[this.ball.lastTouchTeam].possessionMs += ms;
    this.tackleGap = Math.max(0, this.tackleGap - dt);
    if (this.offside && this.time - this.offside.time > 3500) this.offside = null;

    for (const id of TEAM_IDS) {
      const r = this.receiver[id];
      if (r) {
        r.timer -= dt;
        if (r.timer <= 0) this.receiver[id] = null;
      }
    }

    this.chaserTimer -= dt;
    if (this.chaserTimer <= 0) {
      this.updateChasers();
      this.chaserTimer = 0.2;
    }

    for (const p of this.players) this.movePlayer(p, ms);

    this.updateTackles();
    this.diveTimer -= dt;
    if (this.diveTimer <= 0) {
      this.diveTimer = 0.4;
      this.checkDive();
    }
    this.handleTouches();
    this.ball.update(ms);
    this.checkBall();
  }

  updateStopped(ms, dt) {
    for (const p of this.players) this.stepPlayer(p, ms, { x: 0, y: 0 });
    this.ball.update(ms);

    if (this.stopReason === 'goal') {
      this.goalTimer -= dt;
      if (this.goalTimer <= 0) this.startSetPiece('kickoff', this.restartTeam);
    }
  }

  updateSetPiece(ms, dt) {
    const sp = this.setpiece;
    sp.timer -= dt;
    for (const p of this.players) this.movePlayer(p, ms);

    if (!sp.taker || !this.players.includes(sp.taker)) sp.taker = this.pickTaker(sp.team, sp.type);
    const t = sp.taker;
    if (t) {
      const ready = sp.timer <= 0 && t.fallTimer <= 0 && dist(t.x, t.y - 2, this.ball.x, this.ball.y) < 11;
      if (ready || sp.timer < -4) {
        const action = restartAction(t, this.spCtx, sp.type);
        // Impedimento vale em jogo corrido e tiro livre, não em lateral, escanteio, tiro de meta, pênalti ou saída.
        this.applyTouch(t, action, { noOffside: !['free_kick', 'indirect_free_kick'].includes(sp.type) });
        this.state = 'playing';
        this.setpiece = null;
        this.ball.touchLock = 0.25;
        this.updateChasers();
        this.events.emit('play-resumed', { time: this.time, reason: 'restart' });
      }
    }
    this.ball.update(ms);
  }

  stopPlay(reason) {
    this.offside = null;
    if (this.state === 'stopped') return;
    this.state = 'stopped';
    this.stopReason = reason;
    this.setpiece = null;
    this.ball.kick(0, 0);
    this.events.emit('play-stopped', { reason, time: this.time });
  }

  resumeDrop() {
    this.state = 'playing';
    this.stopReason = null;
    this.setpiece = null;
    this.ball.touchLock = 0.5;
    this.updateChasers();
    this.events.emit('play-resumed', { time: this.time, reason: 'drop' });
  }

  startSetPiece(type, team, x, y) {
    this.offside = null;
    const attackDir = this.attackDirs[team];
    let bx = clamp(x ?? L.cx, L.left + 4, L.right - 4);
    let by = clamp(y ?? L.cy, L.top + 4, L.bottom - 4);
    if (type === 'penalty') {
      bx = opponentGoalX(attackDir) - attackDir * FIELD.penaltySpot;
      by = L.cy;
    } else if (type === 'kickoff') {
      bx = L.cx;
      by = L.cy;
      this.resetPositions();
    }

    this.ball.place(bx, by);
    this.ball.lastTouchTeam = team;
    this.state = 'setpiece';
    this.stopReason = null;
    this.spCtx.possessionTeam = team;
    this.setpiece = {
      type,
      team,
      attackDir,
      x: bx,
      y: by,
      timer: SETPIECE_WAIT[type] ?? 1.5,
      taker: this.pickTaker(team, type, bx, by),
    };
    for (const p of this.players) p.holdTimer = 0;
    this.events.emit('setpiece-start', { type, team, x: bx, y: by, time: this.time });
  }

  pickTaker(team, type, bx = this.ball.x, by = this.ball.y) {
    let pool = this.players.filter((p) => p.team === team && p.fallTimer <= 0);
    if (type === 'goal_kick') {
      const gk = pool.find((p) => p.role === 'GK');
      if (gk) return gk;
    }
    const outfield = pool.filter((p) => p.role !== 'GK');
    if (outfield.length) pool = outfield;
    if (type === 'penalty' || type === 'kickoff') {
      const fwd = pool.filter((p) => p.role === 'FWD');
      if (fwd.length) pool = fwd;
    }
    let best = null;
    let bd = Infinity;
    for (const p of pool) {
      const d = dist(p.x, p.y, bx, by);
      if (d < bd) {
        bd = d;
        best = p;
      }
    }
    return best;
  }

  sendOff(player) {
    const i = this.players.indexOf(player);
    if (i < 0) return;
    this.players.splice(i, 1);
    player.sentOff = true;
    if (this.ball.holder === player) this.ball.holder = null;
    for (const id of TEAM_IDS) {
      if (this.receiver[id] && this.receiver[id].player === player) this.receiver[id] = null;
    }
    this.updateChasers();
    this.events.emit('player-sent-off', { player, time: this.time });
  }

  updateChasers() {
    const ball = this.ball;
    for (const id of TEAM_IDS) {
      const team = this.players.filter((p) => p.team === id);
      const gk = team.find((p) => p.role === 'GK');

      if (gk && inOwnPenaltyArea(gk.attackDir, ball.x, ball.y) && dist(gk.x, gk.y, ball.x, ball.y) < 70) {
        this.chaser[id] = gk;
        continue;
      }

      const r = this.receiver[id];
      if (r) {
        this.chaser[id] = r.player;
        continue;
      }

      let best = null;
      let bestScore = Infinity;
      for (const p of team) {
        if (p.role === 'GK' || p.fallTimer > 0) continue;
        let score = dist(p.x, p.y, ball.x, ball.y);
        if (this.chaser[id] === p) score -= 14;
        if (score < bestScore) {
          bestScore = score;
          best = p;
        }
      }
      this.chaser[id] = best;
    }
  }

  setPieceTarget(p) {
    const sp = this.setpiece;
    if (p === sp.taker) {
      const d = dist(p.x, p.y - 2, this.ball.x, this.ball.y);
      return { x: this.ball.x - sp.attackDir * 6, y: this.ball.y + 2, speed: d > 3 ? 0.8 : 0 };
    }
    if (sp.type === 'kickoff') return this.kickoffTarget(p);

    const base = getTarget(p, this.spCtx);
    let { x, y } = base;
    let speed = base.speed;
    const defendingTeam = p.team !== sp.team;

    if (sp.type === 'penalty') {
      const goalX = opponentGoalX(sp.attackDir);
      const inward = -sp.attackDir;
      if (defendingTeam && p.role === 'GK') return { x: goalX + inward * 2, y: L.cy, speed: 0.7 };
      const limit = FIELD.penaltyDepth + 12;
      const depth = (x - goalX) * inward;
      if (depth < limit && Math.abs(y - L.cy) < FIELD.penaltyWidth / 2 + 12) {
        x = goalX + inward * limit;
        speed = Math.max(speed, 0.9);
      }
    } else if (sp.type === 'goal_kick') {
      if (defendingTeam && p.role !== 'GK') {
        const goalX = ownGoalX(sp.attackDir);
        const limit = FIELD.penaltyDepth + 10;
        const depth = (x - goalX) * sp.attackDir;
        if (depth < limit && Math.abs(y - L.cy) < FIELD.penaltyWidth / 2 + 10) {
          x = goalX + sp.attackDir * limit;
          speed = Math.max(speed, 0.9);
        }
      }
    } else if (defendingTeam) {
      const radius = RESTART_RADIUS[sp.type] ?? 30;
      const dx = x - this.ball.x;
      const dy = y - this.ball.y;
      const d = Math.hypot(dx, dy);
      if (d < radius) {
        const ux = d > 0.01 ? dx / d : -sp.attackDir;
        const uy = d > 0.01 ? dy / d : 0;
        x = this.ball.x + ux * radius;
        y = this.ball.y + uy * radius;
        speed = Math.max(speed, 0.9);
      }
    }
    return { x: clamp(x, L.left + 3, L.right - 3), y: clamp(y, L.top + 3, L.bottom - 3), speed };
  }

  kickoffTarget(p) {
    const sp = this.setpiece;
    const spawn = this.spawnPos(p);
    let { x, y } = spawn;
    if (p.team !== sp.team) {
      const dx = x - L.cx;
      const dy = y - L.cy;
      const d = Math.hypot(dx, dy);
      if (d < 38) {
        const sign = -p.attackDir;
        const ux = d > 0.01 ? dx / d : sign;
        const uy = d > 0.01 ? dy / d : 0;
        x = L.cx + ux * 38;
        y = L.cy + uy * 38;
        if ((x - L.cx) * sign < 0) x = L.cx + sign * Math.abs(x - L.cx);
      }
    }
    return { x, y, speed: dist(p.x, p.y, x, y) > 2 ? 0.8 : 0 };
  }

  movePlayer(p, ms) {
    if (p.fallTimer > 0 || p.freezeTimer > 0) {
      this.stepPlayer(p, ms, { x: 0, y: 0 });
      return;
    }

    const target = this.state === 'setpiece' ? this.setPieceTarget(p) : getTarget(p, this.ctx);
    const dx = target.x - p.x;
    const dy = target.y - p.y;
    const len = Math.hypot(dx, dy);
    let mx = 0;
    let my = 0;
    if (len > 1.5) {
      mx = (dx / len) * target.speed;
      my = (dy / len) * target.speed;
    }

    const others = this.referee ? [...this.players, this.referee] : this.players;
    for (const o of others) {
      if (o === p) continue;
      const ddx = p.x - o.x;
      const ddy = p.y - o.y;
      const dd = Math.hypot(ddx, ddy);
      const radius = o === this.referee ? 14 : 11;
      if (dd < radius && dd > 0.01) {
        const push = ((radius - dd) / radius) * 0.9;
        mx += (ddx / dd) * push;
        my += (ddy / dd) * push;
      }
    }

    this.stepPlayer(p, ms, { x: mx, y: my });
  }

  stepPlayer(p, ms, move) {
    p.update(ms, move);
    if (p.setFallen) p.setFallen(p.fallTimer > 0);
  }

  handleTouches() {
    const ball = this.ball;
    if (ball.touchLock > 0) return;

    const h = ball.holder;
    const controlled = h && h.fallTimer <= 0 && dist(h.x, h.y - 2, ball.x, ball.y) < CONTROL_RADIUS;

    let toucher = null;
    let bestDist = Infinity;
    for (const p of this.players) {
      if (p.touchCooldown > 0 || p.fallTimer > 0) continue;
      if (controlled && p.team !== h.team) continue;
      const d = dist(p.x, p.y - 2, ball.x, ball.y);
      const reach = p.role === 'GK' ? GK_TOUCH_RADIUS : TOUCH_RADIUS;
      if (d < reach && d < bestDist) {
        bestDist = d;
        toucher = p;
      }
    }
    if (toucher) this.applyTouch(toucher, decideTouch(toucher, this.ctx));
  }

  applyTouch(p, action, opts = {}) {
    this.checkOffsideTouch(p);
    const ball = this.ball;
    ball.kick(action.vx, action.vy);
    ball.touchLock = 0.1;
    ball.lastTouchTeam = p.team;
    if (ball.holder !== p) {
      ball.holder = p;
      p.holdTimer = 0;
    }
    p.touchCooldown = action.type === 'dribble' ? 0.22 : 0.55;
    if (action.type === 'shoot') this.stats[p.team].shots += 1;
    if (action.type === 'pass') this.stats[p.team].passes += 1;

    // O receptor já chegou na bola.
    if (this.receiver[p.team] && this.receiver[p.team].player === p) this.receiver[p.team] = null;
    if (action.type === 'pass') {
      ball.lastPasser = p;
      ball.lastPassTime = this.time;
      this.receiver[p.team] = { player: action.receiver, timer: 1.3 };
      this.updateChasers();
    }
    // Pose de chute (só no jogo real, onde o sprite existe).
    if (p.setPose && ['shoot', 'pass', 'clear', 'cross'].includes(action.type)) {
      p.dir = 2;
      p.setFlipX(action.vx < 0);
      p.setPose(POSE.kick, 200);
    }
    if (action.type === 'pass' && !opts.noOffside) this.recordPass(p);

    this.events.emit('player-touch', { player: p, action: action.type, speed: Math.hypot(action.vx, action.vy), time: this.time });
  }

  updateTackles() {
    const ball = this.ball;
    const h = ball.holder;
    if (this.tackleGap > 0) return;
    if (!h || h.role === 'GK' || h.fallTimer > 0 || h.tackleImmunity > 0) return;
    if (dist(h.x, h.y - 2, ball.x, ball.y) > CONTROL_RADIUS) return;

    let tackler = null;
    let bd = Infinity;
    for (const o of this.players) {
      if (o.team === h.team || o.role === 'GK' || o.fallTimer > 0 || o.freezeTimer > 0 || o.tackleCooldown > 0) continue;
      const d = dist(o.x, o.y, h.x, h.y);
      if (d < TACKLE_RANGE && d < bd) {
        bd = d;
        tackler = o;
      }
    }
    if (tackler) this.resolveTackle(tackler, h);
  }

  resolveTackle(t, h) {
    t.tackleCooldown = 1.3;
    h.tackleImmunity = 0.8;
    this.tackleGap = this.tackleGapBase;

    const relSpeed = Math.hypot(t.vx - h.vx, t.vy - h.vy);
    const hs = Math.hypot(h.vx, h.vy);
    const hx = hs > 12 ? h.vx / hs : h.attackDir;
    const hy = hs > 12 ? h.vy / hs : 0;
    const d = dist(t.x, t.y, h.x, h.y) || 1;
    const fromBehind = ((t.x - h.x) / d) * hx + ((t.y - h.y) / d) * hy < -0.35;

    const pClean = clamp(0.74 - t.aggression * 0.3 - (fromBehind ? 0.2 : 0), 0.15, 0.8);

    if (this.rng.frac() < pClean) {
      this.applyTouch(t, decideTouch(t, this.ctx));
      if (relSpeed >= 30) {
        this.registerIncident({
          type: INCIDENT.CHALLENGE,
          level: 'none',
          offender: t,
          victim: h,
          evidence: ['bola jogada primeiro', relSpeed > 60 ? 'disputa forte' : 'disputa normal'],
          contact: true,
        });
      }
      return;
    }

    const cls = classifyFoul({ relSpeed, fromBehind, aggression: t.aggression });
    const inArea = inOwnPenaltyArea(t.attackDir, h.x, h.y);
    const type = inArea ? INCIDENT.PENALTY : cls.level === 'light' ? INCIDENT.LIGHT_FOUL : INCIDENT.SERIOUS_FOUL;

    h.fallTimer = cls.level === 'red' ? 2.2 : cls.level === 'yellow' ? 1.6 : 1.0;
    t.freezeTimer = 0.6;
    this.ball.kick(hx * 35, hy * 35);
    this.ball.holder = null;
    this.ball.lastTouchTeam = h.team;

    const evidence = [...cls.evidence];
    if (inArea) evidence.push('dentro da área');
    this.registerIncident({ type, level: cls.level, offender: t, victim: h, evidence, contact: true, inArea });
  }

  checkDive() {
    const ball = this.ball;
    const h = ball.holder;
    if (!h || h.role === 'GK' || h.actor < 0.6 || h.diveCooldown > 0 || h.fallTimer > 0) return;
    if (dist(h.x, h.y - 2, ball.x, ball.y) > CONTROL_RADIUS) return;

    let near = null;
    let nd = Infinity;
    for (const o of this.players) {
      if (o.team === h.team || o.role === 'GK') continue;
      const d = dist(o.x, o.y, h.x, h.y);
      if (d >= 12 && d < 26 && d < nd) {
        nd = d;
        near = o;
      }
    }
    if (!near || this.rng.frac() >= this.diveChance) return;

    h.diveCooldown = 25;
    h.fallTimer = 1.1;
    ball.kick(0, 0);
    ball.holder = null;
    ball.lastTouchTeam = h.team;

    const inArea = inOwnPenaltyArea(near.attackDir, h.x, h.y);
    const evidence = ['sem contato', 'queda antes do contato', `adversário a ${Math.round(nd)}px`];
    if (inArea) evidence.push('dentro da área');
    this.registerIncident({ type: INCIDENT.SIMULATION, level: 'none', offender: near, victim: h, evidence, contact: false, inArea });
  }

  registerIncident({ type, level, offender, victim, evidence, contact, inArea = false, at = null }) {
    const ref = this.referee;
    const ix = at ? at.x : victim.x;
    const iy = at ? at.y : victim.y;
    const incident = {
      id: null,
      type,
      period: this.period,
      clock: this.getClock().text,
      level,
      time: this.time,
      x: ix,
      y: iy,
      offender,
      victim,
      evidence,
      contact,
      inArea,
      refDistance: ref ? dist(ref.x, ref.y, ix, iy) : null,
      expected: buildExpected(type, level),
    };
    if (type === INCIDENT.LIGHT_FOUL || type === INCIDENT.SERIOUS_FOUL || type === INCIDENT.PENALTY) {
      this.stats[offender.team].fouls += 1;
    }
    this.events.emit('incident', incident);
    return incident;
  }

  checkBall() {
    const b = this.ball;
    const outX = b.x < L.left || b.x > L.right;
    const outY = b.y < L.top || b.y > L.bottom;
    if (!outX && !outY) return;

    const last = b.lastTouchTeam;
    const opposite = (t) => (t === 'home' ? 'away' : 'home');

    if (outX) {
      const atLeft = b.x < L.left;
      const defTeam = this.attackDirs.home > 0 === atLeft ? 'home' : 'away';
      const attTeam = opposite(defTeam);

      if (Math.abs(b.y - L.cy) <= FIELD.goalWidth / 2) {
        this.scoreGoal(attTeam);
      } else if (last === defTeam) {
        const cx = atLeft ? L.left + 3 : L.right - 3;
        const cy = b.y < L.cy ? L.top + 3 : L.bottom - 3;
        this.stats[attTeam].corners += 1;
        this.startSetPiece('corner', attTeam, cx, cy);
      } else {
        const dir = this.attackDirs[defTeam];
        this.startSetPiece('goal_kick', defTeam, ownGoalX(dir) + dir * 14, L.cy);
      }
      return;
    }

    const team = last ? opposite(last) : 'home';
    const ty = b.y < L.top ? L.top + 3 : L.bottom - 3;
    this.startSetPiece('throw_in', team, clamp(b.x, L.left + 8, L.right - 8), ty);
  }

  // Guarda quem estava em posição de impedimento no momento do passe.
  recordPass(p) {
    const info = offsideInfo(p, this.players, p.x);
    this.offside = { team: p.team, passer: p, offside: info.offside, close: info.close, lineDefender: info.lineDefender, time: this.time };
  }

  // A infração só existe quando o jogador em posição de impedimento participa do lance (toca na bola).
  checkOffsideTouch(p) {
    const st = this.offside;
    if (!st) return;
    this.offside = null;
    if (p.team !== st.team || p === st.passer) return;

    const off = st.offside.find((e) => e.player === p);
    const close = st.close.find((e) => e.player === p);
    const defender = st.lineDefender || this.players.find((o) => o.team !== p.team);
    if (!defender) return;
    const passer = st.passer.name || `#${st.passer.number}`;

    if (off) {
      this.registerIncident({
        type: INCIDENT.OFFSIDE,
        level: 'none',
        offender: p,
        victim: defender,
        evidence: ['posição de impedimento no passe', `${Math.round(off.margin)}px além da linha`, `passe de ${passer}`],
        contact: false,
        at: { x: p.x, y: p.y },
      });
    } else if (close && this.time - this.lastLegalTime > 12000) {
      this.lastLegalTime = this.time;
      const gap = Math.abs(Math.round(close.margin));
      this.registerIncident({
        type: INCIDENT.LEGAL_POSITION,
        level: 'none',
        offender: p,
        victim: defender,
        evidence: ['posição legal no passe', gap <= 1 ? 'em linha com o penúltimo defensor' : `${gap}px atrás da linha`, `passe de ${passer}`],
        contact: false,
        at: { x: p.x, y: p.y },
      });
    }
  }

  // Jogadores perto do lance reclamam da decisão (apenas visual).
  protest(team, x, y) {
    const near = this.players
      .filter((p) => p.team === team && p.fallTimer <= 0)
      .sort((a, b) => dist(a.x, a.y, x, y) - dist(b.x, b.y, x, y))
      .slice(0, 3);
    for (const p of near) {
      if (p.setPose) {
        p.dir = 0;
        p.setFlipX(false);
        p.setPose(POSE.protest, 1600);
      }
    }
  }

  scoreGoal(team) {
    const holder = this.ball.holder;
    this.score[team] += 1;
    this.stopPlay('goal');
    this.goalTimer = 2.8;
    this.restartTeam = team === 'home' ? 'away' : 'home';
    this.events.emit('goal', {
      team,
      scorer: holder && holder.team === team ? holder : null,
      score: { ...this.score },
      clock: this.getClock().text,
    });
    for (const p of this.players) {
      if (p.team === team && p.setPose) p.setPose(POSE.cheer, 2600);
    }
  }

  // Anula o gol que acabou de sair (só durante a pausa do gol). O placar volta e o jogo recomeça pela falta ou
  // impedimento que originou o gol; sem infração (gol válido anulado por engano) recomeça com tiro de meta.
  // cause = { type, x, y, victim: { team } } ou null.
  disallowGoal(team, cause) {
    if (this.state !== 'stopped' || this.stopReason !== 'goal') return false;
    this.score[team] = Math.max(0, this.score[team] - 1);
    this.goalTimer = 0;
    if (cause) {
      const indirect = cause.type === 'offside';
      this.startSetPiece(indirect ? 'indirect_free_kick' : 'free_kick', cause.victim.team, cause.x, cause.y);
    } else {
      const defTeam = team === 'home' ? 'away' : 'home';
      const dir = this.attackDirs[defTeam];
      this.startSetPiece('goal_kick', defTeam, ownGoalX(dir) + dir * 14, L.cy);
    }
    this.events.emit('goal-disallowed', { team, score: { ...this.score }, clock: this.getClock().text, cause: cause ? cause.type : null });
    return true;
  }

  spawnPos(p) {
    const ownX = p.attackDir > 0 ? L.left : L.right;
    const nx = p.role === 'GK' ? p.nx : Math.min(p.nx, 0.46);
    return { x: ownX + p.attackDir * nx * FIELD.width, y: L.top + p.ny * FIELD.height };
  }

  resetPositions() {
    for (const p of this.players) {
      const pos = this.spawnPos(p);
      p.placeAt(pos.x, pos.y);
      p.fallTimer = 0;
      p.freezeTimer = 0;
      p.touchCooldown = 0;
      p.holdTimer = 0;
      if (p.setFallen) p.setFallen(false);
    }
    this.ball.holder = null;
    this.receiver.home = null;
    this.receiver.away = null;
  }

  swapSides() {
    this.attackDirs.home *= -1;
    this.attackDirs.away *= -1;
    for (const p of this.players) p.attackDir = this.attackDirs[p.team];
  }

  baseEnd(period = this.period) {
    return period === 1 ? this.halfMs : this.matchDurationMs;
  }

  periodEnd() {
    return this.baseEnd() + this.extraMs;
  }

  // Garante um mínimo de tempo de jogo para uma cobrança concedida depois do apito final do tempo (ex.: pênalti do VAR).
  ensureRestartTime(minMs = 15000) {
    const need = this.matchMs + minMs;
    if (need > this.periodEnd()) this.extraMs += need - this.periodEnd();
  }

  endPeriod() {
    this.ball.kick(0, 0);
    this.state = 'stopped';
    this.setpiece = null;
    if (this.period === 1) {
      this.stopReason = 'halftime';
      this.events.emit('halftime', { score: { ...this.score }, time: this.time });
    } else {
      this.stopReason = 'fulltime';
      this.finished = true;
      this.events.emit('fulltime', { score: { ...this.score }, time: this.time });
    }
  }

  startSecondHalf() {
    if (this.state !== 'stopped' || this.stopReason !== 'halftime') return;
    this.period = 2;
    this.extraMs = 0;
    this.swapSides();
    this.startSetPiece('kickoff', 'away');
  }

  // Relógio mostrado para um instante qualquer (usado também pelo VAR para rotular os quadros gravados).
  clockAt(matchMs, period) {
    const base = this.baseEnd(period);
    const shown = Math.min(matchMs, base);
    const sec = Math.floor((shown / this.matchDurationMs) * GAME_SECONDS);
    const mm = String(Math.floor(sec / 60)).padStart(2, '0');
    const ss = String(sec % 60).padStart(2, '0');
    return { text: `${mm}:${ss}`, period, added: matchMs > base };
  }

  getClock() {
    return this.clockAt(this.matchMs, this.period);
  }

  // ---- Estado completo, para o VAR desfazer lances (ver VarSystem) ----------------------------------------------

  captureState() {
    const copyTeams = (o) => ({ home: o.home ? { ...o.home } : null, away: o.away ? { ...o.away } : null });
    const ball = this.ball;
    return {
      time: this.time,
      state: this.state,
      stopReason: this.stopReason,
      period: this.period,
      matchMs: this.matchMs,
      extraMs: this.extraMs,
      goalTimer: this.goalTimer,
      restartTeam: this.restartTeam,
      chaserTimer: this.chaserTimer,
      diveTimer: this.diveTimer,
      lastLegalTime: this.lastLegalTime,
      tackleGap: this.tackleGap,
      score: { ...this.score },
      stats: JSON.parse(JSON.stringify(this.stats)),
      attackDirs: { ...this.attackDirs },
      setpiece: this.setpiece ? { ...this.setpiece } : null,
      chaser: { ...this.chaser },
      receiver: copyTeams(this.receiver),
      offside: this.offside ? { ...this.offside } : null,
      roster: [...this.players],
      players: this.allPlayers.map((p) => ({
        p,
        x: p.x,
        y: p.y,
        vx: p.vx,
        vy: p.vy,
        fallTimer: p.fallTimer,
        freezeTimer: p.freezeTimer,
        tackleCooldown: p.tackleCooldown,
        tackleImmunity: p.tackleImmunity,
        diveCooldown: p.diveCooldown,
        touchCooldown: p.touchCooldown,
        holdTimer: p.holdTimer,
        yellowCards: p.yellowCards,
        sentOff: p.sentOff,
        dir: p.dir,
        flipX: !!p.flipX,
        poseTimer: p.poseTimer,
        poseFrame: p.poseFrame,
      })),
      ball: {
        x: ball.x,
        y: ball.y,
        vx: ball.vx,
        vy: ball.vy,
        lastTouchTeam: ball.lastTouchTeam,
        holder: ball.holder,
        lastPasser: ball.lastPasser,
        lastPassTime: ball.lastPassTime,
        touchLock: ball.touchLock,
        refCooldown: ball.refCooldown,
      },
    };
  }

  // Restaura tudo menos o relógio da partida (matchMs) e o árbitro: o tempo de revisão não volta, e quem
  // apita continua onde está. `time` (usado só para janelas dos lances) volta junto com o resto.
  restoreState(s) {
    const setVel = (o, vx, vy) => {
      if (o.body && o.body.setVelocity) o.body.setVelocity(vx, vy);
      else {
        o.vx = vx;
        o.vy = vy;
      }
    };

    this.time = s.time;
    this.ctx.now = s.time;
    this.spCtx.now = s.time;
    this.state = s.state;
    this.stopReason = s.stopReason;
    this.period = s.period;
    this.extraMs = s.extraMs;
    this.goalTimer = s.goalTimer;
    this.restartTeam = s.restartTeam;
    this.chaserTimer = s.chaserTimer;
    this.diveTimer = s.diveTimer;
    this.lastLegalTime = s.lastLegalTime;
    this.tackleGap = s.tackleGap;
    this.score.home = s.score.home;
    this.score.away = s.score.away;
    for (const id of TEAM_IDS) Object.assign(this.stats[id], s.stats[id]);
    Object.assign(this.attackDirs, s.attackDirs);
    this.setpiece = s.setpiece ? { ...s.setpiece } : null;
    this.offside = s.offside ? { ...s.offside } : null;
    for (const id of TEAM_IDS) {
      this.chaser[id] = s.chaser[id];
      this.receiver[id] = s.receiver[id] ? { ...s.receiver[id] } : null;
    }

    // O array é o mesmo usado pela cena e pela IA: é alterado no lugar.
    this.players.length = 0;
    this.players.push(...s.roster);
    for (const e of s.players) {
      const p = e.p;
      const wasSentOff = p.sentOff;
      if (p.placeAt) p.placeAt(e.x, e.y);
      else {
        p.x = e.x;
        p.y = e.y;
      }
      setVel(p, e.vx, e.vy);
      p.fallTimer = e.fallTimer;
      p.freezeTimer = e.freezeTimer;
      p.tackleCooldown = e.tackleCooldown;
      p.tackleImmunity = e.tackleImmunity;
      p.diveCooldown = e.diveCooldown;
      p.touchCooldown = e.touchCooldown;
      p.holdTimer = e.holdTimer;
      p.yellowCards = e.yellowCards;
      p.sentOff = e.sentOff;
      p.dir = e.dir;
      p.poseTimer = e.poseTimer;
      p.poseFrame = e.poseFrame;
      if (p.setFlipX) p.setFlipX(e.flipX);
      if (wasSentOff && !e.sentOff && p.revive) p.revive();
      if (p.setFallen) p.setFallen(p.fallTimer > 0);
    }

    const b = this.ball;
    const bs = s.ball;
    b.place(bs.x, bs.y);
    setVel(b, bs.vx, bs.vy);
    b.lastTouchTeam = bs.lastTouchTeam;
    b.holder = bs.holder;
    b.lastPasser = bs.lastPasser;
    b.lastPassTime = bs.lastPassTime;
    b.touchLock = bs.touchLock;
    b.refCooldown = bs.refCooldown;
  }
}
