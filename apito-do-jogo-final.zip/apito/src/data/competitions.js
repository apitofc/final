const club = (id, name, shirt, shorts, accent, alt) => ({ id, name, shirt, shorts, accent, alt });

export const COMPETITIONS = [
  {
    id: 'varzea', name: 'Copa Várzea Verde', tier: 0, unlockRep: 0, importance: 1,
    clubs: [
      club('tamarindo', 'Tamarindo FC', '#e0a82e', '#222222', '#222222', '#3c6fd6'),
      club('jaqueira', 'Jaqueira EC', '#2f9e6a', '#f2f2f2', '#f2f2f2', '#e8e8e8'),
      club('moinho', 'Moinho AC', '#9b3fd0', '#f2f2f2', '#f2f2f2', '#e0e0e0'),
      club('cacimba', 'Cacimba FC', '#d9553a', '#222222', '#f2f2f2', '#f0e0c0'),
      club('pitangueira', 'Pitangueira EC', '#c2306a', '#f2f2f2', '#f2f2f2', '#e8e8e8'),
      club('lagoaseca', 'Lagoa Seca', '#3aa0c8', '#1c3a66', '#f2f2f2', '#f0f0f0'),
    ],
  },
  {
    id: 'regional', name: 'Liga Regional do Litoral', tier: 1, unlockRep: 15, importance: 1,
    clubs: [
      club('maresia', 'Maresia SC', '#2f6fd6', '#f2f2f2', '#f2f2f2', '#f0f0f0'),
      club('coqueiral', 'Coqueiral FC', '#3fae4a', '#f2f2f2', '#ffe066', '#f0f0f0'),
      club('dunas', 'Dunas AC', '#e8c24a', '#2b2b2b', '#2b2b2b', '#6fa0e0'),
      club('jangada', 'Jangada EC', '#d6452e', '#f2f2f2', '#f2f2f2', '#f0e8d0'),
      club('salineiros', 'Salineiros FC', '#e8e8e8', '#2f6fd6', '#2f6fd6', '#c84a4a'),
      club('farolazul', 'Farol Azul', '#1f8fc0', '#f2f2f2', '#ffe066', '#f0f0f0'),
    ],
  },
  {
    id: 'estadual', name: 'Campeonato Estadual Brasa', tier: 2, unlockRep: 35, importance: 2,
    clubs: [
      club('serradourada', 'Serra Dourada', '#d9a31f', '#1d1d1d', '#1d1d1d', '#f0f0f0'),
      club('cerrado', 'Cerrado EC', '#8a5a2b', '#f2f2f2', '#f2f2f2', '#e8e8e8'),
      club('sertaoun', 'Sertão United', '#c8422e', '#1d1d1d', '#f2f2f2', '#f0f0f0'),
      club('valedosol', 'Vale do Sol', '#f0a020', '#f2f2f2', '#c84a2a', '#2f6fd6'),
      club('mataatl', 'Mata Atlântica FC', '#1f7a4a', '#f2f2f2', '#f2f2f2', '#e8e8e8'),
      club('planalto', 'Planalto AC', '#5a4ac8', '#f2f2f2', '#f2f2f2', '#e8e8e8'),
    ],
  },
  {
    id: 'nacionalb', name: 'Série Nacional B', tier: 3, unlockRep: 55, importance: 2,
    clubs: [
      club('aurora', 'Aurora FC', '#e86a8a', '#f2f2f2', '#f2f2f2', '#f0f0f0'),
      club('bravos', 'Bravos de Prata', '#b8c0c8', '#1d1d1d', '#1d1d1d', '#c8422e'),
      club('trovao', 'Trovão EC', '#2a2a4a', '#f2f2f2', '#ffe066', '#e8e8e8'),
      club('atlantida', 'Atlântida SC', '#1fa0a8', '#f2f2f2', '#f2f2f2', '#f0f0f0'),
      club('falcoes', 'Falcões do Norte', '#8a2a2a', '#f2f2f2', '#f2f2f2', '#e8e8e8'),
      club('estrelapolar', 'Estrela Polar', '#e8e8f8', '#2a2a8a', '#2a2a8a', '#c8422e'),
    ],
  },
  {
    id: 'nacionala', name: 'Série Nacional A', tier: 4, unlockRep: 75, importance: 3,
    clubs: [
      club('titas', 'Titãs FC', '#d62f2f', '#1d1d1d', '#f2f2f2', '#f0f0f0'),
      club('realhorizonte', 'Real Horizonte', '#f2f2f2', '#2f4fd6', '#2f4fd6', '#d62f2f'),
      club('imperial', 'Imperial AC', '#6a2fa8', '#f2f2f2', '#ffe066', '#e8e8e8'),
      club('fenix', 'Fênix SC', '#f07a1f', '#1d1d1d', '#1d1d1d', '#f0f0f0'),
      club('gigantes', 'Gigantes do Sul', '#2f8a4a', '#f2f2f2', '#f2f2f2', '#e8e8e8'),
      club('dragoes', 'Dragões EC', '#1d1d1d', '#d62f2f', '#d62f2f', '#f0f0f0'),
    ],
  },
  {
    id: 'continental', name: 'Copa Continental', tier: 5, unlockRep: 90, importance: 3,
    clubs: [
      club('condor', 'Condor FC', '#f2f2f2', '#1d1d1d', '#c8422e', '#2f6fd6'),
      club('meridian', 'Meridian United', '#2f6fd6', '#f2f2f2', '#ffe066', '#f0f0f0'),
      club('solnascente', 'Sol Nascente', '#f0b020', '#2f4fd6', '#2f4fd6', '#f0f0f0'),
      club('pamparreal', 'Pampa Real', '#8ac8f0', '#f2f2f2', '#f2f2f2', '#c8422e'),
      club('tucano', 'Tucano FC', '#1d1d1d', '#f0b020', '#f0b020', '#f0f0f0'),
      club('selvaverde', 'Selva Verde', '#1f9a5a', '#f2f2f2', '#ffe066', '#e8e8e8'),
    ],
  },
];

export const QUICK_MATCH = {
  home: club('vermelhos', 'Vermelhos', '#d63a3a', '#f2f2f2', '#ffffff', '#e07070'),
  away: club('azuis', 'Azuis', '#2f6fd6', '#f2f2f2', '#ffffff', '#6fa0e8'),
  importance: 2,
};

export const LEVELS = [
  { xp: 0, title: 'Aspirante' },
  { xp: 100, title: 'Árbitro de Várzea' },
  { xp: 250, title: 'Árbitro Amador' },
  { xp: 450, title: 'Árbitro Regional' },
  { xp: 700, title: 'Árbitro Estadual' },
  { xp: 1000, title: 'Árbitro Nacional B' },
  { xp: 1400, title: 'Árbitro Nacional A' },
  { xp: 1900, title: 'Árbitro Internacional' },
  { xp: 2500, title: 'Árbitro de Elite' },
  { xp: 3200, title: 'Lenda do Apito' },
];

export const getCompetition = (id) => COMPETITIONS.find((c) => c.id === id) || null;
export const getClub = (id) => {
  for (const c of COMPETITIONS) {
    const found = c.clubs.find((k) => k.id === id);
    if (found) return found;
  }
  return null;
};

// ---------------------------------------------------------------------------------------------
// Formatos de competição (Etapa 3). Ligas = pontos corridos (turno único); copas = mata-mata.
// Nada aqui tem lógica: o calendário e as tabelas são gerados em systems/CalendarSystem.js.
// ---------------------------------------------------------------------------------------------
for (const comp of COMPETITIONS) {
  comp.format = 'league';
  comp.division = true; // faz parte da escada de divisões (Várzea -> ... -> Continental)
  comp.region = null;
}

const regionalCup = (id, name, region, unlockRep, clubs) => ({
  id,
  name,
  tier: 1.5,
  unlockRep,
  importance: 2,
  format: 'cup',
  division: false,
  region,
  stages: [
    { name: 'Semifinais', week: 3, importance: 2 },
    { name: 'Final', week: 5, importance: 3 },
  ],
  clubs,
});

COMPETITIONS.push(
  {
    id: 'copanacional',
    name: 'Copa Nacional',
    tier: 2.5,
    unlockRep: 25,
    importance: 2,
    format: 'cup',
    division: false,
    region: null,
    pool: 'leagues', // sorteia 8 clubes das ligas a cada temporada
    stages: [
      { name: 'Quartas de final', week: 2, importance: 2 },
      { name: 'Semifinais', week: 4, importance: 3 },
      { name: 'Final', week: 5, importance: 3 },
    ],
    clubs: [],
  },
  regionalCup('copanorte', 'Copa Norte', 'norte', 20, [
    club('igarape', 'Igarapé FC', '#1f9a5a', '#f2f2f2', '#ffe066', '#e8e8e8'),
    club('acai', 'Açaí EC', '#5a2a7a', '#f2f2f2', '#f2f2f2', '#e0e0e0'),
    club('tapajos', 'Tapajós AC', '#2a7ac8', '#f2f2f2', '#f2f2f2', '#f0f0f0'),
    club('botorosa', 'Boto Rosa', '#e86a9a', '#f2f2f2', '#f2f2f2', '#3a3f4a'),
  ]),
  regionalCup('copanordeste', 'Copa Nordeste', 'nordeste', 20, [
    club('caatinga', 'Caatinga FC', '#d9a31f', '#1d1d1d', '#1d1d1d', '#f0f0f0'),
    club('mandacaru', 'Mandacaru EC', '#3a9a3a', '#f2f2f2', '#f2f2f2', '#e8e8e8'),
    club('cangaco', 'Cangaço AC', '#8a2a2a', '#1d1d1d', '#f0b020', '#f0f0f0'),
    club('rendeira', 'Rendeira FC', '#e8e8e8', '#c8422e', '#c8422e', '#2f6fd6'),
  ]),
  regionalCup('copacentrooeste', 'Copa Centro-Oeste', 'centrooeste', 20, [
    club('pantanal', 'Pantanal FC', '#1f7a8a', '#f2f2f2', '#f2f2f2', '#f0f0f0'),
    club('cerradeiros', 'Cerradeiros EC', '#c8782e', '#f2f2f2', '#f2f2f2', '#e8e8e8'),
    club('araguaia', 'Araguaia AC', '#2f6fd6', '#f2f2f2', '#ffe066', '#f0f0f0'),
    club('pequi', 'Pequi FC', '#e8c24a', '#2b2b2b', '#2b2b2b', '#3c6fd6'),
  ]),
  regionalCup('copasudeste', 'Copa Sudeste', 'sudeste', 20, [
    club('mantiqueira', 'Mantiqueira FC', '#2f8a4a', '#f2f2f2', '#f2f2f2', '#e8e8e8'),
    club('serrano', 'Serrano EC', '#6a2fa8', '#f2f2f2', '#ffe066', '#e8e8e8'),
    club('baiaazul', 'Baía Azul AC', '#2a5ac8', '#f2f2f2', '#f2f2f2', '#f0f0f0'),
    club('garoa', 'Garoa FC', '#6a6f7a', '#1d1d1d', '#f2f2f2', '#c8422e'),
  ]),
  regionalCup('copasul', 'Copa Sul', 'sul', 20, [
    club('pampeiro', 'Pampeiro FC', '#c82f2f', '#1d1d1d', '#f2f2f2', '#f0f0f0'),
    club('coxilha', 'Coxilha EC', '#1f8a5a', '#f2f2f2', '#f2f2f2', '#e8e8e8'),
    club('minuano', 'Minuano AC', '#2fa0d6', '#f2f2f2', '#f2f2f2', '#f0f0f0'),
    club('araucaria', 'Araucária FC', '#4a8a2a', '#f2f2f2', '#ffe066', '#e8e8e8'),
  ])
);

// Reputação necessária: competições regionais exigem 15 pontos a mais de quem é de outra região
// (a região influencia a oportunidade, mas nunca bloqueia a progressão).
export const OTHER_REGION_EXTRA_REP = 15;
export const unlockThreshold = (comp, region) =>
  comp.region && comp.region !== region ? comp.unlockRep + OTHER_REGION_EXTRA_REP : comp.unlockRep;

export const isDivision = (comp) => comp.division === true;
export const clubCount = (comp) => (comp.pool === 'leagues' ? 2 ** comp.stages.length : comp.clubs.length);

// Estádio fictício determinístico para cada clube.
const STADIUM_PATTERNS = ['Arena %', 'Estádio %', 'Campo do %', 'Parque %'];
export function stadiumOf(c) {
  let h = 0;
  for (const ch of c.id) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  const base = c.name.replace(/\s+(FC|EC|AC|SC|United)$/i, '');
  return STADIUM_PATTERNS[h % STADIUM_PATTERNS.length].replace('%', base);
}
