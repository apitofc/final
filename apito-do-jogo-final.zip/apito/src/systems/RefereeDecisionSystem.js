import {
  INCIDENT,
  INCIDENT_LABEL,
  CALL_RANGE,
  INCIDENT_WINDOW_MS,
  ADVANTAGE_MS,
  IMMEDIATE_FEEDBACK,
  ERROR_MESSAGES,
  errorText,
  evaluateDecision,
  GOAL_CHECK,
  GOAL_CHECK_S,
  GOAL_CAUSE_WINDOW_MS,
  GOAL_CAUSE_TYPES,
} from './MatchRules.js';
import { playerFull } from '../utils/labels.js';

const NO_INCIDENT_STOP_MS = 1500;
const CARD_ANIM_MS = 1800;
const DECISION_ANIM_MS = 600;

const dist = (ax, ay, bx, by) => Math.hypot(ax - bx, ay - by);

export default class RefereeDecisionSystem {
  constructor(events, sim) {
    this.events = events;
    this.sim = sim;

    this.nextId = 1;
    this.pending = [];
    this.log = [];
    this.stoppage = null;
    this.cards = { home: { yellow: 0, red: 0 }, away: { yellow: 0, red: 0 } };

    // Conferência de gol: gol que veio de falta ou impedimento de quem marcou pode ser anulado pelo árbitro (tecla G),
    // com ou sem VAR. goalCheck só existe durante a pausa depois do gol.
    this.goalCheck = null;
    this.playStartedAt = 0;
    events.on('play-resumed', (e) => (this.playStartedAt = e.time));
    events.on('goal', (g) => this.onGoal(g));

    events.on('incident', (incident) => this.register(incident));
  }

  // ---- Conferência de gol -----------------------------------------------------------------------------------------

  // Falta ou impedimento da equipe que marcou, não apitado, no trecho de jogo corrido que levou ao gol.
  findGoalCause(team) {
    const sim = this.sim;
    const from = Math.max(this.playStartedAt, sim.time - GOAL_CAUSE_WINDOW_MS);
    const plain = (p) => ({ team: p.team, number: p.number, name: p.name });
    const cands = [];
    for (const inc of this.pending) {
      if (inc.status === 'pending') cands.push(inc);
    }
    for (const e of this.log) {
      if (e.incidentId !== null && e.period === sim.period) cands.push(e);
    }
    let best = null;
    for (const c of cands) {
      const ok = c.expected && c.expected.foul && GOAL_CAUSE_TYPES.includes(c.type) && c.offender.team === team && !c.actual.foulCalled && c.time >= from && c.time <= sim.time;
      if (ok && (!best || c.time > best.time)) best = c;
    }
    if (!best) return null;
    return { incidentId: best.incidentId ?? best.id, type: best.type, time: best.time, clock: best.clock, x: best.x, y: best.y, offender: plain(best.offender), victim: plain(best.victim) };
  }

  onGoal({ team, scorer }) {
    const sim = this.sim;
    this.goalCheck = { team, scorer: scorer || null, clock: sim.getClock().text, period: sim.period, time: sim.time, cause: this.findGoalCause(team) };
    // Pausa um pouco maior para dar tempo de decidir (a comemoração continua igual).
    sim.goalTimer = Math.max(sim.goalTimer, GOAL_CHECK_S);
  }

  isGoalCheckOpen() {
    const sim = this.sim;
    return !!(this.goalCheck && sim.state === 'stopped' && sim.stopReason === 'goal');
  }

  // O árbitro anula o gol (tecla G). Vale com ou sem infração: anular um gol válido é erro e é avaliado como tal.
  annulGoal() {
    if (!this.isGoalCheckOpen()) return false;
    const gc = this.goalCheck;
    if (!this.sim.disallowGoal(gc.team, gc.cause)) return false;
    this.closeGoalCheck(true);
    return true;
  }

  // Fim da pausa do gol sem anulação: o gol é confirmado. Só vira registro (erro) se havia infração.
  update_goalCheck() {
    if (this.goalCheck && !this.isGoalCheckOpen()) this.closeGoalCheck(false);
  }

  closeGoalCheck(annulled) {
    const gc = this.goalCheck;
    this.goalCheck = null;
    if (!gc) return;
    const irregular = !!gc.cause;
    // Gol normal confirmado: nada a avaliar (não infla a nota com acertos fáceis).
    if (!irregular && !annulled) return;

    const stub = (team) => ({ team, number: '—', name: 'equipe' });
    const scorer = gc.scorer ? { team: gc.scorer.team, number: gc.scorer.number, name: gc.scorer.name } : stub(gc.team);
    const offender = gc.cause ? gc.cause.offender : scorer;
    const victim = gc.cause ? gc.cause.victim : stub(gc.team === 'home' ? 'away' : 'home');
    const kind = gc.cause ? { light_foul: 'falta leve', serious_foul: 'falta grave', penalty: 'falta na área', offside: 'impedimento' }[gc.cause.type] : null;
    const incident = {
      expected: { foul: irregular, card: null, restart: gc.cause ? (gc.cause.type === 'offside' ? 'indirect_free_kick' : 'free_kick') : null, cardTarget: null, advantageAllowed: false },
      actual: { foulCalled: annulled, cards: [], advantage: null, decided: true },
      offender,
      victim,
    };
    const result = evaluateDecision(incident);
    const entry = {
      incidentId: null,
      type: GOAL_CHECK,
      level: 'none',
      time: gc.time,
      clock: gc.clock,
      period: gc.period,
      x: gc.cause ? gc.cause.x : null,
      y: gc.cause ? gc.cause.y : null,
      refDistance: null,
      evidence: gc.cause ? [`${kind} de ${playerFull(offender)} no lance do gol`, `infração aos ${gc.cause.clock}`] : ['nenhuma falta nem impedimento no lance do gol'],
      offender,
      victim,
      expected: incident.expected,
      actual: incident.actual,
      errors: result.errors,
      notes: result.notes,
      correct: result.correct,
      varChanged: false,
      cause: gc.cause ? { incidentId: gc.cause.incidentId, type: gc.cause.type } : null,
    };
    this.log.push(entry);
    this.events.emit('goal-decision', entry);
    if (!IMMEDIATE_FEEDBACK) return;
    if (result.errors.length) this.feedback('bad', `Gol: ${result.errors.map((c) => errorText(c, GOAL_CHECK)).join(', ')}\n(${entry.evidence.join(', ')})`);
    else this.feedback('good', 'Gol anulado corretamente!');
  }

  register(incident) {
    incident.id = this.nextId++;
    incident.status = 'pending';
    incident.expiresAt = incident.time + INCIDENT_WINDOW_MS[incident.type];
    incident.advantageUntil = null;
    incident.actual = { foulCalled: false, cards: [], advantage: null, decided: false };
    this.pending.push(incident);
    this.events.emit('incident-registered', incident);
  }

  nearest() {
    const ref = this.sim.referee;
    let best = null;
    let bd = CALL_RANGE;
    for (const inc of this.pending) {
      if (inc.status !== 'pending') continue;
      const d = dist(ref.x, ref.y, inc.x, inc.y);
      if (d <= bd) {
        bd = d;
        best = inc;
      }
    }
    return best;
  }

  isDeciding() {
    return !!(this.stoppage && this.stoppage.reason === 'decision');
  }

  whistle() {
    const sim = this.sim;
    if (sim.state === 'playing') {
      const inc = this.nearest();
      sim.stopPlay('whistle');
      this.events.emit('whistle', { time: sim.time });
      if (inc) {
        this.openDecision(inc, false);
      } else {
        this.stoppage = {
          reason: 'whistle',
          timer: NO_INCIDENT_STOP_MS,
          incident: null,
          whistleTime: sim.time,
          clock: sim.getClock().text,
          period: sim.period,
        };
        this.feedback('info', 'Apito sem lance');
      }
    } else if (sim.state === 'stopped' && this.stoppage && this.stoppage.reason === 'whistle') {
      this.endStoppage();
    }
  }

  openDecision(inc, forceFoul) {
    inc.status = 'called';
    this.stoppage = { reason: 'decision', timer: Infinity, incident: inc, forceFoul };
    this.events.emit('decision-needed', { incident: inc, forceFoul });
  }

  // ---- VAR ------------------------------------------------------------------------------------------------------

  captureState() {
    return {
      cards: JSON.parse(JSON.stringify(this.cards)),
      logLength: this.log.length,
      stoppage: this.stoppage ? { ...this.stoppage } : null,
      pending: this.pending.map((inc) => ({
        inc,
        status: inc.status,
        expiresAt: inc.expiresAt,
        advantageUntil: inc.advantageUntil,
        actual: { ...inc.actual, cards: [...inc.actual.cards] },
      })),
    };
  }

  // Volta ao estado capturado: cartões, súmula e lances pendentes. Devolve os lances que voltaram a ficar pendentes.
  restoreState(s) {
    this.goalCheck = null; // a revisão do VAR volta no tempo: a conferência de gol daquele instante deixa de valer
    for (const id of ['home', 'away']) Object.assign(this.cards[id], s.cards[id]);
    this.log.length = s.logLength;
    this.stoppage = s.stoppage ? { ...s.stoppage } : null;
    this.pending = s.pending.map((e) => {
      e.inc.status = e.status;
      e.inc.expiresAt = e.expiresAt;
      e.inc.advantageUntil = e.advantageUntil;
      e.inc.actual = { ...e.actual, cards: [...e.actual.cards] };
      return e.inc;
    });
    return [...this.pending];
  }

  // Aplica a decisão tomada na revisão do VAR (o estado já foi restaurado para o instante do lance).
  // Segue o mesmo caminho de uma decisão normal: cartões, tiro livre/pênalti/bola ao chão e nota.
  applyReviewDecision(inc, choice) {
    inc.varChanged = true;
    inc.status = 'called';
    this.stoppage = { reason: 'decision', timer: Infinity, incident: inc, forceFoul: false };
    this.resolveDecision(choice);
  }

  resolveDecision(choice) {
    const s = this.stoppage;
    if (!s || s.reason !== 'decision') return;
    const inc = s.incident;

    inc.actual.decided = true;
    inc.actual.foulCalled = !!choice.foul || !!s.forceFoul;

    let shownCard = false;
    for (const who of ['offender', 'victim']) {
      const color = choice.cards?.[who];
      if (!color) continue;
      if (color !== 'warning') shownCard = true;
      this.applyCard(inc, inc[who], color);
    }

    this.stoppage = { reason: 'resolved', timer: shownCard ? CARD_ANIM_MS : DECISION_ANIM_MS, incident: inc };

    // Jogadores reclamam (efeito visual): quem foi punido, ou quem sofreu a falta que não foi marcada.
    if (this.sim.protest) {
      if (inc.actual.foulCalled) this.sim.protest(inc.offender.team, inc.x, inc.y);
      else if (inc.expected.foul) this.sim.protest(inc.victim.team, inc.x, inc.y);
    }
  }

  applyCard(inc, target, color) {
    inc.actual.cards.push({ player: target, color });
    if (color === 'warning') {
      this.feedback('info', `Advertência verbal: ${playerFull(target)}`);
      return;
    }

    let effective = color;
    let secondYellow = false;
    if (color === 'yellow') {
      target.yellowCards += 1;
      if (target.yellowCards >= 2) {
        effective = 'red';
        secondYellow = true;
      }
    }
    this.cards[target.team][effective] += 1;
    this.events.emit('card', { color, effective, player: target, secondYellow, incident: inc });
    if (effective === 'red') this.sim.sendOff(target);
  }

  signalAdvantage() {
    const sim = this.sim;
    if (sim.state !== 'playing') return;
    const inc = this.nearest();
    if (!inc || inc.type !== INCIDENT.LIGHT_FOUL || inc.actual.advantage) {
      this.feedback('info', 'Vantagem só em falta leve');
      return;
    }
    inc.actual.advantage = 'pending';
    inc.advantageUntil = sim.time + ADVANTAGE_MS;
    this.events.emit('advantage', { incident: inc });
    this.feedback('info', 'Vantagem!');
  }

  update(delta) {
    const ms = Math.min(delta, 50);
    const sim = this.sim;

    if (sim.state !== 'playing') {
      for (const inc of this.pending) {
        inc.expiresAt += ms;
        if (inc.advantageUntil !== null) inc.advantageUntil += ms;
      }
    }

    this.update_goalCheck();

    if (this.stoppage) {
      this.stoppage.timer -= ms;
      if (this.stoppage.timer <= 0) this.endStoppage();
    }

    if (sim.state !== 'playing') return;
    const now = sim.time;
    for (const inc of [...this.pending]) {
      if (inc.status !== 'pending') continue;
      if (inc.actual.advantage === 'pending') {
        if (now >= inc.advantageUntil) this.resolveAdvantage(inc);
      } else if (now >= inc.expiresAt) {
        this.resolveIgnored(inc);
      }
    }
  }

  resolveAdvantage(inc) {
    const retained = this.sim.ball.lastTouchTeam === inc.victim.team;
    if (retained) {
      inc.actual.advantage = 'success';
      this.finalize(inc);
      return;
    }

    inc.actual.advantage = 'failed';
    this.sim.stopPlay('advantage');
    this.events.emit('whistle', { time: this.sim.time });
    this.feedback('info', 'Vantagem não se confirmou: falta!');
    this.openDecision(inc, true);
  }

  resolveIgnored(inc) {
    if (inc.type === INCIDENT.LIGHT_FOUL && this.sim.ball.lastTouchTeam === inc.victim.team) {
      inc.actual.advantage = 'implicit';
    }
    this.finalize(inc);
  }

  closeAll() {
    for (const inc of [...this.pending]) {
      if (inc.status !== 'pending') continue;
      if (inc.actual.advantage === 'pending') {
        const retained = this.sim.ball.lastTouchTeam === inc.victim.team;
        inc.actual.advantage = retained ? 'success' : 'failed';
        if (!retained) inc.actual.foulCalled = true;
        this.finalize(inc);
      } else {
        this.resolveIgnored(inc);
      }
    }
  }

  endStoppage() {
    const s = this.stoppage;
    this.stoppage = null;
    const sim = this.sim;
    if (!s || s.reason === 'decision') return;
    const inc = s.incident;

    // Apito sem lance próximo.
    if (!inc) {
      this.log.push({
        incidentId: null,
        type: 'unnecessary_whistle',
        time: s.whistleTime ?? sim.time,
        clock: s.clock ?? sim.getClock().text,
        period: s.period ?? sim.period,
        errors: ['WHISTLE_UNNECESSARY'],
        notes: [],
        correct: false,
      });
      this.feedback('bad', `Apito sem lance: ${ERROR_MESSAGES.WHISTLE_UNNECESSARY}`);
      sim.resumeDrop();
      return;
    }

    this.finalize(inc);

    const diverCarded = inc.actual.cards.some((c) => c.player === inc.victim && c.color !== 'warning');
    if (inc.actual.foulCalled) {
      const indirect = inc.type === INCIDENT.OFFSIDE || inc.type === INCIDENT.LEGAL_POSITION;
      const type = inc.type === INCIDENT.PENALTY ? 'penalty' : indirect ? 'indirect_free_kick' : 'free_kick';
      sim.startSetPiece(type, inc.victim.team, inc.x, inc.y);
    } else if (inc.type === INCIDENT.SIMULATION && diverCarded) {
      const other = inc.victim.team === 'home' ? 'away' : 'home';
      sim.startSetPiece('indirect_free_kick', other, inc.x, inc.y);
    } else {
      sim.resumeDrop();
    }
  }

  finalize(inc) {
    if (inc.status === 'resolved') return;
    inc.status = 'resolved';
    this.pending = this.pending.filter((p) => p !== inc);

    const result = evaluateDecision(inc);
    const entry = {
      incidentId: inc.id,
      type: inc.type,
      level: inc.level,
      time: inc.time,
      clock: inc.clock,
      period: inc.period,
      x: inc.x,
      y: inc.y,
      refDistance: inc.refDistance,
      evidence: inc.evidence,
      offender: { team: inc.offender.team, number: inc.offender.number, name: inc.offender.name },
      victim: { team: inc.victim.team, number: inc.victim.number, name: inc.victim.name },
      expected: inc.expected,
      actual: {
        foulCalled: inc.actual.foulCalled,
        cards: inc.actual.cards.map((c) => ({ team: c.player.team, number: c.player.number, name: c.player.name, color: c.color })),
        advantage: inc.actual.advantage,
        decided: inc.actual.decided,
      },
      errors: result.errors,
      notes: result.notes,
      correct: result.correct,
      varChanged: !!inc.varChanged,
    };
    this.log.push(entry);
    this.events.emit('decision-result', entry);

    if (!IMMEDIATE_FEEDBACK) return;
    const label = INCIDENT_LABEL[inc.type];
    if (result.errors.length) {
      const msgs = result.errors.map((c) => errorText(c, inc.type)).join(', ');
      this.feedback('bad', `${label}: ${msgs}\n(${inc.evidence.join(', ')})`);
    } else if (inc.actual.decided || inc.actual.advantage === 'success') {
      this.feedback('good', `${label}: decisão correta!`);
    }
  }

  feedback(kind, text) {
    this.events.emit('feedback', { kind, text });
  }

  getPrompt() {
    const sim = this.sim;
    if (sim.state === 'setpiece' || this.isDeciding()) return '';
    if (this.isGoalCheckOpen()) return 'GOL!  Espaço anula o gol';
    if (this.stoppage && this.stoppage.reason === 'whistle') return 'JOGO PARADO  Espaço retoma';
    if (sim.state === 'playing' && this.nearest()) return 'LANCE!  Espaço apita  V vantagem';
    return '';
  }
}