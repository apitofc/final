import test from 'node:test';
import assert from 'node:assert/strict';
import { createCareer, applyMatch, migrateCareer, getOffers, skipWeek, CAREER_VERSION, SEASON_ROUNDS } from '../src/systems/CareerSystem.js';
import { AWARDS, AWARD_XP, awardStatus, grantAwards, awardKey, unseenAwards, markAwardsSeen } from '../src/systems/AwardsSystem.js';
import { CAREER_OBJECTIVES, careerObjectives, completeObjectives } from '../src/systems/ProgressionSystem.js';

const rec = (nota, over = {}) => ({ nota, graves: 0, competitionId: 'varzea', ...over });
const ids = (list) => list.map((a) => a.id).sort();

test('os cinco prêmios pedidos existem, com critérios e resumo', () => {
  assert.deepEqual(AWARDS.map((a) => a.name).sort(), ['Árbitro Revelação', 'Árbitro da Temporada', 'Destaque Regional', 'Destaque em Competições Eliminatórias', 'Melhor Avaliação Técnica'].sort());
  for (const a of AWARDS) assert.ok(a.summary && a.criteria([], 1).length >= 2);
});

test('sem jogos ou com poucos jogos ninguém ganha prêmio', () => {
  const c = createCareer('Ana', 1);
  assert.deepEqual(grantAwards(c, [], 1, { season: 1, week: 5 }), []);
  assert.deepEqual(grantAwards(c, [rec(9), rec(9)], 1, { season: 1, week: 5 }), []);
  assert.equal(c.awards.length, 0);
  assert.equal(c.xp, 0);
});

test('critérios verificáveis: Revelação, Avaliação Técnica e Árbitro da Temporada', () => {
  const c = createCareer('Ana', 2);
  const season = [rec(8.6), rec(8.2), rec(8.4), rec(8.1)];
  const got = grantAwards(c, season, 1, { season: 1, week: 5 });
  assert.deepEqual(ids(got), ['avaliacao', 'revelacao', 'temporada']);
  assert.equal(c.xp, AWARD_XP * 3);
  assert.ok(got.every((a) => a.xp === AWARD_XP && a.detail.includes('média')));
});

test('um erro grave bloqueia o Árbitro da Temporada, mas não a Revelação (no máximo 1)', () => {
  const c = createCareer('Ana', 3);
  const got = grantAwards(c, [rec(8.6, { graves: 1 }), rec(8.2), rec(8.4), rec(8.1)], 1, { season: 1, week: 5 });
  assert.deepEqual(ids(got), ['avaliacao', 'revelacao']);
});

test('copas: Eliminatórias com 2 jogos de copa; Regional só com copas regionais', () => {
  const c = createCareer('Ana', 4);
  const matches = [rec(7.5, { competitionId: 'copanacional' }), rec(7.2, { competitionId: 'copanacional' }), rec(6, {})];
  assert.deepEqual(ids(grantAwards(c, matches, 3, { season: 3, week: 5 })), ['eliminatorias']);
  const d = createCareer('Ana', 5);
  const reg = [rec(7.5, { competitionId: 'copasul' }), rec(7.2, { competitionId: 'copasul' })];
  assert.deepEqual(ids(grantAwards(d, reg, 3, { season: 3, week: 5 })), ['eliminatorias', 'regional']);
  const e = createCareer('Ana', 6);
  assert.deepEqual(grantAwards(e, [rec(6.5, { competitionId: 'copasul' }), rec(6.9, { competitionId: 'copasul' })], 3, { season: 3, week: 5 }), [], 'média abaixo de 7,0');
});

test('sem duplicar: o mesmo prêmio na mesma temporada nunca é dado duas vezes e o XP entra uma vez', () => {
  const c = createCareer('Ana', 7);
  const season = [rec(8.6), rec(8.2), rec(8.4), rec(8.1)];
  grantAwards(c, season, 1, { season: 1, week: 5 });
  const xp = c.xp;
  const n = c.awards.length;
  assert.deepEqual(grantAwards(c, season, 1, { season: 1, week: 5 }), []);
  assert.equal(c.xp, xp);
  assert.equal(c.awards.length, n);
  assert.ok(c.awards.every((a, i, all) => all.findIndex((b) => b.key === a.key) === i));
});

test('Revelação é um prêmio único; os demais podem se repetir em outra temporada', () => {
  const c = createCareer('Ana', 8);
  const season = [rec(8.6), rec(8.2), rec(8.4), rec(8.1)];
  grantAwards(c, season, 1, { season: 1, week: 5 });
  const second = grantAwards(c, season, 2, { season: 2, week: 5 });
  assert.deepEqual(ids(second), ['avaliacao', 'temporada']);
  assert.equal(c.awards.filter((a) => a.id === 'revelacao').length, 1);
  assert.ok(c.awards.some((a) => a.key === awardKey('avaliacao', 2)));
  const late = createCareer('Ana', 9);
  assert.ok(!ids(grantAwards(late, season, 3, { season: 3, week: 5 })).includes('revelacao'), 'só nas duas primeiras temporadas');
});

test('awardStatus mostra critérios com valores reais e o estado de cada prêmio', () => {
  const c = createCareer('Ana', 10);
  const st = awardStatus(c, [rec(8.5), rec(8.5), rec(8.5)], 1);
  const aval = st.find((s) => s.id === 'avaliacao');
  assert.ok(aval.met && !aval.earned);
  assert.ok(aval.criteria.every((k) => k.text && k.detail));
  assert.ok(!st.find((s) => s.id === 'temporada').met, 'faltam jogos');
});

test('avisos de novo prêmio: não vistos contam e são zerados ao abrir a aba', () => {
  const c = createCareer('Ana', 11);
  grantAwards(c, [rec(8.6), rec(8.2), rec(8.4)], 1, { season: 1, week: 5 });
  assert.equal(unseenAwards(c), c.awards.length);
  assert.ok(markAwardsSeen(c));
  assert.equal(unseenAwards(c), 0);
  assert.equal(markAwardsSeen(c), false);
});

// ------------------------------------------------------------ integração com a temporada
const result = (nota) => ({
  nota, label: 'ok', categories: [{ label: 'Posicionamento', points: 5, max: 10, ratio: 0.5 }], mistakes: [], hits: [], counts: { unnecessaryWhistles: 0 }, score: { home: 1, away: 0 },
  extras: { decisions: 8, correct: 8, yellow: 0, red: 0, redWrong: 0, fouls: 2, penalties: 0, penaltiesCorrect: 0, penaltiesMissed: 0, wrongCalls: 0, missedFouls: 0, simulationsPunished: 0, simulationsMissed: 0, offsides: 0, offsidesCorrect: 0, offsidesMissed: 0, advantageOk: 0, advantageFailed: 0, whistles: 0 },
});

function playSeason(career, nota) {
  const start = career.season.number;
  let guard = 0;
  while (career.season.number === start && guard++ < 20) {
    const offers = getOffers(career).filter((o) => o.status === 'offered');
    if (!offers.length) {
      skipWeek(career);
      continue;
    }
    const f = offers[0].fixture;
    applyMatch(career, { competitionId: f.competitionId, homeId: f.home, awayId: f.away, importance: f.importance, fixtureId: f.id, matchId: `s${start}-${guard}`, duration: 'standard' }, result(nota));
  }
  assert.ok(career.season.number > start, 'a temporada precisa terminar');
}

test('fim da temporada: prêmios entram uma vez, com XP, notícia, e-mail e publicação; temporada fraca não ganha nada', () => {
  const good = createCareer('Ana', 21);
  playSeason(good, 8.8);
  const keys = good.awards.map((a) => a.key);
  assert.ok(keys.includes('revelacao:s1') && keys.includes('avaliacao:s1') && keys.includes('temporada:s1'), keys.join());
  assert.ok(good.news.some((n) => n.key === 'season:1:news:award:avaliacao' && n.tone === 'positive'));
  assert.ok(good.inbox.some((m) => m.key === 'season:1:mail:award:temporada' && m.category === 'reconhecimento'));
  assert.ok(good.social.some((p) => p.key === 'season:1:post:award:revelacao' && p.tag === 'dado oficial'));
  assert.ok(good.awards.every((a) => a.xp === AWARD_XP && a.season === 1 && a.seen === false));

  const bad = createCareer('Ana', 22);
  playSeason(bad, 5.2);
  assert.equal(bad.awards.length, 0);
  assert.ok(!bad.news.some((n) => n.key.includes(':news:award:')));
});

test('passar a rodada sem apitar não gera prêmio', () => {
  const c = createCareer('Ana', 23);
  for (let i = 0; i < SEASON_ROUNDS; i++) skipWeek(c);
  assert.equal(c.season.number, 2);
  assert.equal(c.awards.length, 0);
});

// ------------------------------------------------------------ migração e objetivo do VAR
test('migração v6 -> v7: prêmios começam vazios e nada é concedido retroativamente', () => {
  const c = createCareer('Ana', 24);
  const old = JSON.parse(JSON.stringify(c));
  old.version = 6;
  delete old.awards;
  const r = migrateCareer(old);
  assert.ok(!r.error && r.migrated);
  assert.equal(r.career.version, CAREER_VERSION);
  assert.deepEqual(r.career.awards, []);
  assert.equal(migrateCareer(JSON.parse(JSON.stringify(r.career))).migrated, false);
});

test('objetivo do VAR: só conta revisão em lance típico com decisão final correta, e paga uma vez', () => {
  const c = createCareer('Ana', 25);
  const def = CAREER_OBJECTIVES.find((o) => o.id === 'var');
  assert.ok(def && def.goal === 3);
  const audit = (n, over = {}) => Array.from({ length: n }, () => ({ eligible: true, finalCorrect: true, kind: 'change', ...over }));
  c.history.unshift({ nota: 7, graves: 0, var: { audit: audit(2) } });
  c.history.unshift({ nota: 7, graves: 0, var: { audit: [...audit(5, { eligible: false }), ...audit(4, { finalCorrect: false }), ...audit(1, { finalCorrect: null })] } });
  assert.equal(def.measure(c), 2, 'fora de lance típico, errada ou sem desfecho não contam');
  assert.equal(completeObjectives(c).some((o) => o.id === 'var'), false);
  c.history.unshift({ nota: 7, graves: 0, var: { audit: audit(1) } });
  const done = completeObjectives(c);
  assert.ok(done.some((o) => o.id === 'var'));
  const xp = c.xp;
  assert.equal(completeObjectives(c).length, 0, 'a recompensa não é paga de novo');
  assert.equal(c.xp, xp);
  assert.equal(careerObjectives(c).find((o) => o.id === 'var').status, 'done');
});
