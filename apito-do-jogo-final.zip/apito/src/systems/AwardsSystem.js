// Prêmios de temporada (Etapa 7). Funções puras.
//
// Cada prêmio tem critérios verificáveis, calculados só a partir dos registros das partidas da temporada
// (nota, erros graves e competição). Nada é sorteado. A recompensa é só XP e é entregue uma única vez:
// career.awards guarda uma chave por prêmio e temporada (e prêmios "únicos" nunca se repetem).
import { getCompetition } from '../data/competitions.js';

export const AWARD_XP = 40;
export const AWARDS_LIMIT = 60;
const MIN_PLAYED = 3;

const avgOf = (list) => (list.length ? list.reduce((a, m) => a + m.nota, 0) / list.length : null);
const compOf = (m) => getCompetition(m.competitionId);
const fmt = (n) => String(Math.round(n * 10) / 10).replace('.', ',');

// Cada critério devolve { ok, text, detail } para ser mostrado ao jogador (✓ ou ✗, com o valor real).
export const AWARDS = [
  {
    id: 'revelacao',
    name: 'Árbitro Revelação',
    once: true,
    summary: 'Começo de carreira de destaque: nas duas primeiras temporadas, média 6,5 ou mais e no máximo 1 erro grave.',
    criteria: (ms, season) => {
      const avg = avgOf(ms);
      const graves = ms.reduce((a, m) => a + (m.graves || 0), 0);
      return [
        { ok: season <= 2, text: 'Estar na 1ª ou 2ª temporada', detail: `temporada ${season}` },
        { ok: ms.length >= MIN_PLAYED, text: `Apitar ${MIN_PLAYED} jogos ou mais`, detail: `${ms.length} jogo(s)` },
        { ok: avg !== null && avg >= 6.5, text: 'Média 6,5 ou mais', detail: avg === null ? 'sem jogos' : `média ${fmt(avg)}` },
        { ok: graves <= 1, text: 'No máximo 1 erro grave', detail: `${graves} erro(s) grave(s)` },
      ];
    },
  },
  {
    id: 'avaliacao',
    name: 'Melhor Avaliação Técnica',
    once: false,
    summary: 'Média 8,0 ou mais na temporada, com pelo menos 3 jogos.',
    criteria: (ms) => {
      const avg = avgOf(ms);
      return [
        { ok: ms.length >= MIN_PLAYED, text: `Apitar ${MIN_PLAYED} jogos ou mais`, detail: `${ms.length} jogo(s)` },
        { ok: avg !== null && avg >= 8, text: 'Média 8,0 ou mais', detail: avg === null ? 'sem jogos' : `média ${fmt(avg)}` },
      ];
    },
  },
  {
    id: 'regional',
    name: 'Destaque Regional',
    once: false,
    summary: 'Pelo menos 2 jogos em copas regionais, com média 7,0 ou mais nesses jogos.',
    criteria: (ms) => {
      const list = ms.filter((m) => compOf(m) && compOf(m).region);
      const avg = avgOf(list);
      return [
        { ok: list.length >= 2, text: 'Apitar 2 jogos de copas regionais', detail: `${list.length} jogo(s)` },
        { ok: avg !== null && avg >= 7, text: 'Média 7,0 ou mais nesses jogos', detail: avg === null ? 'sem jogos' : `média ${fmt(avg)}` },
      ];
    },
  },
  {
    id: 'eliminatorias',
    name: 'Destaque em Competições Eliminatórias',
    once: false,
    summary: 'Pelo menos 2 jogos de copas (mata-mata), com média 7,0 ou mais nesses jogos.',
    criteria: (ms) => {
      const list = ms.filter((m) => compOf(m) && compOf(m).format === 'cup');
      const avg = avgOf(list);
      return [
        { ok: list.length >= 2, text: 'Apitar 2 jogos de copas', detail: `${list.length} jogo(s)` },
        { ok: avg !== null && avg >= 7, text: 'Média 7,0 ou mais nesses jogos', detail: avg === null ? 'sem jogos' : `média ${fmt(avg)}` },
      ];
    },
  },
  {
    id: 'temporada',
    name: 'Árbitro da Temporada',
    once: false,
    summary: 'O prêmio mais exigente: 4 jogos ou mais, média 7,5 ou mais e nenhum erro grave.',
    criteria: (ms) => {
      const avg = avgOf(ms);
      const graves = ms.reduce((a, m) => a + (m.graves || 0), 0);
      return [
        { ok: ms.length >= 4, text: 'Apitar 4 jogos ou mais', detail: `${ms.length} jogo(s)` },
        { ok: avg !== null && avg >= 7.5, text: 'Média 7,5 ou mais', detail: avg === null ? 'sem jogos' : `média ${fmt(avg)}` },
        { ok: graves === 0, text: 'Nenhum erro grave', detail: `${graves} erro(s) grave(s)` },
      ];
    },
  },
];

export const getAward = (id) => AWARDS.find((a) => a.id === id) || null;
export const awardKey = (id, season) => `${id}:s${season}`;
export const ensureAwards = (career) => {
  if (!Array.isArray(career.awards)) career.awards = [];
};

// Situação de cada prêmio para uma temporada: critérios com valores reais e se já foi conquistado.
export function awardStatus(career, matches, season) {
  ensureAwards(career);
  return AWARDS.map((a) => {
    const criteria = a.criteria(matches, season);
    const earned = career.awards.some((x) => x.key === awardKey(a.id, season));
    const blockedOnce = a.once && career.awards.some((x) => x.id === a.id) && !earned;
    return { id: a.id, name: a.name, summary: a.summary, once: a.once, criteria, met: criteria.every((c) => c.ok), earned, blockedOnce };
  });
}

// Fim de temporada: concede os prêmios cujos critérios foram todos cumpridos. Idempotente (chave por prêmio e temporada).
// Devolve os prêmios novos. O XP entra uma única vez, junto com o registro.
export function grantAwards(career, matches, season, date) {
  ensureAwards(career);
  const granted = [];
  for (const st of awardStatus(career, matches, season)) {
    if (!st.met || st.earned || st.blockedOnce) continue;
    const entry = {
      key: awardKey(st.id, season),
      id: st.id,
      name: st.name,
      season,
      date,
      xp: AWARD_XP,
      seen: false,
      detail: st.criteria.map((c) => `${c.text}: ${c.detail}`).join(' · '),
    };
    career.awards.unshift(entry);
    career.xp += AWARD_XP;
    granted.push(entry);
  }
  career.awards.length = Math.min(career.awards.length, AWARDS_LIMIT);
  return granted;
}

export const unseenAwards = (career) => (career.awards || []).filter((a) => !a.seen).length;
export function markAwardsSeen(career) {
  let changed = false;
  for (const a of career.awards || []) {
    if (!a.seen) {
      a.seen = true;
      changed = true;
    }
  }
  return changed;
}
