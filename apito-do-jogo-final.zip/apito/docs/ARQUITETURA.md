# Apito do Jogo: arquitetura e auditoria (Etapa 1)

Documento escrito a partir do código do `apito.zip` recebido e atualizado nesta etapa. Serve de mapa para as próximas etapas.

## 1. Estrutura

```
index.html            título "Apito"; carrega src/main.js
src/main.js           configuração do Phaser (320x180, escala FIT, física Arcade) e lista de cenas
src/config.js         campo, equipes, durações das partidas, lista de eventos do jogo
src/scenes/           BootScene, MenuScene (HTML), MatchScene (Phaser), ResultScene (HTML)
src/entities/         Character (base), Player, Referee, Ball
src/systems/          MatchSimulation, PlayerAI, MatchRules, RefereeDecisionSystem,
                      RefereeGrading, CareerSystem, Controls
src/ui/               HUD, Effects, DecisionPanel (HTML)
src/data/             competitions, formations, names, referees (novo)
src/utils/            pixelTextures, audio, storage, rng, labels
tests/                testes automáticos (npm test)
```

Fluxo de cenas: `BootScene -> MenuScene -> MatchScene -> ResultScene -> MenuScene`.

## 2. Fases de gameplay: estado real no código recebido

| Fase | O que é | Onde está | Estado |
|---|---|---|---|
| 1 | Projeto e campo | `MatchScene.drawField`, `config.js` | completa |
| 2 | Árbitro e câmera | `Character`, `Referee`, `Controls`, `MatchScene` | completa |
| 3 | Jogadores, bola, IA | `Player`, `Ball`, `PlayerAI`, `MatchSimulation` | completa |
| 4 | Faltas, apito, cartões, painel | `MatchRules`, `RefereeDecisionSystem`, `DecisionPanel` | completa |
| 5 | Placar, relógio, gols, bola fora, tempos | `MatchSimulation`, `HUD`, `ResultScene` | completa |
| 6 | Nota do árbitro | `RefereeGrading`, `ResultScene` | completa |
| 7 | Menu e carreira | `MenuScene`, `CareerSystem`, `storage` | completa |
| 8 | Melhorias gráficas, áudio, novas regras | `pixelTextures` (poses), `Character.setPose`, `MatchScene.drawStands`, `Ball` (rastro), `utils/audio`, `Effects`, `PlayerAI.offsideInfo`, `MatchSimulation` | completa (concluída depois do `apito.zip` recebido, que só tinha o nome e o "Como jogar") |

## 3. Controles (inalterados)

WASD/setas mover, Espaço apitar, V vantagem (falta leve), N liga/desliga o som, Esc pausar, M (na pausa) menu, F2 debug. No painel: 1 amarelo, 2 vermelho (no autor), F marcar falta, I ignorar. Na tela de resultado: 1 a 4 trocam de aba, Espaço ou R continuam, M menu.

## 4. Regras de arbitragem

Lances gerados por `MatchSimulation` (`incident`), classificados em `MatchRules` e avaliados contra a decisão do jogador (`evaluateDecision`). Tipos: disputa legal, falta leve, falta pesada, pênalti, simulação, impedimento e posição legal.

Gravidade da falta = número de agravantes (entrada por trás, alta velocidade, entrada imprudente):

| Agravantes | Gravidade | Cartão |
|---|---|---|
| 0 ou 1 | falta leve | nenhum (advertência verbal aceita; vantagem permitida) |
| 2 | falta pesada | amarelo |
| 3 | força excessiva | vermelho |

**Mudança desta etapa:** antes, a gravidade vinha de uma pontuação contínua e as evidências eram só pistas (uma falta "por trás" era leve em 97% das vezes). Agora a regra é a contagem acima, igual à explicada no "Como jogar". Teste automático: `tests/sim.test.mjs`.

### Impedimento (Fase 8)

No momento de cada passe em jogo corrido ou tiro livre, `PlayerAI.offsideInfo` lista os atacantes em posição de impedimento (metade adversária, à frente da bola e do penúltimo defensor; o goleiro conta) e os que estão "no limite" (legais, até 7 px atrás da linha). A infração só existe se um deles for o próximo a tocar na bola (`MatchSimulation.checkOffsideTouch`). Impedimento marcado dá tiro livre indireto ao adversário, sem cartão. Não vale em lateral, escanteio, tiro de meta, pênalti nem saída de bola. Marcar impedimento numa posição legal é erro. Em 20 partidas de teste: cerca de 1,3 impedimentos e 1,2 posições legais por partida.

### Visual e áudio (Fase 8)

Poses por código: chute, comemoração (time que marca), reclamação (jogadores perto de uma decisão) e sinal do árbitro (apito e cartões). Arquibancadas com torcida nas cores dos clubes, placas de publicidade, rastro da bola rápida e tremor de câmera no gol. Áudio sintetizado (Web Audio, sem arquivos): apito longo, curto e triplo, chute, gol, cartão e torcida de fundo que reage aos lances. Tecla N liga e desliga o som (preferência salva).

## 5. Eventos (`CUSTOM_EVENTS` em `config.js`)

`incident`, `incident-registered`, `whistle`, `decision-needed`, `card`, `advantage`, `decision-result`, `feedback`, `player-touch`, `referee-bump` (sem uso), `play-stopped`, `play-resumed`, `setpiece-start`, `player-sent-off`, `goal`, `halftime`, `fulltime`. São removidos ao sair da partida para não acumular ao reiniciar.

## 6. Fim de partida (fonte única de verdade)

`MatchScene.finishMatch` envia `{ mode, fixture, score, stats, cards, log }` à `ResultScene`. O `log` (um registro por lance, vindo de `RefereeDecisionSystem`) é a única fonte da nota (`gradeMatch`). A `ResultScene` aplica o resultado à carreira com `applyMatch`, que agora é **idempotente** (`matchId`): o mesmo jogo nunca soma experiência, reputação ou histórico duas vezes.

## 7. Persistência

| Chave (localStorage) | Conteúdo |
|---|---|
| `refwhistle:career:v1` | carreira (formato versão 2; a chave antiga foi mantida) |
| `refwhistle:career:backup` | cópia da carreira original, criada na primeira migração |
| `refwhistle:career:previous` | cópia da carreira antes de ser substituída ou apagada |
| `apitodojogo:settings` | preferências (duração das partidas) |

Carreira versão 5: `version, name, profile{name, look, region}, seed, xp, rep, totalMatches, unlocked[], season{}, history[], processed[], skipped, champions[], division, strikes, restricted, seasons[], objectives[], inbox[], news[], social[], comms{seq}, world{season, week, competitions{}, offers{week, items[], restriction}}` (e `invitations[]`, campo legado das versões anteriores). As versões 1 a 4 são migradas automaticamente em cadeia (campos antigos preservados, padrões para os novos, backup antes); na migração para a 3, o calendário é montado a partir do progresso da temporada e as semanas anteriores são simuladas. Dados ilegíveis nunca são apagados: o menu avisa e a carreira fica intacta.

## 8. Pontos de integração para as próximas etapas

- Calendário e convocações: **feitos na Etapa 3** (seção 10).
- Novas competições: `data/competitions.js` (estrutura de dados, sem lógica). Faltam a Supercopa e a Liga Continental.
- Notícias, e-mails e rede social: gerados a partir de `result.log` e do registro de partida em `applyMatch`.
- VAR: ponto natural em `RefereeDecisionSystem.resolveDecision` (decisão inicial) antes de `finalize`.
- Tabelas: **feitas na Etapa 3**; os jogos que o jogador não apita são simulados com a semente da carreira.

## 9. Testes

`npm test` roda 66 testes: regras de gravidade, avaliação de decisões, perfil e migração da carreira, idempotência, convocações, calendário e tabelas, copas, progressão (promoção, rebaixamento, reputação, suspensão, objetivos), notícias, e-mails e rede social, impedimento, partidas completas (várias sementes e durações), reprodutibilidade da nota. Não cobrem a interface (HTML/Phaser), que precisa de teste manual.

## 10. Etapa 3: central da carreira, calendário e competições

**Competições** (`data/competitions.js`, só dados): 6 ligas em pontos corridos, turno único, as mesmas de antes (Várzea até Continental, que formam a escada de divisões), mais 6 copas em mata-mata: Copa Nacional (8 clubes sorteados das ligas a cada temporada, quartas, semifinais e final) e as copas Norte, Nordeste, Centro-Oeste, Sudeste e Sul (4 clubes cada, semifinais e final). Cada competição declara `format`, `stages`, `importance` e a reputação para liberar. Copas não contam como divisão (`division: false`). Competições regionais exigem 15 de reputação a mais de quem é de outra região: a região influencia a oportunidade, mas nunca bloqueia a progressão.

**Calendário** (`systems/CalendarSystem.js`, funções puras): a temporada tem 5 rodadas (uma por semana; eram 6 jogos antes). Cada jogo tem `id`, rodada, competição, fase, mandante, visitante, estádio fictício, importância, `status` e resultado. As ligas usam o método do círculo; as copas criam a fase seguinte quando a anterior termina, e empates vão aos pênaltis (sorteados com a semente). Tudo vem da semente da carreira: o calendário não muda ao recarregar.

**Convocações:** a cada rodada o árbitro recebe até 3 jogos das competições liberadas (um seguro, um intermediário e um importante). Aceitar inicia a partida; recusar não custa nada; "Passar a rodada sem apitar" simula todos os jogos e não custa experiência nem reputação. Um jogo concluído ou recusado não pode ser iniciado de novo (`startableFixture`), e o resultado de uma partida só conta uma vez (`matchId`).

**Fluxo de uma rodada (`CareerSystem.applyMatch`):** registra o resultado real no jogo do calendário, fecha as convocações da semana, simula os demais jogos da rodada, atualiza as copas e avança a semana. Ao fim da quinta rodada: objetivos, bônus de reputação (só com 3 jogos apitados ou mais), campeões da temporada (`career.champions`), novas competições liberadas e novo calendário.

**Interface (`MenuScene`):** central com navegação lateral (Visão geral, Convocações, Calendário, Classificação, Estatísticas, Objetivos, Histórico, Competições), indicadores de convocações abertas e objetivos concluídos, detalhes de cada jogo, tabelas de liga e chaves de copa. Notícias, e-mails e rede social ficam para a Etapa 5, e prêmios para a Etapa 7 (sem botões vazios até lá).

## 11. Etapa 4: progressão e avaliação

**Três atributos, três funções** (`systems/ProgressionSystem.js`, funções puras):
- **Avaliação técnica**: a nota da partida (`RefereeGrading`). É a mesma da tela de resultado e a carreira nunca a altera nem cria uma pontuação paralela.
- **Experiência (XP)**: prática acumulada; define nível e título. Nunca diminui.
- **Reputação (0 a 100)**: confiança do comitê. Nota acima de 6,0 sobe e abaixo desce, multiplicada pela importância do jogo, com teto por partida (+5 / -5). Cada erro grave (gravidade 3 ou mais na lista de erros da partida) desconta 0,5, até 3. Libera as copas e é um requisito de promoção. Uma partida ruim isolada não apaga a progressão.

**Divisão** (`career.division`, índice na escada de ligas): muda só por promoção ou rebaixamento. As ligas passaram a ser liberadas pela divisão (antes, pela reputação); as copas continuam liberadas por reputação.

**Promoção** no fim da temporada, só se **todos** os requisitos forem atendidos: reputação mínima da divisão seguinte (15, 35, 55, 75, 90), média da temporada igual ou acima da meta (6,0 na Várzea, +0,4 por divisão), pelo menos 3 jogos apitados, no máximo 3 erros graves e pelo menos 2 dos 4 objetivos da temporada. Dá 100 XP. O jogador vê cada requisito (✓ ou ✗, com o valor) durante a temporada (aba Objetivos) e o motivo no fim.

**Rebaixamento**: só após 2 temporadas seguidas com média abaixo de 5,0 (a primeira gera aviso; média de 6,0 ou mais zera os avisos). Perde uma divisão e 5 de reputação, nunca abaixo da divisão mais baixa. Temporada sem 3 jogos apitados não gera aviso.

**Suspensão de oportunidades**: com 4 ou mais erros graves numa partida, ou duas notas abaixo de 4,0 seguidas, a próxima rodada só oferece jogos de importância 1. Dura uma rodada, o motivo aparece na tela e a progressão não é afetada.

**Objetivos de carreira** (8, definidos em `ProgressionSystem`): só o estado é salvo; o progresso é calculado a partir do histórico. A recompensa (XP ou reputação) é entregue uma única vez. "Concluir uma temporada" exige 3 jogos apitados (passar todas as rodadas não vale). Na migração, objetivos já cumpridos são marcados sem recompensa.

**Registros**: cada partida guarda erros graves e competição; cada temporada concluída guarda divisão, média, jogos, erros graves, objetivos, bônus e a decisão (promoção, aviso, rebaixamento ou mantido) com o motivo. As estatísticas (aba Estatísticas) saem desses registros.

**Idempotência**: o resultado de uma partida (matchId) e a recompensa de cada objetivo só contam uma vez.

## 12. Etapa 5: notícias, e-mails e rede social

**Fonte única dos fatos** (`RefereeGrading.matchFacts`): a partir do registro de decisões da partida, conta cartões, pênaltis marcados e não marcados, faltas indevidas, impedimentos, simulações e vantagens. Os mesmos números alimentam as estatísticas da carreira e todo o conteúdo de comunicação. Notícia, e-mail e publicação não calculam nem alteram a nota.

**Geração** (`systems/CommsSystem.js`, funções puras e determinísticas pela semente da carreira e pelo `matchId`):
- **Notícias** (categorias arbitragem, lance, resultado, carreira, competição): tom positivo (nota 7,5 ou mais sem erro grave), negativo (nota abaixo de 5 ou 2 erros graves ou mais) ou neutro. Notícias de lance só existem se o fato ocorreu (no máximo 2 por partida). Manchetes e variantes não se repetem em sequência. Cada notícia guarda data, competição, jogo de origem e fonte fictícia.
- **E-mails** (avaliação, convocação, objetivo, disciplinar, convite, reconhecimento, promoção, comunicado): relatório da supervisão após cada jogo (nota, pontos fortes e fracos, principal erro e acerto), escala semanal com as convocações, objetivo concluído, suspensão com o motivo, convite ao liberar uma competição, decisão do comitê no fim da temporada. Cada mensagem tem id, remetente, assunto, texto, data, categoria e situação de leitura.
- **Rede social** (clube, jornalista, comentarista, torcedor, perfil oficial): cada publicação tem etiqueta (dado oficial, comunicado do clube, análise ou opinião). Só "dado oficial" e "análise" citam a avaliação técnica; opiniões de torcedores e comentaristas são marcadas e podem reclamar mesmo sem erro nenhum, para deixar claro que reclamação não prova erro técnico.

**Convocações por e-mail:** o e-mail da rodada é atualizado no lugar quando as ofertas mudam (por exemplo, numa suspensão). Os botões Aceitar e Recusar usam o estado real das convocações (`world.offers`), então aceitar ou recusar pela aba ou pelo e-mail é a mesma operação e não pode ser feita duas vezes. Recusar não custa nada. Mensagens de rodadas antigas aparecem como "Rodada encerrada".

**Idempotência e persistência:** cada item tem uma chave (por partida, temporada, objetivo ou rodada) e itens com a mesma chave nunca entram duas vezes; reprocessar um jogo (`matchId`) não gera nada. Limites: 60 notícias, 80 e-mails, 120 publicações (as mais antigas saem). Tudo é salvo com a carreira. Uma carreira com 60 jogos ocupa cerca de 150 KB.

**Imagem pública:** tom das últimas 5 notícias sobre a arbitragem (positiva, neutra ou crítica). É só narrativa: não afeta nota, reputação nem progressão. Os gatilhos de pressão e rivalidade ficam para a Etapa 6.

**Interface:** abas Notícias (filtro por tom), E-mails (lista, leitura, marcar lida ou não lida, marcar todas, ações de convocação, indicador de não lidas) e Rede social (filtro por etiqueta). A tela de resultado informa quantas mensagens novas chegaram.


## VAR
O VAR grava o estado da partida em `VarRecorder`/`VarSystem`, reproduz os quadros por `VarReplay` e apresenta a revisão em `VarPanel`. A abertura congela a simulação; uma correção restaura o estado do lance, reaplica a decisão escolhida e emite eventos para atualizar efeitos, cartões, placar e jogadores. O histórico de comunicação da Etapa 5 continua sendo alimentado pela carreira normalmente.

## 13. Etapa 6 (conclusão): VAR na carreira, pressão, rivalidades e eventos

**Onde o projeto estava:** Etapas 1 a 5, durações configuráveis e o VAR em partida (gravação, reprodução, painel, correção com restauração do estado) já existiam, com 83 testes. Faltavam: o VAR chegar à carreira (histórico auditável, notícias, e-mails, publicações, estatísticas) e o sistema de pressão, rivalidades e eventos especiais.

**VAR auditável** (`VarSystem.audit`): cada revisão concluída (decisão mantida ou alterada) vira uma linha com id, lance, relógio, se era um lance típico de VAR (`isVarEligible`: pênalti, impedimento ou vermelho), decisão inicial, decisão final e motivo. A decisão inicial é copiada antes de a correção ser reaplicada. Ao fim da partida, `MatchScene` envia `varReviews` com o desfecho real de cada lance (`finalCorrect`, vindo da súmula, a mesma fonte da nota). `RefereeGrading.varFacts` conta revisões, mantidas, alteradas, em lances elegíveis, corrigidas (alteradas e certas) e pioradas (alteradas e ainda erradas). Esses fatos entram em `extras` do resultado e no registro da partida (`history[].var`, com no máximo 8 linhas de auditoria). O VAR não recalcula nem altera a nota: ela continua vindo só da súmula de decisões.

**Comunicação sobre o VAR** (`CommsSystem`): só existe se houve revisão. Notícia da categoria `lance` (não entra na imagem pública), com tom positivo (correção confirmada), negativo (alteração que ainda aparece como erro) ou neutro (mantida, ou alterada sem desfecho conhecido); linha "VAR" no relatório da supervisão; publicação de dado oficial e debate de comentarista (opinião).

**Pressão** (`systems/ContextSystem.js`, funções puras): `matchContext` soma fatores explícitos, nível 0 a 3 (Normal, Atenção, Alta, Máxima): rivalidade (12 clássicos fictícios, `RIVALRIES`), final (peso 2) ou semifinal, competição de prestígio, última rodada da temporada, última partida com 2 ou mais erros graves ou nota abaixo de 5, e imagem pública crítica. **A pressão não altera nota, XP, reputação nem a quantidade ou dificuldade dos lances**: ela é mostrada nas convocações e alimenta eventos narrativos. A dificuldade real continua vindo da importância da partida (Etapa 3). O contexto é calculado antes de a partida entrar no histórico e salvo em `history[].context`.

**Eventos da carreira** (`career.events`, até 40, chave única por evento, nunca duplicados):
| Evento | Gatilho | Efeito |
|---|---|---|
| Jogo de pressão | nível 2 ou mais | registro, notícia (tom pela nota e erros graves) e publicação |
| Revisão técnica | 2 ou mais erros graves reais | e-mail do comitê citando os lances; resultado e nota não mudam |
| Reconhecimento | nota 9 ou mais | registro (o e-mail de reconhecimento já existia) |
| Críticas públicas | imagem pública "Crítica", no máximo a cada 3 partidas | e-mail da assessoria; só narrativa |
| Convocação especial | convocação da semana é final, semifinal, clássico ou última rodada | registro e e-mail, uma vez por jogo |

Nenhum evento custa reputação, XP ou nota. Reprocessar uma partida (`matchId`) ou reabrir a semana não gera nada novo.

**Interface:** aba Eventos na central; linha "Pressão" nas convocações (cores por nível); VAR e pressão no histórico; novas linhas na aba Estatísticas (revisões, alterações, revisões em lances elegíveis, jogos de pressão alta); lista de revisões do VAR com decisão inicial, final e motivo na aba Decisões do resultado; pressão e eventos na aba Carreira do resultado.

**Persistência:** `CAREER_VERSION` 6. A migração 5 para 6 só cria `events: []` (nada é inventado sobre partidas passadas), com backup como nas outras migrações.

**Testes:** `tests/context.test.mjs` (15 testes): rivalidades, níveis de pressão, recompensas inalteradas, eventos e idempotência, críticas, convocações especiais, migração, fatos e comunicação do VAR e auditoria em partida simulada. Total: 98 testes.

**Ainda não feito (Etapas 7 e 8):** prêmios de temporada, Supercopa e Liga Continental, objetivo de "usar o VAR corretamente", eventos de mudança de escala e de oportunidade de competição superior (hoje coberta pelo e-mail de convite ao liberar uma competição), refinamento final e regressão manual completa.

## 14. Etapa 7: prêmios de temporada, objetivo do VAR e acabamento

**Prêmios** (`systems/AwardsSystem.js`, funções puras): Árbitro Revelação, Melhor Avaliação Técnica, Destaque Regional, Destaque em Competições Eliminatórias e Árbitro da Temporada. Cada um tem critérios verificáveis calculados só com os registros das partidas da temporada (nota, erros graves e competição), sem sorteio: Revelação (1ª ou 2ª temporada, 3 jogos ou mais, média 6,5 ou mais, no máximo 1 erro grave; único na carreira), Avaliação Técnica (3 jogos ou mais, média 8,0 ou mais), Regional (2 jogos de copas regionais, média 7,0 ou mais neles), Eliminatórias (2 jogos de copas, média 7,0 ou mais neles) e Árbitro da Temporada (4 jogos ou mais, média 7,5 ou mais, nenhum erro grave). Recompensa: +40 XP uma única vez (chave `prêmio:sTemporada` em `career.awards`).

**Fluxo:** `closeSeason` chama `grantAwards` antes de publicar a comunicação da temporada. Os prêmios conquistados entram em `summary.seasonEnded.awards` e geram notícia, e-mail de reconhecimento e publicação oficial (chaves únicas). Passar a rodada sem apitar não gera prêmio. Reprocessar nunca duplica prêmio nem XP.

**Interface:** aba Prêmios (conquistados, critérios da temporada atual com valores reais e indicador de novos prêmios) e bloco "Prêmios de temporada" no fim da temporada.

**Objetivo de carreira do VAR** (`id: 'var'`): usar o VAR e terminar com a decisão final correta em 3 lances típicos (pênalti, vermelho ou impedimento), medido a partir da auditoria dos registros das partidas. Recompensa: +80 XP, uma vez. Agora são 9 objetivos de carreira.

**Persistência:** `CAREER_VERSION` 7. A migração 6 para 7 só cria `awards: []` (nada é concedido retroativamente).

**Durações:** não foram alteradas. Continuam as 3 opções (Rápida, Padrão, Longa); `src/config.js` e `tests/duration.test.mjs` são idênticos aos da versão anterior.

**Testes:** `tests/awards.test.mjs` (13 testes). Total: 111 testes, todos aprovados.

**Limitações conhecidas:** a Supercopa e a Liga Continental não foram adicionadas (a Etapa 7 pede só integrar as ligas já habilitadas); mudança de escala e oportunidade de competição superior continuam sem evento próprio. A Etapa 8 (regressão manual completa) ainda não foi feita.

## 15. Anulação de gol (falta ou impedimento no lance do gol)

**Pedido:** todo gol que vem de falta ou impedimento deve poder ser anulado, com ou sem VAR, sem alterar o VAR.

**Como funciona (sem VAR):**
- Quando sai o gol, `RefereeDecisionSystem.onGoal` procura a *causa*: uma falta (leve, grave ou na área) ou um impedimento **da equipe que marcou**, que não foi apitado, ocorrido no jogo corrido atual e nos últimos 8 s (`GOAL_CAUSE_WINDOW_MS`). Disputa legal, posição legal e simulação nunca são causa, nem infração da equipe que sofreu o gol (isso é vantagem natural).
- A pausa depois do gol passa de 2,8 s para 4,2 s (`GOAL_CHECK_S`) e o HUD mostra "GOL! Espaço anula o gol". O prompt é o mesmo com ou sem causa, então não entrega a resposta.
- **Espaço** (apito), **F** (falta) ou **G** chamam `annulGoal()` (a `MatchScene` direciona essas teclas para a anulação só durante a pausa do gol; fora dela o apito é o de sempre) → `MatchSimulation.disallowGoal`: o placar volta, o banner mostra "GOL ANULADO" e o jogo recomeça com tiro livre (indireto se foi impedimento) para a equipe prejudicada, no local da infração. Sem infração (gol válido anulado por engano), recomeça com tiro de meta.
- Se nada for apertado, o gol vale.

**Nota (decisão registrada na súmula, tipo `goal_check`):**
- Só entra na súmula quando há infração real ou quando o árbitro anula: gol limpo confirmado não gera registro, para não inflar a nota com acertos fáceis.
- Anular gol com infração real: acerto ("Gol irregular anulado corretamente").
- Confirmar gol com infração real: "gol irregular validado" (erro grave, peso 1,5).
- Anular gol limpo: "gol válido anulado" (erro grave).
- A falta ou o impedimento original continua avaliado à parte, como antes (se não foi apitado, segue como "não marcada").
- `matchFacts` não conta o `goal_check` como falta, impedimento nem cartão (campos novos: `goalsDisallowed`, `goalChecksWrong`).

**Com VAR (nada foi alterado em `VarSystem`):** corrigir a falta ou o impedimento na revisão volta a partida ao instante do lance, e o gol some junto, como já acontecia. `restoreState` descarta a conferência de gol pendente e a súmula é truncada, sem registro duplicado.

**Arquivos:** `MatchRules.js` (constantes e textos), `MatchSimulation.js` (`disallowGoal`), `RefereeDecisionSystem.js`, `RefereeGrading.js`, `Controls.js` (tecla G), `MatchScene.js`, `HUD.js`, `config.js` (eventos `goal-disallowed` e `goal-decision` na lista), `MenuScene.js` (Como jogar) e `CommsSystem.js` (campos novos de fatos).

**Testes:** `tests/goalcheck.test.mjs` (12 testes). Total: 123 testes.

**Limitações:** a anulação não permite dar cartão junto; o replay do VAR continua mostrando o gol anulado pela tecla G na linha do tempo (o VAR não foi alterado); a durações das partidas continuam as mesmas 3 opções (só a pausa depois de cada gol ficou 1,4 s maior).
