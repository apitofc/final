import { migrateCareer, CAREER_VERSION } from '../systems/CareerSystem.js';
import { DURATIONS, DEFAULT_DURATION } from '../config.js';

// A chave original é mantida: carreiras salvas em versões anteriores continuam sendo encontradas.
const KEY = 'refwhistle:career:v1';
const MIGRATION_BACKUP_KEY = 'refwhistle:career:backup';
const PREVIOUS_KEY = 'refwhistle:career:previous';
const SETTINGS_KEY = 'apitodojogo:settings';

// Resultado: { career, status: 'none' | 'ok' | 'migrated' | 'invalid' | 'unavailable', error? }
// Dados antigos são migrados com backup; dados inválidos nunca são apagados.
export function loadCareerResult() {
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return { career: null, status: 'none' };

    let data;
    try {
      data = JSON.parse(raw);
    } catch (e) {
      return { career: null, status: 'invalid', error: 'o arquivo salvo está ilegível' };
    }
    const result = migrateCareer(data);
    if (result.error) return { career: null, status: 'invalid', error: result.error };

    if (result.migrated) {
      if (!window.localStorage.getItem(MIGRATION_BACKUP_KEY)) window.localStorage.setItem(MIGRATION_BACKUP_KEY, raw);
      window.localStorage.setItem(KEY, JSON.stringify(result.career));
      return { career: result.career, status: 'migrated' };
    }
    return { career: result.career, status: 'ok' };
  } catch (e) {
    return { career: null, status: 'unavailable', error: 'o navegador bloqueou o armazenamento' };
  }
}

export function loadCareer() {
  return loadCareerResult().career;
}

export function saveCareer(career) {
  try {
    career.version = CAREER_VERSION;
    window.localStorage.setItem(KEY, JSON.stringify(career));
    return true;
  } catch (e) {
    return false;
  }
}

// Guarda uma cópia da carreira atual antes de substituí-la ou apagá-la.
export function backupCurrentCareer() {
  try {
    const raw = window.localStorage.getItem(KEY);
    if (raw) window.localStorage.setItem(PREVIOUS_KEY, raw);
  } catch (e) {
    // sem armazenamento: nada a copiar
  }
}

export function clearCareer() {
  backupCurrentCareer();
  try {
    window.localStorage.removeItem(KEY);
  } catch (e) {
    // ignora
  }
}

// Preferências do jogador (não pertencem a uma carreira): duração das partidas.
export function loadSettings() {
  const defaults = { duration: DEFAULT_DURATION };
  try {
    const raw = window.localStorage.getItem(SETTINGS_KEY);
    if (!raw) return defaults;
    const data = JSON.parse(raw);
    const duration = DURATIONS.some((d) => d.id === data.duration) ? data.duration : DEFAULT_DURATION;
    return { ...defaults, ...data, duration };
  } catch (e) {
    return defaults;
  }
}

export function saveSettings(settings) {
  try {
    window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    return true;
  } catch (e) {
    return false;
  }
}
