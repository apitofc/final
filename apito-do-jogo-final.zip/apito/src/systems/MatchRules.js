import { playerFull } from '../utils/labels.js';

export const INCIDENT = {
  CHALLENGE: 'challenge',
  LIGHT_FOUL: 'light_foul',
  SERIOUS_FOUL: 'serious_foul',
  PENALTY: 'penalty',
  SIMULATION: 'simulation',
  OFFSIDE: 'offside',
  LEGAL_POSITION: 'legal_position',
};

// Conferência de gol (gol que veio de falta ou impedimento da equipe que marcou). Não é um lance do campo: nasce no
// momento do gol, durante a pausa de comemoração, e é decidido pelo árbitro (anular ou confirmar) sem depender do VAR.
export const GOAL_CHECK = 'goal_check';
export const GOAL_CHECK_S = 4.2; // pausa depois do gol (segundos de jogo) para o árbitro anular, se for o caso
export const GOAL_CAUSE_WINDOW_MS = 8000; // a infração precisa ter ocorrido nos últimos 8 s de jogo corrido
export const GOAL_CAUSE_TYPES = ['light_foul', 'serious_foul', 'penalty', 'offside'];

export const INCIDENT_LABEL = {
  goal_check: 'Gol',
  challenge: 'Disputa legal',
  light_foul: 'Falta leve',
  serious_foul: 'Falta grave',
  penalty: 'Pênalti',
  simulation: 'Simulação',
  offside: 'Impedimento',
  legal_position: 'Posição legal',
};

export const CALL_RANGE = 90;
export const INCIDENT_WINDOW_MS = {
  challenge: 3000,
  light_foul: 4000,
  serious_foul: 5000,
  penalty: 5000,
  simulation: 5000,
  offside: 4000,
  legal_position: 3000,
};
export const ADVANTAGE_MS = 3000;
export const IMMEDIATE_FEEDBACK = true;

// Limites das agravantes de uma falta (mostradas ao árbitro como evidências).
export const FOUL_THRESHOLDS = { highSpeed: 50, reckless: 0.45 };

// Gravidade = número de agravantes: entrada por trás, alta velocidade e entrada imprudente.
//   0 ou 1 agravante  -> falta leve (sem cartão)
//   2 agravantes      -> falta pesada (cartão amarelo)
//   3 agravantes      -> força excessiva (cartão vermelho)
// A regra é a mesma que o "Como jogar" explica e depende só de velocidade, ângulo e agressividade.
export function classifyFoul({ relSpeed, fromBehind, aggression }) {
  const evidence = ['contato antes da bola'];
  let aggravating = 0;
  if (fromBehind) {
    evidence.push('entrada por trás');
    aggravating += 1;
  }
  if (relSpeed > FOUL_THRESHOLDS.highSpeed) {
    evidence.push('alta velocidade');
    aggravating += 1;
  }
  if (aggression > FOUL_THRESHOLDS.reckless) {
    evidence.push('entrada imprudente');
    aggravating += 1;
  }
  const level = aggravating >= 3 ? 'red' : aggravating === 2 ? 'yellow' : 'light';
  if (level === 'red') evidence.push('força excessiva');
  return { level, aggravating, evidence };
}

export function buildExpected(type, level) {
  switch (type) {
    case INCIDENT.SIMULATION:
      return { foul: false, card: 'yellow', restart: 'indirect_free_kick', cardTarget: 'diver', advantageAllowed: false };
    case INCIDENT.OFFSIDE:
      return { foul: true, card: null, restart: 'indirect_free_kick', cardTarget: null, advantageAllowed: false };
    case INCIDENT.LIGHT_FOUL:
      return { foul: true, card: null, restart: 'free_kick', cardTarget: null, advantageAllowed: true };
    case INCIDENT.SERIOUS_FOUL:
      return { foul: true, card: level === 'red' ? 'red' : 'yellow', restart: 'free_kick', cardTarget: 'offender', advantageAllowed: false };
    case INCIDENT.PENALTY:
      return {
        foul: true,
        card: level === 'light' ? null : level,
        restart: 'penalty',
        cardTarget: level === 'light' ? null : 'offender',
        advantageAllowed: false,
      };
    default: // challenge
      return { foul: false, card: null, restart: null, cardTarget: null, advantageAllowed: false };
  }
}

export const ERROR_MESSAGES = {
  FOUL_MISSED: 'falta não marcada',
  FOUL_WRONG: 'não era falta',
  CARD_MISSED: 'faltou o cartão',
  CARD_TOO_LIGHT: 'cartão brando demais',
  CARD_TOO_HARSH: 'cartão severo demais',
  CARD_UNWARRANTED: 'cartão sem motivo',
  CARD_WRONG_PLAYER: 'cartão para o jogador errado',
  ADVANTAGE_FAILED: 'vantagem não se confirmou',
  WHISTLE_UNNECESSARY: 'apito sem lance',
};

export function describeIncident(incident) {
  const off = playerFull(incident.offender);
  const vic = playerFull(incident.victim);
  switch (incident.type) {
    case INCIDENT.SIMULATION:
      return `${vic} cai na disputa com ${off}`;
    case INCIDENT.PENALTY:
      return `${off} atinge ${vic} dentro da área`;
    case INCIDENT.CHALLENGE:
      return `${off} disputa a bola com ${vic}`;
    case INCIDENT.OFFSIDE:
      return `${off} recebe o passe em posição de impedimento (último defensor: ${vic})`;
    case INCIDENT.LEGAL_POSITION:
      return `${off} recebe o passe na linha do último defensor (${vic})`;
    default:
      return `${off} atinge ${vic} em disputa de bola`;
  }
}

export function evaluateDecision(incident) {
  const e = incident.expected;
  const a = incident.actual;
  const errors = new Set();
  const notes = [];

  const advantageOk = a.advantage === 'success' || a.advantage === 'implicit';
  if (a.advantage === 'failed') errors.add('ADVANTAGE_FAILED');

  if (e.foul && !a.foulCalled && !(advantageOk && e.advantageAllowed)) errors.add('FOUL_MISSED');
  if (!e.foul && a.foulCalled) errors.add('FOUL_WRONG');

  const wanted = e.card ? (e.cardTarget === 'diver' ? incident.victim : incident.offender) : null;
  const shown = a.cards.filter((c) => c.color !== 'warning');
  const warned = a.cards.filter((c) => c.color === 'warning');

  for (const c of shown) {
    if (!e.card) errors.add('CARD_UNWARRANTED');
    else if (c.player !== wanted) errors.add('CARD_WRONG_PLAYER');
    else if (c.color !== e.card) errors.add(e.card === 'red' ? 'CARD_TOO_LIGHT' : 'CARD_TOO_HARSH');
  }

  if (e.card && !shown.some((c) => c.player === wanted)) {
    if (warned.some((c) => c.player === wanted)) errors.add('CARD_TOO_LIGHT');
    else if (!(e.foul && !a.foulCalled)) errors.add('CARD_MISSED');

  }

  if (a.advantage === 'success') notes.push('ADVANTAGE_OK');
  if (a.advantage === 'implicit') notes.push('ADVANTAGE_UNSIGNALED');
  if (warned.length) notes.push('VERBAL_WARNING');

  const list = [...errors];
  return { errors: list, notes, correct: list.length === 0 };
}

// Texto do erro, ajustado ao tipo de lance (no impedimento "falta" vira "impedimento").
export function errorText(code, type) {
  if (type === GOAL_CHECK) {
    if (code === 'FOUL_MISSED') return 'gol irregular validado';
    if (code === 'FOUL_WRONG') return 'gol válido anulado';
  }
  if (type === INCIDENT.OFFSIDE || type === INCIDENT.LEGAL_POSITION) {
    if (code === 'FOUL_MISSED') return 'impedimento não marcado';
    if (code === 'FOUL_WRONG') return 'não era impedimento';
  }
  return ERROR_MESSAGES[code];
}
