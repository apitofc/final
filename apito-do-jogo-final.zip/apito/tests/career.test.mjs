import test from 'node:test';
import assert from 'node:assert/strict';
import { createCareer, migrateCareer, isValidCareer, applyMatch, sanitizeProfile, getOffers, CAREER_VERSION } from '../src/systems/CareerSystem.js';
import { REFEREE_LOOKS, REGIONS } from '../src/data/referees.js';

const report = (nota, mistakes = 0) => ({
  nota,
  label: 'x',
  categories: [{ label: 'Posicionamento', ratio: 0.4 }],
  mistakes: Array.from({ length: mistakes }, () => ({ severity: 3 })),
  counts: { unnecessaryWhistles: 0 },
  score: { home: 1, away: 0 },
});
// Jogo do calendário (convocação i da semana; -1 = a última) no formato que a partida devolve ao resultado.
const fixtureOf = (career, i, extra = {}) => {
  const offers = getOffers(career);
  const f = offers[i < 0 ? offers.length + i : i].fixture;
  return { competitionId: f.competitionId, homeId: f.home, awayId: f.away, importance: f.importance, fixtureId: f.id, ...extra };
};

test('perfil: oito aparências, cinco regiões e valores padrão', () => {
  assert.equal(REFEREE_LOOKS.length, 8);
  assert.equal(new Set(REFEREE_LOOKS.map((l) => `${l.skin}${l.hair}${l.shirt}${l.accent}`)).size, 8);
  assert.deepEqual(REGIONS.map((r) => r.name), ['Norte', 'Nordeste', 'Centro-Oeste', 'Sudeste', 'Sul']);
  assert.deepEqual(sanitizeProfile({}), { name: 'Novo Árbitro', look: 0, region: 'sudeste' });
  assert.deepEqual(sanitizeProfile({ name: '  Ana  ', look: 5, region: 'sul' }), { name: 'Ana', look: 5, region: 'sul' });
  assert.equal(sanitizeProfile({ look: 99, region: 'lua' }).look, 0);
});

test('criar carreira guarda nome, aparência e região', () => {
  const c = createCareer({ name: 'Marina', look: 3, region: 'nordeste' }, 7);
  assert.equal(c.version, CAREER_VERSION);
  assert.deepEqual(c.profile, { name: 'Marina', look: 3, region: 'nordeste' });
  assert.equal(c.name, 'Marina');
  assert.ok(isValidCareer(c));
  assert.equal(JSON.stringify(JSON.parse(JSON.stringify(c))), JSON.stringify(c)); // serializa sem perdas
});

test('migração v1 -> v2 preserva todos os campos antigos', () => {
  const v1 = { ...createCareer('Antigo', 11), version: 1 };
  delete v1.profile;
  delete v1.processed;
  v1.xp = 321;
  v1.rep = 42.5;
  v1.history = [{ season: 1, round: 1, nota: 7.1 }];
  const r = migrateCareer(JSON.parse(JSON.stringify(v1)));
  assert.ok(r.migrated);
  assert.equal(r.career.version, CAREER_VERSION);
  assert.equal(r.career.xp, 321);
  assert.equal(r.career.rep, 42.5);
  assert.deepEqual(r.career.history, v1.history);
  assert.equal(r.career.name, 'Antigo');
  assert.equal(r.career.profile.name, 'Antigo');
  assert.equal(r.career.migratedFrom, 1);
});

test('dados inválidos ou de versão desconhecida são recusados sem exceção', () => {
  assert.ok(migrateCareer(null).error);
  assert.ok(migrateCareer({ version: 99 }).error);
  assert.ok(migrateCareer({ version: 1, name: 'x' }).error);
  assert.ok(migrateCareer('texto').error);
});

test('resultado de partida é idempotente (mesmo jogo não conta duas vezes)', () => {
  const c = createCareer('Teste', 5);
  const fixture = fixtureOf(c, 0, { matchId: 'jogo-1', duration: 'quick' });
  const first = applyMatch(c, fixture, report(8));
  assert.ok(first);
  const snapshot = JSON.stringify(c);
  assert.equal(applyMatch(c, fixture, report(8)), null);
  assert.equal(JSON.stringify(c), snapshot);
  assert.equal(c.history[0].duration, 'quick');
  assert.equal(c.totalMatches, 1);
});

test('um mau jogo nunca trava a carreira', () => {
  const c = createCareer('Teste', 9);
  for (let i = 0; i < 40; i++) applyMatch(c, fixtureOf(c, -1, { matchId: `m${i}` }), report(1.5, 5));
  assert.ok(c.rep >= 0);
  const offers = getOffers(c);
  assert.ok(offers.length >= 1, 'sempre há convocação');
  assert.ok(offers.some((o) => o.competition.id === 'varzea'), 'a divisão mais baixa continua disponível');
});

test('convocações são determinísticas', () => {
  const a = createCareer('A', 123);
  const b = createCareer('B', 123);
  assert.deepEqual(getOffers(a).map((o) => o.fixture.id), getOffers(b).map((o) => o.fixture.id));
});
