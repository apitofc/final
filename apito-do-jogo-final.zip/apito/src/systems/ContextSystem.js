// Contexto profissional: pressão, rivalidades e eventos especiais da carreira (Etapa 6). Funções puras.
//
// Regras de projeto:
//  - A pressão é calculada só a partir de fatos do calendário e da carreira (rivalidade, fase, prestígio, última rodada,
//    última partida e imagem pública). Nada é sorteado.
//  - A pressão NÃO altera nota, reputação, XP nem a quantidade ou a dificuldade dos lances. Ela aparece nas convocações,
//    nos detalhes dos jogos e alimenta eventos narrativos (notícias, e-mails e publicações). A dificuldade real dos
//    jogos importantes continua vindo da importância da partida, como antes.
//  - Eventos nunca punem: são registros narrativos. Cada evento tem uma chave única, então reprocessar não duplica.
import { getCompetition } from '../data/competitions.js';
import { WEEKS_PER_SEASON, findFixture } from './CalendarSystem.js';
import { publicImage } from './CommsSystem.js';

// Rivalidades fictícias (pares de clubes). Os nomes dos clássicos aparecem nos detalhes do jogo.
export const RIVALRIES = [
  { id: 'varzea', name: 'Clássico da Várzea', clubs: ['tamarindo', 'jaqueira'] },
  { id: 'litoral', name: 'Clássico do Litoral', clubs: ['maresia', 'coqueiral'] },
  { id: 'dunas', name: 'Dérbi das Dunas', clubs: ['dunas', 'jangada'] },
  { id: 'cerrado', name: 'Clássico do Cerrado', clubs: ['cerrado', 'serradourada'] },
  { id: 'sertao', name: 'Clássico do Sertão', clubs: ['sertaoun', 'valedosol'] },
  { id: 'estrelas', name: 'Clássico das Estrelas', clubs: ['aurora', 'estrelapolar'] },
  { id: 'norte', name: 'Clássico do Norte', clubs: ['falcoes', 'trovao'] },
  { id: 'nacional', name: 'Grande Clássico Nacional', clubs: ['titas', 'realhorizonte'] },
  { id: 'fenix', name: 'Clássico Imperial', clubs: ['imperial', 'fenix'] },
  { id: 'sul', name: 'Clássico do Sul', clubs: ['gigantes', 'dragoes'] },
  { id: 'continental', name: 'Clássico Continental', clubs: ['condor', 'meridian'] },
  { id: 'sol', name: 'Dérbi do Sol', clubs: ['solnascente', 'tucano'] },
];

export const PRESSURE_LABELS = ['Normal', 'Atenção', 'Alta', 'Máxima'];
export const EVENT_LIMIT = 40;

export const rivalryOf = (homeId, awayId) => RIVALRIES.find((r) => r.clubs.includes(homeId) && r.clubs.includes(awayId)) || null;

const isFinal = (stage) => /^final$/i.test(stage || '');
const isSemi = (stage) => /^semifinal/i.test(stage || '');

// Contexto de um jogo. f = { competitionId, homeId, awayId, stage, week }.
// Retorna { level (0 a 3), label, tags: [{ id, label, text }] }.
export function matchContext(career, f) {
  const comp = getCompetition(f.competitionId);
  const tags = [];
  let points = 0;
  const add = (id, label, text, weight) => {
    tags.push({ id, label, text });
    points += weight;
  };

  const riv = rivalryOf(f.homeId, f.awayId);
  if (riv) add('rivalry', riv.name, `Rivalidade histórica entre os clubes (${riv.name}).`, 1);

  if (isFinal(f.stage)) add('final', 'Final', `Final da ${comp ? comp.name : 'competição'}: o jogo decide o título.`, 2);
  else if (isSemi(f.stage)) add('semifinal', 'Semifinal', `Semifinal da ${comp ? comp.name : 'competição'}: quem perder está fora.`, 1);

  if (comp && comp.importance >= 3) add('prestige', 'Competição de prestígio', `${comp.name} é uma das competições de maior prestígio.`, 1);

  if (comp && comp.division && f.week >= WEEKS_PER_SEASON) add('decisive', 'Última rodada', 'Última rodada da temporada: o comitê decide promoções e rebaixamentos logo depois.', 1);

  const last = career && career.history ? career.history[0] : null;
  if (last && ((last.graves || 0) >= 2 || last.nota < 5)) add('controversy', 'Jogo anterior polêmico', 'Sua última partida teve erros graves ou nota baixa, e a atenção sobre você aumentou.', 1);

  const image = career ? publicImage(career) : null;
  if (image && image.label === 'Crítica') add('criticism', 'Imprensa crítica', 'A imprensa tem sido crítica com a sua arbitragem nas últimas partidas.', 1);

  const level = Math.min(3, points);
  return { level, label: PRESSURE_LABELS[level], tags };
}

// Resumo salvo no registro da partida (só os identificadores, para o histórico).
export const contextSummary = (ctx) => ({ level: ctx.level, label: ctx.label, tags: ctx.tags.map((t) => t.id) });

// ------------------------------------------------------------ eventos da carreira
export function ensureEvents(career) {
  if (!Array.isArray(career.events)) career.events = [];
}

function addEvent(career, ev) {
  ensureEvents(career);
  if (career.events.some((e) => e.key === ev.key)) return false;
  career.events.unshift(ev);
  career.events.length = Math.min(career.events.length, EVENT_LIMIT);
  return true;
}

export const eventTone = (nota, graves) => (nota >= 7.5 && graves === 0 ? 'positive' : nota < 5 || graves >= 2 ? 'negative' : 'neutral');

// Eventos gerados depois de uma partida. ctx é o mesmo contexto da comunicação (partida, nota, erros e fatos reais) mais
// `pressure` (matchContext calculado ANTES de a partida entrar no histórico).
// Devolve { events, bundle } onde bundle = { news, emails, posts } para o CommsSystem.publish. Só os eventos novos entram.
export function eventsForMatch(career, ctx, pressure) {
  const date = { season: ctx.season, week: ctx.week };
  const events = [];
  const bundle = { news: [], emails: [], posts: [] };
  const vs = `${ctx.home.name} x ${ctx.away.name}`;
  const base = { competitionId: ctx.competitionId, fixtureId: ctx.fixtureId, matchId: ctx.matchId, date };
  const push = (ev, extra = {}) => {
    const full = { ...ev, date, matchId: ctx.matchId, fixtureId: ctx.fixtureId, totalMatches: career.totalMatches };
    if (!addEvent(career, full)) return false;
    events.push(full);
    if (extra.news) bundle.news.push({ ...base, key: `${ev.key}:news`, category: 'carreira', ...extra.news });
    if (extra.email) bundle.emails.push({ ...base, key: `${ev.key}:mail`, ...extra.email });
    if (extra.post) bundle.posts.push({ ...base, key: `${ev.key}:post`, ...extra.post });
    return true;
  };

  // 1. Jogo de alta pressão: o desfecho da notícia depende só da nota e dos erros graves registrados.
  if (pressure && pressure.level >= 2) {
    const tone = eventTone(ctx.nota, ctx.graves);
    const headline =
      tone === 'positive' ? `Árbitro mantém o controle em jogo de pressão: ${vs}` : tone === 'negative' ? `Pressão pesa sobre a arbitragem em ${vs}` : `Jogo de pressão termina sem grandes sobressaltos: ${vs}`;
    const tagText = pressure.tags.map((t) => t.label.toLowerCase()).join(', ');
    push(
      { key: `${ctx.matchId}:ev:pressure`, type: 'high_pressure', tone, title: `Jogo de pressão ${pressure.label.toLowerCase()}: ${vs}`, text: `Fatores: ${tagText}. Nota final ${String(ctx.nota).replace('.', ',')}.` },
      {
        news: { tone, variant: 'ev-pressure', source: 'Gazeta do Apito', headline, summary: `O jogo tinha pressão ${pressure.label.toLowerCase()} (${tagText}). A avaliação técnica foi ${ctx.label.toLowerCase()}, com ${ctx.graves} ${ctx.graves === 1 ? 'erro grave' : 'erros graves'}.` },
        post: { author: { name: 'Rádio Campo Aberto', handle: '@campoaberto', kind: 'comentarista' }, tag: 'opinião', text: `${vs}: ${tagText}. Jogo que exige pulso firme do árbitro.`, likes: 40 + ((ctx.nota * 37) | 0), technical: false },
      }
    );
  }

  // 2. Revisão técnica: erros graves registrados abrem uma análise do comitê. Não altera o resultado nem a nota.
  if (ctx.graves >= 2) {
    const items = (ctx.mistakes || []).filter((m) => m.errors).slice(0, 2).map((m) => `${m.clock} · ${m.label}: ${m.errors.join(', ')}.`);
    push(
      { key: `${ctx.matchId}:ev:review`, type: 'technical_review', tone: 'negative', title: `Revisão técnica: ${vs}`, text: `O comitê analisou ${ctx.graves} erros graves da partida. Resultado e nota não mudam.` },
      {
        email: {
          from: 'Comitê de Arbitragem',
          category: 'avaliação',
          subject: `Revisão técnica: ${vs}`,
          lines: [`O comitê fez uma revisão técnica da partida por causa de ${ctx.graves} erros graves registrados.`, ...items, 'A revisão é só um registro de aprendizado: o resultado e a nota da partida não são alterados.'],
        },
      }
    );
  }

  // 3. Reconhecimento por desempenho: só o registro (o e-mail de reconhecimento já existe na comunicação da partida).
  if (ctx.nota >= 9) {
    push({ key: `${ctx.matchId}:ev:recognition`, type: 'recognition', tone: 'positive', title: `Reconhecimento: ${vs}`, text: `Nota ${String(ctx.nota).replace('.', ',')}, entre as mais altas da competição.` });
  }

  return { events, bundle };
}

// Críticas públicas: avaliadas DEPOIS de a comunicação da partida ser publicada (a imagem pública usa as notícias).
// Só gera um evento a cada 3 partidas, para não virar repetição. É só narrativa: não custa reputação.
export function criticismEvent(career, ctx) {
  const image = publicImage(career);
  if (!image || image.label !== 'Crítica') return { events: [], bundle: { news: [], emails: [], posts: [] } };
  ensureEvents(career);
  const lastOne = career.events.find((e) => e.type === 'public_criticism');
  if (lastOne && career.totalMatches - (lastOne.totalMatches || 0) < 3) return { events: [], bundle: { news: [], emails: [], posts: [] } };
  const date = { season: ctx.season, week: ctx.week };
  const ev = {
    key: `${ctx.matchId}:ev:criticism`,
    type: 'public_criticism',
    tone: 'negative',
    title: 'Críticas públicas à arbitragem',
    text: `${image.negative} das últimas ${image.total} reportagens sobre você foram críticas.`,
    date,
    matchId: ctx.matchId,
    fixtureId: ctx.fixtureId,
    totalMatches: career.totalMatches,
  };
  if (!addEvent(career, ev)) return { events: [], bundle: { news: [], emails: [], posts: [] } };
  return {
    events: [ev],
    bundle: {
      emails: [
        {
          key: `${ev.key}:mail`,
          from: 'Assessoria de Imprensa',
          category: 'comunicado',
          subject: 'A imprensa tem criticado a sua arbitragem',
          lines: [`${image.negative} das últimas ${image.total} reportagens sobre a sua arbitragem foram críticas.`, 'Isso é só a imagem pública: não altera sua nota, sua reputação nem sua progressão.', 'O melhor caminho é seguir o plano de jogo e revisar os lances apontados nos relatórios.'],
          matchId: ctx.matchId,
          date,
        },
      ],
    },
  };
}

// Convocações especiais da semana: finais, semifinais, clássicos e a última rodada. Chamado ao montar as convocações.
// Cria só um registro e um e-mail por jogo (chave estável), então reabrir a carreira não duplica nada.
export function eventsForWeek(career) {
  const w = career.world;
  const date = { season: w.season, week: w.week };
  const events = [];
  const emails = [];
  if (!w.offers || !Array.isArray(w.offers.items)) return { events, bundle: { emails } };
  for (const item of w.offers.items) {
    if (item.status !== 'offered') continue;
    const fx = findFixture(w, item.fixtureId);
    if (!fx) continue;
    const comp = getCompetition(fx.competitionId);
    const pressure = matchContext(career, { competitionId: fx.competitionId, homeId: fx.home, awayId: fx.away, stage: fx.stage, week: fx.week });
    const special = pressure.tags.filter((t) => ['final', 'semifinal', 'rivalry', 'decisive'].includes(t.id));
    if (!special.length) continue;
    const ev = {
      key: `ev:special:${fx.id}`,
      type: 'special_call',
      tone: 'neutral',
      title: `Convocação especial: ${special[0].label}`,
      text: `${comp ? comp.name : ''}${fx.stage ? ` · ${fx.stage}` : ''}. ${special.map((t) => t.text).join(' ')}`,
      date,
      fixtureId: fx.id,
      totalMatches: career.totalMatches,
    };
    if (!addEvent(career, ev)) continue;
    events.push(ev);
    emails.push({
      key: `${ev.key}:mail`,
      from: 'Comissão de Arbitragem',
      category: 'convocação',
      subject: `Convocação especial: ${special[0].label}`,
      lines: [`Há um jogo especial entre as suas convocações da semana (${comp ? comp.name : ''}${fx.stage ? `, ${fx.stage}` : ''}).`, ...special.map((t) => t.text), 'Aceitar é opcional e recusar não custa nada. A pressão não muda a nota: só o que você decidir em campo.'],
      fixtureId: fx.id,
      date,
    });
  }
  return { events, bundle: { emails } };
}
