import test from 'node:test';
import assert from 'node:assert/strict';
import { classifyFoul, FOUL_THRESHOLDS, evaluateDecision, buildExpected } from '../src/systems/MatchRules.js';

const fast = FOUL_THRESHOLDS.highSpeed + 1;
const slow = 10;
const rough = FOUL_THRESHOLDS.reckless + 0.1;
const calm = 0.2;

test('gravidade da falta = número de agravantes (regra do "Como jogar")', () => {
  const cases = [
    [{ relSpeed: slow, fromBehind: false, aggression: calm }, 'light', 0],
    [{ relSpeed: slow, fromBehind: true, aggression: calm }, 'light', 1],
    [{ relSpeed: fast, fromBehind: false, aggression: calm }, 'light', 1],
    [{ relSpeed: slow, fromBehind: false, aggression: rough }, 'light', 1],
    [{ relSpeed: fast, fromBehind: true, aggression: calm }, 'yellow', 2],
    [{ relSpeed: slow, fromBehind: true, aggression: rough }, 'yellow', 2],
    [{ relSpeed: fast, fromBehind: false, aggression: rough }, 'yellow', 2],
    [{ relSpeed: fast, fromBehind: true, aggression: rough }, 'red', 3],
  ];
  for (const [input, level, count] of cases) {
    const r = classifyFoul(input);
    assert.equal(r.level, level, JSON.stringify(input));
    assert.equal(r.aggravating, count);
    assert.equal(r.evidence.includes('força excessiva'), level === 'red');
  }
});

test('decisão esperada para cada tipo de lance', () => {
  assert.deepEqual(buildExpected('challenge', 'none').foul, false);
  assert.equal(buildExpected('light_foul', 'light').card, null);
  assert.equal(buildExpected('serious_foul', 'yellow').card, 'yellow');
  assert.equal(buildExpected('serious_foul', 'red').card, 'red');
  assert.equal(buildExpected('penalty', 'light').card, null);
  const sim = buildExpected('simulation', 'none');
  assert.equal(sim.foul, false);
  assert.equal(sim.cardTarget, 'diver');
});

const A = { team: 'home', number: 4, name: 'A' };
const B = { team: 'away', number: 9, name: 'B' };
const incident = (type, level, actual) => ({ type, level, offender: A, victim: B, expected: buildExpected(type, level), actual: { foulCalled: false, cards: [], advantage: null, ...actual } });

test('avaliação: acertos, erros e cartões', () => {
  assert.ok(evaluateDecision(incident('challenge', 'none', {})).correct);
  assert.deepEqual(evaluateDecision(incident('challenge', 'none', { foulCalled: true })).errors, ['FOUL_WRONG']);
  assert.deepEqual(evaluateDecision(incident('serious_foul', 'yellow', {})).errors, ['FOUL_MISSED']);
  assert.ok(evaluateDecision(incident('serious_foul', 'yellow', { foulCalled: true, cards: [{ player: A, color: 'yellow' }] })).correct);
  assert.deepEqual(evaluateDecision(incident('serious_foul', 'yellow', { foulCalled: true, cards: [{ player: A, color: 'red' }] })).errors, ['CARD_TOO_HARSH']);
  assert.ok(evaluateDecision(incident('serious_foul', 'yellow', { foulCalled: true, cards: [{ player: B, color: 'yellow' }] })).errors.includes('CARD_WRONG_PLAYER'));
  assert.deepEqual(evaluateDecision(incident('light_foul', 'light', { foulCalled: true, cards: [{ player: A, color: 'yellow' }] })).errors, ['CARD_UNWARRANTED']);
  assert.ok(evaluateDecision(incident('simulation', 'none', { cards: [{ player: B, color: 'yellow' }] })).correct);
});
